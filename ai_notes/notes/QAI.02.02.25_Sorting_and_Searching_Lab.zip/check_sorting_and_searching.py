"""Check copy/in-place behavior, axis sorting, locations, and membership."""

import numpy as np

from sorting_and_searching import contains, make_examples


def main():
    scores, table, repeated = make_examples()
    ordered = np.sort(scores)
    assert ordered.tolist() == [10, 20, 30, 40]
    assert scores.tolist() == [40, 10, 30, 20]
    assert ordered[::-1].tolist() == [40, 30, 20, 10]
    editable = scores.copy()
    assert editable.sort() is None
    assert editable.tolist() == [10, 20, 30, 40]
    assert scores.tolist() == [40, 10, 30, 20]
    assert np.sort(table).tolist() == np.sort(table, axis=1).tolist()
    assert np.sort(table, axis=1).tolist() == [[1, 3, 4], [2, 5, 6]]
    assert np.sort(table, axis=0).tolist() == [[2, 1, 3], [4, 6, 5]]
    positions = np.argsort(scores)
    assert positions.tolist() == [1, 3, 2, 0]
    assert np.array_equal(scores[positions], ordered)
    assert np.argsort(table, axis=1).tolist() == [[1, 2, 0], [0, 2, 1]]
    assert np.where(scores >= 30)[0].tolist() == [0, 2]
    rows, cols = np.where(table >= 5)
    assert rows.tolist() == [1, 1] and cols.tolist() == [1, 2]
    assert table[rows, cols].tolist() == [6, 5]
    assert np.nonzero([0, 7, 0, 9])[0].tolist() == [1, 3]
    assert np.nonzero(scores >= 30)[0].tolist() == [0, 2]
    assert np.searchsorted(ordered, [15, 30, 50]).tolist() == [1, 2, 4]
    assert np.searchsorted(ordered, 30, side="left") == 2
    assert np.searchsorted(ordered, 30, side="right") == 3
    assert not contains(ordered, 15)
    assert contains(ordered, 30)
    assert not contains(ordered, 50)
    assert np.unique(repeated).tolist() == [1, 2, 3]
    changed = scores.copy()
    changed[0] = 5
    assert np.sort(changed).tolist() == [5, 10, 20, 30]
    assert np.argsort(changed)[0] == 0
    assert np.where(changed >= 30)[0].tolist() == [2]
    assert scores.tolist() == [40, 10, 30, 20]
    print("All checks passed.")


if __name__ == "__main__":
    main()
