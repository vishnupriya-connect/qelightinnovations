# One-dimensional indexing lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python one_dimensional_indexing.py
python check_one_dimensional_indexing.py
```

Use `python3` if needed. Predict every indexed value before running. Attempt the five-session mini-project independently, then compare with `python mini_project_reference.py`. These examples were checked with NumPy 2.3.5.
