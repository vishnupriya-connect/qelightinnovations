"""SQL safety demo on a disposable SQLite file and synthetic rows."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory

AUDIT_EVENTS = []  # sanitized denial events for this process only
SORT_COLUMNS = {'id': 'course_id', 'title': 'title'}


def setup(path):
    db = sqlite3.connect(path)
    assert db.execute('PRAGMA journal_mode=WAL').fetchone()[0] == 'wal'
    db.executescript("""
        CREATE TABLE courses (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            duration INTEGER NOT NULL CHECK (duration > 0)
        );
        CREATE TABLE audit_log (
            event_id INTEGER PRIMARY KEY,
            actor TEXT NOT NULL,
            action TEXT NOT NULL,
            course_id INTEGER NOT NULL,
            old_value INTEGER NOT NULL,
            new_value INTEGER NOT NULL
        );
    """)
    db.executemany('INSERT INTO courses VALUES (?, ?, ?)', [
        (101, 'AI Foundations', 95),
        (102, 'Git Basics', 50),
        (103, 'Data Basics', 80),
        (104, "O'Brien's SQL", 65),
    ])
    db.commit()
    db.close()


def open_editor(path):
    return sqlite3.connect(path, isolation_level=None)


def open_reader(path):
    # SQLite's file URI mode=ro makes this connection read-only.
    return sqlite3.connect(Path(path).resolve().as_uri() + '?mode=ro', uri=True)


def unsafe_search(db, text):
    """Intentionally unsafe; used only to demonstrate a controlled failure."""
    sql = "SELECT course_id FROM courses WHERE title = '" + text + "' ORDER BY course_id"
    return db.execute(sql).fetchall()


def safe_search(db, text):
    return db.execute('SELECT course_id FROM courses WHERE title = ? ORDER BY course_id',
                      (text,)).fetchall()


def sorted_courses(db, sort_key):
    # A placeholder stands for a value, not a SQL identifier or ORDER BY syntax.
    if sort_key not in SORT_COLUMNS:
        raise ValueError('unsupported sort key')
    column = SORT_COLUMNS[sort_key]
    return db.execute(f'SELECT course_id, title FROM courses ORDER BY {column}').fetchall()


def update_duration(db, *, role, actor, course_id, duration):
    if role != 'editor':
        AUDIT_EVENTS.append({'event': 'write_denied', 'role': 'reader'})
        raise PermissionError('write permission required')
    if type(duration) is not int or duration <= 0:
        raise ValueError('duration must be a positive integer')
    try:
        db.execute('BEGIN IMMEDIATE')
        row = db.execute('SELECT duration FROM courses WHERE course_id = ?',
                         (course_id,)).fetchone()
        if row is None:
            raise ValueError('course not found')
        old_duration = row[0]
        db.execute('UPDATE courses SET duration = ? WHERE course_id = ?',
                   (duration, course_id))
        db.execute('''INSERT INTO audit_log
                      (actor, action, course_id, old_value, new_value)
                      VALUES (?, ?, ?, ?, ?)''',
                   (actor, 'UPDATE_DURATION', course_id, old_duration, duration))
        db.execute('COMMIT')
    except Exception:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise


def main():
    with TemporaryDirectory(prefix='qai_sql_safety_') as folder:
        path = Path(folder) / 'safety.sqlite'
        setup(path)
        reader = open_reader(path)
        editor = open_editor(path)
        try:
            payload = "x' OR 1=1 --"
            print('Unsafe synthetic demonstration:', unsafe_search(reader, payload))
            print('Bound same input:', safe_search(reader, payload))
            print('Apostrophe as bound data:', safe_search(reader, "O'Brien's SQL"))
            print('Allowed title sort:', sorted_courses(reader, 'title'))
            try:
                sorted_courses(reader, 'title; DROP TABLE courses')
            except ValueError:
                print('Unapproved sort rejected:', True)
            try:
                reader.execute('UPDATE courses SET duration = 1 WHERE course_id = 101')
            except sqlite3.OperationalError:
                print('Read-only connection blocked write:', True)
                if reader.in_transaction:
                    reader.rollback()
            try:
                update_duration(reader, role='reader', actor='learner', course_id=104, duration=70)
            except PermissionError:
                print('Reader role denied:', True)
            update_duration(editor, role='editor', actor='trainer', course_id=104, duration=70)
            print('Updated duration:', safe_search(reader, "O'Brien's SQL"),
                  reader.execute('SELECT duration FROM courses WHERE course_id=104').fetchone())
            print('Committed audit:', editor.execute(
                'SELECT actor, action, course_id, old_value, new_value FROM audit_log'
            ).fetchall())
            print('Sanitized denial events:', AUDIT_EVENTS)
        finally:
            reader.close()
            editor.close()


if __name__ == '__main__':
    main()
