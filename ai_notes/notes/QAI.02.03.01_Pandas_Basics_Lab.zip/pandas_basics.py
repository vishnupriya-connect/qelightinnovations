"""A first labeled Series and DataFrame."""

import pandas as pd


def make_examples():
    scores = pd.Series([7, 9, 8], index=["Asha", "Bala", "Charu"])
    table = pd.DataFrame(
        {"name": ["Asha", "Bala"], "score": [7, 9]},
        index=["L1", "L2"],
    )
    return scores, table


def main():
    scores, table = make_examples()
    print("Series labels:", scores.index.tolist())
    print("Bala's Series score:", scores["Bala"])
    print("Table:")
    print(table.to_string())
    print("Row labels:", table.index.tolist())
    print("Column labels:", table.columns.tolist())
    print("Second row label:", table.index[1])
    print("Table shape:", table.shape)
    print("Score column type:", type(table["score"]).__name__)
    print("Score column values:", table["score"].tolist())
    print("Row axis:", table.axes[0].tolist())
    print("Column axis:", table.axes[1].tolist())
    print("Cell L2 / score:", table.loc["L2", "score"])


if __name__ == "__main__":
    main()
