# Data insertion lab

Run from this unzipped folder with Python 3:

```sh
python data_insertion.py
python check_data_insertion.py
```

Use `python3` if needed. The standard-library `sqlite3` module creates three private in-memory tables. Predict the new rows, defaults, and archive IDs before running. Try a missing required title in a fresh copy and explain the error. Attempt the explicit-status variation before inspecting its reference function. The checker confirms the supplied examples; compare your own queries with the table contents.
