"""Join arrays along existing axes or introduce a new axis."""

import numpy as np


def make_examples():
    first = np.array([[10, 20], [30, 40]])
    extra = np.array([[50, 60]])
    new_task = np.array([[7], [9]])
    second = np.array([[50, 60], [70, 80]])
    a = np.array([10, 20, 30])
    b = np.array([40, 50, 60])
    return first, extra, new_task, second, a, b


def main():
    first, extra, new_task, second, a, b = make_examples()
    rows = np.concatenate((first, extra), axis=0)
    columns = np.concatenate((first, new_task), axis=1)
    print("Rows:", rows.shape, rows.tolist())
    print("Columns:", columns.shape, columns.tolist())
    print("hstack vectors:", np.hstack((a, b)).shape)
    print("vstack vectors:", np.vstack((a, b)).shape)
    print("column_stack vectors:", np.column_stack((a, b)).shape)
    joined = np.concatenate((first, second), axis=0)
    stacked = np.stack((first, second), axis=0)
    depth = np.dstack((first, second))
    print("Joined:", joined.shape, joined[2, 1])
    print("Stacked:", stacked.shape, stacked[1, 0, 1])
    print("Depth:", depth.shape, depth[0, 1, 1])
    changed = second.copy()
    changed[0, 1] = 99
    print("Variation:",
          np.concatenate((first, changed), axis=0)[2, 1],
          np.stack((first, changed), axis=0)[1, 0, 1],
          np.dstack((first, changed))[0, 1, 1],
          "original:", second[0, 1])


if __name__ == "__main__":
    main()
