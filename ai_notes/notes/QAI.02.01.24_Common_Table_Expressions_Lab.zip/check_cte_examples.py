"""Check named queries, recursive anchor/member, depth and cycle boundary."""

import sqlite3

from cte_examples import (
    COURSES, PREREQUISITES, long_courses, make_connection, multiple_ctes,
    path_from,
)


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute(
            "SELECT * FROM course_prerequisites ORDER BY course_id"
        ).fetchall() == PREREQUISITES
        assert long_courses(db) == [
            (101, "AI Foundations"), (103, "Data Basics"), (105, "SQL Basics")
        ]
        assert long_courses(db, 80) == [
            (101, "AI Foundations"), (103, "Data Basics")
        ]
        assert multiple_ctes(db) == (3, 245)
        assert multiple_ctes(db, 80) == (2, 175)
        print("Named CTEs, second CTE, threshold variation: correct")

        expected_root = [
            (101, "AI Foundations", 0),
            (103, "Data Basics", 1),
            (104, "Python Basics", 1),
            (105, "SQL Basics", 2),
        ]
        assert path_from(db) == expected_root
        assert path_from(db, 101, 1) == expected_root[:3]
        assert path_from(db, 101, 0) == expected_root[:1]
        assert path_from(db, 999, 2) == []
        assert path_from(db, 103, 2) == [
            (103, "Data Basics", 0), (105, "SQL Basics", 1)
        ]
        print("Anchor, recursive member, new root and depth bounds: correct")

        try:
            db.execute("SELECT * FROM long_courses").fetchall()
        except sqlite3.OperationalError as exc:
            assert "no such table" in str(exc).lower()
        else:
            raise AssertionError("CTE should not survive a later statement")
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        print("Named result is statement-scoped; base rows unchanged: correct")

    with make_connection() as db:
        db.execute(
            "INSERT INTO course_prerequisites VALUES (?, ?)", (101, 105)
        )
        db.commit()
        cycled = path_from(db, 101, 3)
        assert cycled[-1] == (101, "AI Foundations", 3)
        assert len(cycled) == 5
        print("Bounded cycle produces a repeat, then stops at depth 3: correct")


if __name__ == "__main__":
    main()
