"""Complete reference solution for splitting study records."""

import numpy as np


def main():
    records = np.arange(100, 124, dtype=np.int32).reshape(6, 4)
    row_parts = np.vsplit(records, [2, 5])
    column_parts = np.hsplit(records, [1, 3])
    cube = records.reshape(2, 3, 4)
    depth_parts = np.dsplit(cube, 2)
    print("row shapes", [p.shape for p in row_parts], "value", row_parts[2][0, 3])
    print("column shapes", [p.shape for p in column_parts], "value", column_parts[2][5, 0])
    print("depth shapes", [p.shape for p in depth_parts], "value", depth_parts[1][1, 2, 1])


if __name__ == "__main__":
    main()
