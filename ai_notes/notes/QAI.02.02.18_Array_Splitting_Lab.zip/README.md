# Array splitting lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python array_splitting.py
python check_array_splitting.py
python mini_project_reference.py
```

Predict the shape of each piece and trace values 16 and 23 before running. Then try the controlled variation in the companion notes.
