"""Select arbitrary, ordered, and repeated positions with integer arrays."""

import numpy as np


def session_minutes():
    return np.array([12, 18, 25, 30, 40], dtype=np.int32)


def select_positions(source, positions):
    return source[np.asarray(positions, dtype=np.intp)]


def learner_work():
    return np.array([[12, 8], [10, 15], [14, 6]], dtype=np.int32)


def main():
    source = session_minutes()
    positions = np.array([4, 1, 4, 0], dtype=np.intp)
    selected = select_positions(source, positions)
    print("Positions:", positions.tolist())
    print("Selected:", selected.tolist(), selected.shape)
    print("Shares memory:", bool(np.shares_memory(selected, source)))
    selected[0] = 99
    print("Changed selection:", selected.tolist(), "; source:", source.tolist())

    slice_result = source[1:4]
    fancy_result = source[np.array([1, 2, 3])]
    print("Same values:", slice_result.tolist(), fancy_result.tolist())
    print("Slice and fancy share memory with source:",
          bool(np.shares_memory(slice_result, source)),
          bool(np.shares_memory(fancy_result, source)))

    changed = select_positions(source, [0, 4, 0])
    print("Changed request:", changed.tolist(), changed.shape)
    changed[-1] = 99
    print("Edited changed result:", changed.tolist(), "; source first:", int(source[0]))

    work = learner_work()
    print("Reordered rows:", work[[2, 0, 2]].tolist())
    print("Pairwise coordinates:", work[[0, 2], [1, 0]].tolist())
    print("Empty request:", select_positions(source, []).tolist())
    try:
        select_positions(source, [4, 5])
    except IndexError as error:
        print("Invalid position:", type(error).__name__)


if __name__ == "__main__":
    main()
