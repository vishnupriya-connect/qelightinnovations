"""Verify value changes, original types, and guarded rejection."""

import numpy as np

from array_type_conversion import conversion_examples, whole_minutes_to_int16


def run_checks():
    e = conversion_examples()
    assert e["counts"].tolist() == [20, 30] and e["counts"].dtype == np.dtype("int32")
    assert e["durations"].tolist() == [20.0, 30.0]
    assert e["durations"].dtype == np.dtype("float64")
    assert e["durations"] is not e["counts"]
    assert e["promoted"].tolist() == [20.5, 30.25]
    assert e["promoted"].dtype == np.dtype("float64")
    assert e["truncated"].tolist() == [2, -2]
    assert e["boolean"].tolist() == [False, True, True]
    assert e["boolean"].dtype == np.dtype("bool")
    assert e["strings"].dtype.kind == "U"
    assert e["parsed"].tolist() == [10, 20]
    assert e["objects"].dtype == np.dtype("object")
    assert e["objects"].tolist() == [1, "2"]
    assert e["wrapped"].tolist() == [-128, 44]
    assert e["underflowed"].tolist() == [0.0]
    assert e["imprecise"].tolist() == [16_777_216.0]

    original = np.array([15.0, 25.0, 35.0], dtype=np.float64)
    converted = whole_minutes_to_int16(original)
    assert converted.tolist() == [15, 25, 35]
    assert converted.dtype == np.dtype("int16")
    assert (converted.itemsize, converted.nbytes) == (2, 6)
    assert original.tolist() == [15.0, 25.0, 35.0]
    assert (original.itemsize, original.nbytes) == (8, 24)
    assert whole_minutes_to_int16([-32768, 32767]).tolist() == [-32768, 32767]
    for values, expected in [
        ([15.0, 25.5, 35.0], "whole-minute"),
        ([15.0, 40_000.0, 35.0], "outside int16"),
        ([15.0, float("nan"), 35.0], "finite"),
        ([15.0, float("inf"), 35.0], "finite"),
    ]:
        try:
            whole_minutes_to_int16(values)
        except ValueError as error:
            assert expected in str(error)
        else:
            raise AssertionError(f"Expected rejection for {values!r}")

    try:
        np.array(["10", "unknown"]).astype(np.int32)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected string parsing failure")
    try:
        np.array([128], dtype=np.int16).astype(np.int8, casting="safe")
    except TypeError:
        pass
    else:
        raise AssertionError("Expected unsafe dtype cast failure")
    print("All array-type conversion checks passed.")


if __name__ == "__main__":
    run_checks()
