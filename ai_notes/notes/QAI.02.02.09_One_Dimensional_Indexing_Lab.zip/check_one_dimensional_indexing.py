"""Check index pairs, boundaries, updates, and source preservation."""

import numpy as np

from one_dimensional_indexing import read_at, study_minutes, updated_copy


def run_checks():
    source = study_minutes()
    assert source.shape == (4,) and source.size == 4
    assert source.dtype == np.dtype("int32")
    assert source.tolist() == [12, 18, 15, 20]
    for positive, negative, expected in [
        (0, -4, 12), (1, -3, 18), (2, -2, 15), (3, -1, 20),
    ]:
        assert read_at(source, positive) == expected
        assert read_at(source, negative) == expected

    corrected = updated_copy(source, 2, 17)
    assert corrected is not source
    corrected[-1] = 22
    assert corrected.tolist() == [12, 18, 17, 22]
    assert source.tolist() == [12, 18, 15, 20]
    assert corrected.shape == source.shape and corrected.size == source.size
    controlled = updated_copy(source, 2, 19)
    assert read_at(controlled, 2) == read_at(controlled, -2) == 19
    assert read_at(source, 2) == 15

    for index in (4, -5):
        try:
            read_at(source, index)
        except IndexError:
            pass
        else:
            raise AssertionError(f"Expected out-of-bounds read for {index}")
        try:
            updated_copy(source, index, 99)
        except IndexError:
            pass
        else:
            raise AssertionError(f"Expected out-of-bounds update for {index}")
    assert source.tolist() == [12, 18, 15, 20]
    empty = np.array([], dtype=np.int32)
    for index in (0, -1):
        try:
            read_at(empty, index)
        except IndexError:
            pass
        else:
            raise AssertionError("Empty array should have no valid index")
    print("All one-dimensional indexing checks passed.")


if __name__ == "__main__":
    run_checks()
