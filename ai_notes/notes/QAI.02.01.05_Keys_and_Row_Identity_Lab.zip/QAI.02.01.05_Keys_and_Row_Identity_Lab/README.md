# QAI.02.01.05 — Keys and row identity

## Purpose

Learn row identification and key rules with an in-memory SQLite catalogue. Python's standard library is sufficient; no installation, account, external connection, or persistent database is needed. Example email addresses use the reserved `.invalid` domain and are not real user accounts.

## Run

Open a terminal in this folder:

```text
python db_keys.py
python check_keys.py
python db_keys.py --add-learner
```

If your machine uses `python3`, use that name instead. The first command displays 2 learners, 2 courses, 3 enrolments, and learners Anu and Ravi in course 101. The checker displays five rejected inserts and `Checks passed: 5`. The last command displays 3 learners, 2 courses, 4 enrolments, with the same course 101 learner list.

See the companion `QAI.02.01.05_Keys_and_Row_Identity_Notes.md` for term-by-term explanations, the solution to an independent extension, and why `PRAGMA foreign_keys = ON` must be set per SQLite connection.

## Evidence to keep

- A short explanation of why `(1,101)` and `(1,102)` are different enrolments.
- The output of the baseline, five rejection checks, and `--add-learner`.
- The schema lines declaring primary, unique, not-null and foreign-key rules.
- An independent copy of the project extended with course 103 and its valid enrolment, plus its new count outputs.

## Limits

This is a teaching project: fake people, no authentication, no concurrent enrolment operation, no long-lived database, and no claim that a student's email remains unique forever. Review domain and security rules before building an actual enrolment product.
