"""Check labels, cell values, dtypes, and four constructions."""

import pandas as pd

from dataframe_fundamentals import make_examples


def main():
    learners, from_rows, from_lists, from_array = make_examples()
    assert isinstance(learners, pd.DataFrame)
    assert learners.shape == (2, 2)
    assert learners.ndim == 2
    assert learners.index.tolist() == ["L1", "L2"]
    assert learners.columns.tolist() == ["name", "score"]
    assert learners.loc["L1", "name"] == "Asha"
    assert learners.loc["L2", "score"] == 9
    assert pd.api.types.is_integer_dtype(learners["score"].dtype)
    assert not pd.api.types.is_integer_dtype(learners["name"].dtype)
    assert from_rows.equals(learners)
    assert from_lists.equals(learners)
    assert from_array.shape == (2, 2)
    assert from_array.index.tolist() == ["L1", "L2"]
    assert from_array.columns.tolist() == ["score", "tasks"]
    assert from_array.loc["L2", "tasks"] == 3
    assert str(from_array["score"].dtype) == "int32"

    try:
        pd.DataFrame({"name": ["Asha", "Bala"], "score": [7, 9, 8]})
    except ValueError:
        pass
    else:
        raise AssertionError("Columns with unequal lengths must fail.")
    try:
        learners.loc["L3", "score"]
    except KeyError:
        pass
    else:
        raise AssertionError("An unknown row label must fail.")
    print("All checks passed.")


if __name__ == "__main__":
    main()
