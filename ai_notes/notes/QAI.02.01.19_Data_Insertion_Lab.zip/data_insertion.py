"""Practice single, multiple, query-based, and default-only SQLite inserts."""

import sqlite3


SEED = [
    (101, "AI Foundations", 7, 95, 4, "intro", 20, "published"),
    (102, "Git Basics", 8, 50, 3, None, None, "published"),
    (103, "Data Basics", 7, 80, 4, "tables", 30, "published"),
    (104, "Python Basics", 8, 65, 3, None, None, "published"),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT,
            practice_minutes INTEGER,
            status TEXT NOT NULL DEFAULT 'draft'
        )"""
    )
    db.execute(
        """CREATE TABLE long_course_archive (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            duration_minutes INTEGER NOT NULL
        )"""
    )
    db.execute(
        """CREATE TABLE review_queue (
            queue_id INTEGER PRIMARY KEY,
            state TEXT NOT NULL DEFAULT 'pending',
            attempts INTEGER NOT NULL DEFAULT 0
        )"""
    )
    db.executemany(
        "INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?, ?, ?)", SEED
    )
    db.commit()
    return db


def add_one(db):
    db.execute(
        """INSERT INTO course_catalogue
           (course_id, title, instructor_id, duration_minutes, lesson_count)
           VALUES (?, ?, ?, ?, ?)""",
        (105, "SQL Basics", 7, 70, 3),
    )
    db.commit()


def add_two(db):
    db.execute(
        """INSERT INTO course_catalogue
           (course_id, title, instructor_id, duration_minutes, lesson_count)
           VALUES (106, 'Query Practice', 8, 45, 2),
                  (107, 'Data Visuals', 9, 60, 3)"""
    )
    db.commit()


def copy_long_courses(db):
    """Copy selected source values into a three-column archive."""
    db.execute(
        """INSERT INTO long_course_archive (course_id, title, duration_minutes)
           SELECT course_id, title, duration_minutes
           FROM course_catalogue
           WHERE duration_minutes >= 80"""
    )
    db.commit()


def add_queue_default(db):
    db.execute("INSERT INTO review_queue DEFAULT VALUES")
    db.commit()


def independent_variation(db):
    """A learner can re-create this insert with an explicit status."""
    db.execute(
        """INSERT INTO course_catalogue
           (course_id, title, instructor_id, duration_minutes, lesson_count, status)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (108, "Linux Basics", 9, 55, 2, "published"),
    )
    db.commit()


def new_rows(db):
    return db.execute(
        """SELECT course_id, title, topic_note, practice_minutes, status
           FROM course_catalogue WHERE course_id >= 105 ORDER BY course_id"""
    ).fetchall()


def main():
    with make_connection() as db:
        add_one(db)
        add_two(db)
        copy_long_courses(db)
        add_queue_default(db)
        print("After three new courses:", new_rows(db))
        print("Archive:", db.execute(
            "SELECT * FROM long_course_archive ORDER BY course_id"
        ).fetchall())
        print("Default queue row:", db.execute(
            "SELECT * FROM review_queue ORDER BY queue_id"
        ).fetchall())
        independent_variation(db)
        print("Independent row:", new_rows(db)[-1])
        print("Original four retained:", db.execute(
            "SELECT * FROM course_catalogue WHERE course_id <= 104 ORDER BY course_id"
        ).fetchall() == SEED)


if __name__ == "__main__":
    main()
