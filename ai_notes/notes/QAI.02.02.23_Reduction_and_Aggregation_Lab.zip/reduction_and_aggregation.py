"""Summarize a table across the whole array or a selected axis."""

import numpy as np


def make_counts():
    return np.array([[1, 2, 3], [4, 5, 6]])


def main():
    counts = make_counts()
    print("Whole sum and mean:", np.sum(counts), np.mean(counts))
    print("Row sums:", np.sum(counts, axis=1).tolist())
    print("Column sums:", np.sum(counts, axis=0).tolist())
    print("Row means:", np.mean(counts, axis=1).tolist())
    print("Column means:", np.mean(counts, axis=0).tolist())
    print("Min, max, median:", np.min(counts), np.max(counts), np.median(counts))
    print("Row min and max:", np.min(counts, axis=1).tolist(),
          np.max(counts, axis=1).tolist())
    print("Column max:", np.max(counts, axis=0).tolist())
    print("Row median:", np.median(counts, axis=1).tolist())
    print("Row variance:", np.round(np.var(counts, axis=1), 3).tolist())
    print("Row std:", np.round(np.std(counts, axis=1), 3).tolist())
    print("Flat min and max positions:", np.argmin(counts), np.argmax(counts))
    print("Row min and max positions:", np.argmin(counts, axis=1).tolist(),
          np.argmax(counts, axis=1).tolist())
    print("Running sum by row:", np.cumsum(counts, axis=1).tolist())
    print("Running product by row:", np.cumprod(counts, axis=1).tolist())
    print("Running sum by column:", np.cumsum(counts, axis=0).tolist())
    changed = counts.copy()
    changed[1, 2] = 9
    print("Variation:", np.sum(changed, axis=1)[1],
          np.sum(changed, axis=0)[2], np.max(changed, axis=1)[1],
          "original:", counts[1, 2])


if __name__ == "__main__":
    main()
