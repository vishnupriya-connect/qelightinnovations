"""Check compatible counts, data order, storage relationships, and errors."""

import numpy as np

from array_reshaping import (
    controlled_eight_values, flatten_examples, reshaped_examples,
    resize_on_fresh_array, shape_assignment_on_fresh_array, source_values,
)


def run_checks():
    source, two_three, three_two, inferred = reshaped_examples()
    assert source.shape == (6,) and source.size == 6
    assert two_three.shape == (2, 3)
    assert two_three.tolist() == [[10, 20, 30], [40, 50, 60]]
    assert three_two.shape == (3, 2)
    assert three_two.tolist() == [[10, 20], [30, 40], [50, 60]]
    assert inferred.shape == (2, 3) and inferred.tolist() == two_three.tolist()
    assert all(a.size == source.size for a in (two_three, three_two, inferred))
    assert source.shape == (6,)
    assert two_three is not source and np.shares_memory(two_three, source)
    for shape in ((4, 2), (-1, -1)):
        try:
            source.reshape(shape)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Expected incompatible shape: {shape}")

    table, copied, raveled, skipped, skipped_raveled = flatten_examples()
    expected = [10, 20, 30, 40, 50, 60]
    assert copied.tolist() == raveled.tolist() == expected
    assert copied.shape == raveled.shape == (6,)
    assert not np.shares_memory(copied, table)
    assert np.shares_memory(raveled, table)  # This supplied table is contiguous.
    assert skipped.tolist() == [[10, 30], [40, 60]]
    assert skipped_raveled.tolist() == [10, 30, 40, 60]
    assert not np.shares_memory(skipped_raveled, skipped)
    copied[0] = 99
    assert int(table[0, 0]) == 10
    raveled[0] = 11
    assert int(table[0, 0]) == 11

    grown = resize_on_fresh_array()
    assert grown.shape == (2, 4) and grown.size == 8
    assert grown.tolist() == [[10, 20, 30, 40], [50, 60, 0, 0]]
    assigned = shape_assignment_on_fresh_array()
    assert assigned.shape == (3, 2) and assigned.size == 6
    assert assigned.tolist() == [[10, 20], [30, 40], [50, 60]]
    assert np.resize(source_values(), (2, 4)).tolist() == [
        [10, 20, 30, 40], [50, 60, 10, 20],
    ]

    eight, reshaped = controlled_eight_values()
    assert eight.shape == (8,) and reshaped.shape == (2, 4)
    assert reshaped.tolist() == [[1, 2, 3, 4], [5, 6, 7, 8]]
    try:
        eight.reshape(3, -1)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected incompatible eight-value reshape")
    print("All array-reshaping checks passed.")


if __name__ == "__main__":
    run_checks()
