# Series fundamentals lab

Run from this folder:

```bash
python -m pip install -r requirements.txt
python series_fundamentals.py
python check_series_fundamentals.py
python mini_project_reference.py
```

Before running, predict Tuesday's value, the first two values, and the days retained by the `>= 20` filter. Try changing Wednesday's value to 19, then restore it to 20 before running the checker. The mini-project reference solves the reading-pages task in the notes.
