"""Local SQLite example of one-to-one, one-to-many and many-to-many links."""

import argparse
import sqlite3


def open_database():
    connection = sqlite3.connect(":memory:")
    connection.execute("PRAGMA foreign_keys = ON")
    if connection.execute("PRAGMA foreign_keys").fetchone() != (1,):
        connection.close()
        raise RuntimeError("SQLite foreign-key enforcement unavailable")
    return connection


def create_tables(connection):
    connection.executescript(
        """
        CREATE TABLE learners (
            learner_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL
        );
        CREATE TABLE profiles (
            learner_id INTEGER PRIMARY KEY
                REFERENCES learners(learner_id),
            bio TEXT NOT NULL
        );
        CREATE TABLE courses (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            capacity INTEGER NOT NULL
        );
        CREATE TABLE lessons (
            lesson_id INTEGER PRIMARY KEY,
            course_id INTEGER NOT NULL
                REFERENCES courses(course_id),
            title TEXT NOT NULL
        );
        CREATE TABLE enrolments (
            learner_id INTEGER NOT NULL
                REFERENCES learners(learner_id),
            course_id INTEGER NOT NULL
                REFERENCES courses(course_id),
            PRIMARY KEY (learner_id, course_id)
        );
        """
    )


def seed(connection):
    connection.executemany(
        "INSERT INTO learners (learner_id, name) VALUES (?, ?)",
        [(1, "Anu"), (2, "Ravi"), (3, "Meera")],
    )
    connection.execute(
        "INSERT INTO profiles (learner_id, bio) VALUES (?, ?)",
        (1, "Interested in AI"),
    )
    connection.executemany(
        "INSERT INTO courses (course_id, title, capacity) VALUES (?, ?, ?)",
        [(101, "AI Foundations", 2), (102, "Git Basics", 2)],
    )
    connection.executemany(
        "INSERT INTO lessons (lesson_id, course_id, title) VALUES (?, ?, ?)",
        [
            (1001, 101, "AI tasks"),
            (1002, 101, "Models and data"),
            (1003, 102, "Commits"),
        ],
    )
    connection.executemany(
        "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
        [(1, 101), (1, 102), (2, 101)],
    )


def build_database():
    connection = open_database()
    try:
        create_tables(connection)
        seed(connection)
    except Exception:
        connection.close()
        raise
    return connection


def summary(connection):
    enabled = connection.execute("PRAGMA foreign_keys").fetchone()[0]
    print("Foreign-key enforcement:", "on" if enabled == 1 else "off")
    for name, table in (
        ("Learners", "learners"),
        ("Profiles", "profiles"),
        ("Courses", "courses"),
        ("Lessons", "lessons"),
        ("Enrolments", "enrolments"),
    ):
        count = connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
        print(f"{name}: {count}")
    lesson_count = connection.execute(
        "SELECT COUNT(*) FROM lessons WHERE course_id = ?", (101,)
    ).fetchone()[0]
    names = [
        row[0]
        for row in connection.execute(
            "SELECT learners.name FROM enrolments "
            "JOIN learners ON learners.learner_id = enrolments.learner_id "
            "WHERE enrolments.course_id = ? ORDER BY learners.name",
            (101,),
        )
    ]
    no_profile = [
        row[0] for row in connection.execute(
            "SELECT l.name FROM learners AS l LEFT JOIN profiles AS p "
            "ON l.learner_id = p.learner_id "
            "WHERE p.learner_id IS NULL ORDER BY l.name"
        )
    ]
    no_enrolment = [
        row[0] for row in connection.execute(
            "SELECT l.name FROM learners AS l LEFT JOIN enrolments AS e "
            "ON l.learner_id = e.learner_id "
            "WHERE e.learner_id IS NULL ORDER BY l.name"
        )
    ]
    print("Course 101 lessons:", lesson_count)
    print("Course 101 learners:", ", ".join(names))
    print("Learners without profiles:", ", ".join(no_profile))
    print("Learner without enrolments:", ", ".join(no_enrolment))


def main():
    parser = argparse.ArgumentParser(description="Local relationship model")
    parser.add_argument("--enrol-ravi-in-git", action="store_true")
    args = parser.parse_args()
    connection = build_database()
    try:
        if args.enrol_ravi_in_git:
            connection.execute(
                "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
                (2, 102),
            )
        summary(connection)
    finally:
        connection.close()


if __name__ == "__main__":
    main()
