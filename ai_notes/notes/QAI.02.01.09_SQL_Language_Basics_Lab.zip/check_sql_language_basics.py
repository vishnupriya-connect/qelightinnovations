"""Reference checks for the SQL language basics lab."""

import sqlite3

from sql_language_basics import (
    catalogue_preview,
    independent_variant,
    make_connection,
    run_statement,
)


def main():
    with make_connection() as connection:
        original = connection.execute(
            "SELECT course_id, course_title, instructor_id "
            "FROM courses ORDER BY course_id;"
        ).fetchall()

        names, rows = run_statement(
            connection,
            "SELECT course_id, course_title FROM courses ORDER BY course_id;",
        )
        assert names == ["course_id", "course_title"]
        assert rows == [
            (101, "AI Foundations"),
            (102, "Git Basics"),
            (103, "Data Basics"),
        ]

        changed_names, changed_rows = run_statement(
            connection,
            "SELECT course_id, instructor_id FROM courses ORDER BY course_id;",
        )
        assert changed_names == ["course_id", "instructor_id"]
        assert changed_rows[0] == (101, 7) and changed_rows[-1] == (103, 9)

        literal_names, literal_rows = run_statement(
            connection,
            "SELECT course_title, 'course' AS item_type, 1 AS example_count "
            "FROM courses ORDER BY course_id;",
        )
        assert literal_names == ["course_title", "item_type", "example_count"]
        assert literal_rows[0] == ("AI Foundations", "course", 1)

        preview_names, preview_rows = catalogue_preview(connection)
        assert preview_names == ["course_id", "label", "item_type"]
        assert preview_rows == [
            (101, "AI Foundations", "course"),
            (102, "Git Basics", "course"),
            (103, "Data Basics", "course"),
        ]

        variant_names, variant_rows = independent_variant(connection)
        assert variant_names == ["course_id", "display_id", "item_type"]
        assert variant_rows == [
            (101, 1101, "course"),
            (102, 1102, "course"),
            (103, 1103, "course"),
        ]

        try:
            connection.execute("SELECT course_name FROM courses;").fetchall()
        except sqlite3.OperationalError as exc:
            assert "no such column" in str(exc)
            assert connection.execute(
                "SELECT course_title FROM courses ORDER BY course_id;"
            ).fetchone() == ("AI Foundations",)
        else:
            raise AssertionError("A missing column should produce an error")

        untrusted_text = "AI'; DROP TABLE courses; --"
        supplied_names, supplied_rows = run_statement(
            connection, "SELECT ? AS supplied;", (untrusted_text,)
        )
        assert supplied_names == ["supplied"]
        assert supplied_rows == [(untrusted_text,)]
        assert connection.execute("SELECT COUNT(*) FROM courses;").fetchone() == (3,)

        after = connection.execute(
            "SELECT course_id, course_title, instructor_id "
            "FROM courses ORDER BY course_id;"
        ).fetchall()
        assert original == after

        print("Checks passed: 8")
        print("Corrected identifier: course_title")
        print("Bound value left the table intact: True")


if __name__ == "__main__":
    main()
