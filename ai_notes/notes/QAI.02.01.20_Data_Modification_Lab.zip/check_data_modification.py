"""Check selected changes, unaffected rows, zero matches, and isolated broad changes."""

from data_modification import (
    SEED, independent_variation, make_connection, project_changes, rows,
    selected_update_demo, truncate_demo, whole_table_delete_demo,
    whole_table_update_demo,
)


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == SEED
        assert db.execute(
            "SELECT course_id FROM course_catalogue WHERE status='draft' ORDER BY course_id"
        ).fetchall() == [(105,), (106,)]
        assert selected_update_demo(db) == 2
        assert db.execute(
            "SELECT course_id, status FROM course_catalogue ORDER BY course_id"
        ).fetchall() == [
            (101, "published"), (102, "published"), (103, "published"),
            (104, "published"), (105, "review"), (106, "review"),
        ]
        print("Update condition selects exactly two rows: correct")

    with make_connection() as db:
        assert project_changes(db) == (1, 1)
        assert rows(db) == [
            (101, "AI Foundations", 4, "intro", "published"),
            (102, "Git Basics", 3, None, "published"),
            (103, "Data Basics", 4, "tables", "published"),
            (104, "Python Basics", 3, None, "published"),
            (105, "SQL Basics", 3, "queries", "published"),
        ]
        assert db.execute(
            "DELETE FROM course_catalogue WHERE course_id = ?", (999,)
        ).rowcount == 0
        db.commit()
        assert len(rows(db)) == 5
        print("Project update, delete and zero-match deletion: correct")

        assert independent_variation(db) == 2
        assert db.execute(
            "SELECT course_id, lesson_count FROM course_catalogue ORDER BY course_id"
        ).fetchall() == [(101, 4), (102, 4), (103, 4), (104, 4), (105, 3)]
        print("Independent selected update and unaffected rows: correct")

    assert whole_table_update_demo() == (6, [("archived",)])
    assert whole_table_delete_demo() == (6, 0)
    error, remaining = truncate_demo()
    assert "TRUNCATE" in error.upper()
    assert remaining == 6
    print("Unrestricted changes isolated; SQLite TRUNCATE rejected: correct")


if __name__ == "__main__":
    main()
