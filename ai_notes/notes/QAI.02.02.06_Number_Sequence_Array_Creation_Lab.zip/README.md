# Number-sequence array creation lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python number_sequences.py
python check_number_sequences.py
```

Use `python3` if needed. Predict the first, last, and count of each sequence before running. Complete the independent checkpoint plans, then compare with `python mini_project_reference.py`. This lab was checked with NumPy 2.3.5. Floating-point checks use a numerical tolerance rather than exact equality.
