# Sorting and limiting lab

From this unzipped folder, run:

```sh
python sorting_limiting.py
python check_sorting_limiting.py
```

Use `python3` if needed. The standard-library `sqlite3` module creates an in-memory catalogue. Predict row IDs before running. Change the sort direction, then change page size and offset and explain which rows move between pages. Attempt the mini-project and independent variation in your own query before inspecting the supplied reference functions. Run the checker for the provided examples, then compare your own query output with your prediction.
