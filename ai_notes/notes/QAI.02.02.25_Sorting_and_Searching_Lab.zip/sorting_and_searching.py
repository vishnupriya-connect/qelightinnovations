"""Compare ordered values, original indices, and insertion positions."""

import numpy as np


def make_examples():
    scores = np.array([40, 10, 30, 20])
    table = np.array([[4, 1, 3], [2, 6, 5]])
    repeated = np.array([3, 1, 3, 2, 1])
    return scores, table, repeated


def contains(sorted_values, target):
    """Check membership separately from an insertion position."""
    position = int(np.searchsorted(sorted_values, target))
    return position < sorted_values.size and sorted_values[position] == target


def main():
    scores, table, repeated = make_examples()
    ordered = np.sort(scores)
    print("Ascending:", ordered.tolist(), "original:", scores.tolist())
    print("Descending:", ordered[::-1].tolist())
    editable = scores.copy()
    returned = editable.sort()
    print("In-place:", editable.tolist(), "return:", returned)
    print("Sort rows:", np.sort(table, axis=1).tolist())
    print("Sort columns:", np.sort(table, axis=0).tolist())
    positions = np.argsort(scores)
    print("Original positions in sorted order:", positions.tolist())
    print("Recovered values:", scores[positions].tolist())
    print("Where >= 30:", np.where(scores >= 30)[0].tolist())
    rows, columns = np.where(table >= 5)
    print("Table coordinates:", rows.tolist(), columns.tolist())
    print("Nonzero flags:", np.nonzero([0, 7, 0, 9])[0].tolist())
    print("Insert 15, 30, 50:", np.searchsorted(ordered, [15, 30, 50]).tolist())
    print("30 left/right:", np.searchsorted(ordered, 30, side="left"),
          np.searchsorted(ordered, 30, side="right"))
    print("Contains 15 / 30:", bool(contains(ordered, 15)),
          bool(contains(ordered, 30)))
    print("Unique:", np.unique(repeated).tolist())
    changed = scores.copy()
    changed[0] = 5
    print("Variation:", np.sort(changed).tolist(),
          np.argsort(changed).tolist(), np.where(changed >= 30)[0].tolist(),
          "original:", scores.tolist())


if __name__ == "__main__":
    main()
