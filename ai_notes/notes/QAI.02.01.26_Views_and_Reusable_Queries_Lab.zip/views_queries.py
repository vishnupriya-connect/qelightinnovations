"""Small SQLite view and snapshot examples; run with Python's standard library."""

import sqlite3


def make_db():
    db = sqlite3.connect(":memory:")
    db.executescript("""
        CREATE TABLE courses (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            duration_minutes INTEGER NOT NULL,
            active INTEGER NOT NULL CHECK (active IN (0, 1))
        );
        INSERT INTO courses VALUES
            (101, 'AI Foundations', 95, 1),
            (102, 'Git Basics', 50, 1),
            (103, 'Data Basics', 80, 1),
            (104, 'Python Basics', 65, 1),
            (105, 'SQL Basics', 70, 1),
            (106, 'Archived Basics', 120, 0);
    """)
    return db


def create_learning_view(db, threshold=70):
    # Identifiers and schema are fixed here; threshold is an internal integer.
    if type(threshold) is not int or threshold < 0:
        raise ValueError("threshold must be a nonnegative integer")
    db.execute(f"""
        CREATE VIEW learning_courses (course_id, title, duration_minutes) AS
        SELECT course_id, title, duration_minutes
        FROM courses
        WHERE active = 1 AND duration_minutes >= {threshold}
    """)


def learning_rows(db):
    return db.execute("""
        SELECT course_id, title, duration_minutes
        FROM learning_courses ORDER BY course_id
    """).fetchall()


def report(db):
    return db.execute("""
        SELECT COUNT(*), SUM(duration_minutes)
        FROM learning_courses
    """).fetchone()


def replace_learning_view(db, threshold=80):
    # SQLite has no CREATE OR REPLACE VIEW. Dependents should be reviewed first.
    db.execute("DROP VIEW learning_courses")
    create_learning_view(db, threshold)


def create_snapshot(db):
    db.execute("""
        CREATE TABLE learning_snapshot AS
        SELECT course_id, title, duration_minutes
        FROM learning_courses
    """)


def snapshot_rows(db):
    return db.execute("""
        SELECT course_id, title, duration_minutes
        FROM learning_snapshot ORDER BY course_id
    """).fetchall()


def refresh_snapshot(db):
    db.execute("DELETE FROM learning_snapshot")
    db.execute("""
        INSERT INTO learning_snapshot (course_id, title, duration_minutes)
        SELECT course_id, title, duration_minutes FROM learning_courses
    """)


def short_course_view(db):
    db.execute("""
        CREATE VIEW short_courses (course_id, title) AS
        SELECT course_id, title FROM courses
        WHERE active = 1 AND duration_minutes < 70
    """)
    return db.execute("SELECT course_id, title FROM short_courses ORDER BY course_id").fetchall()


def main():
    db = make_db()
    create_learning_view(db)
    print("Initial view:", learning_rows(db))
    print("Initial report:", report(db))
    create_snapshot(db)
    db.execute("UPDATE courses SET duration_minutes = 85 WHERE course_id = 104")
    print("After source update, view:", learning_rows(db))
    print("After source update, snapshot:", snapshot_rows(db))
    print("Updated report:", report(db))
    replace_learning_view(db)
    print("After definition change:", learning_rows(db))
    print("Independent short-course view:", short_course_view(db))
    refresh_snapshot(db)
    print("After explicit snapshot refresh:", snapshot_rows(db))
    db.execute("DROP VIEW IF EXISTS learning_courses")
    print("Base table row count after drop:", db.execute("SELECT COUNT(*) FROM courses").fetchone()[0])
    db.close()


if __name__ == "__main__":
    main()
