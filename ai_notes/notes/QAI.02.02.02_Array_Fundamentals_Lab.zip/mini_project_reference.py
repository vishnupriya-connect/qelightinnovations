"""Read after attempting the two-learner workshop task yourself."""

import numpy as np

from array_fundamentals import describe, learner_total, revise_value


def main():
    workshop = np.array([[12, 8, 5], [10, 15, 5]], dtype=np.int32)
    print("Type:", type(workshop).__name__)
    print("Properties:", describe(workshop))
    print("Selected value:", int(workshop[1, 1]))
    print("Second learner total:", learner_total(workshop, 1))

    revised = revise_value(workshop, 0, 2, 9)
    print("First learner original total:", learner_total(workshop, 0))
    print("First learner revised total:", learner_total(revised, 0))
    try:
        _ = workshop[2, 0]
    except IndexError as error:
        print("Invalid index:", type(error).__name__, "; valid first indexes: 0, 1")


if __name__ == "__main__":
    main()
