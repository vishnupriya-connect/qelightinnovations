"""Check subquery shapes, correlations, quantified comparisons, and projects."""

import sqlite3

from subqueries import (
    COURSES, INSTRUCTORS, TAGS, above_average, greater_than_all_peers,
    greater_than_any_peer, independent_variation, make_connection,
    nested_example, project_candidates, selected_instructors, starter_courses,
    untagged_courses,
)


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall() == INSTRUCTORS
        assert db.execute(
            "SELECT * FROM course_tags ORDER BY course_id, tag"
        ).fetchall() == sorted(TAGS)

        assert db.execute(
            "SELECT AVG(duration_minutes) FROM course_catalogue"
        ).fetchone() == (72.0,)
        assert above_average(db) == [101, 103]
        assert selected_instructors(db) == [101, 103]
        assert nested_example(db) == [101, 103]
        assert db.execute("SELECT (SELECT instructor_name FROM instructors WHERE instructor_id=99)").fetchone() == (None,)
        print("Scalar, multi-row, nested and empty scalar subqueries: correct")

        assert starter_courses(db) == [101, 102, 104]
        assert untagged_courses(db) == [103, 105]
        assert db.execute(
            "SELECT course_id FROM course_catalogue WHERE "
            "EXISTS (SELECT 1 FROM instructors WHERE instructor_id=9) "
            "ORDER BY course_id"
        ).fetchall() == [(101,), (102,), (103,), (104,), (105,)]
        print("Correlated and uncorrelated EXISTS; NOT EXISTS: correct")

        assert greater_than_any_peer(db) == [101, 103, 104, 105]
        assert greater_than_all_peers(db) == [101, 103, 105]
        assert greater_than_any_peer(db, 99) == []
        assert greater_than_all_peers(db, 99) == [101, 102, 103, 104, 105]
        for sql in (
            "SELECT 5 > ANY (SELECT 3)",
            "SELECT 5 > ALL (SELECT 3)",
        ):
            try:
                db.execute(sql).fetchall()
            except sqlite3.OperationalError:
                pass
            else:
                raise AssertionError("SQLite unexpectedly accepted quantified syntax")
        print("ANY/ALL meaning, empty-set boundaries, SQLite syntax: correct")

        assert project_candidates(db) == [(101, "AI Foundations", 95)]
        assert independent_variation(db) == [103, 105]
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall() == INSTRUCTORS
        assert db.execute(
            "SELECT * FROM course_tags ORDER BY course_id, tag"
        ).fetchall() == sorted(TAGS)
        print("Mini-project, independent variation, unchanged tables: correct")


if __name__ == "__main__":
    main()
