"""Verify all operations, row-level distinctness, compatible columns, and projects."""

import sqlite3

from set_operations import (
    CORE, COURSES, PRACTICE, independent_variation, labeled_union,
    make_connection, one_column, project_shared,
)


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute("SELECT * FROM core_candidates ORDER BY course_id").fetchall() == sorted(CORE)
        assert db.execute("SELECT * FROM practice_candidates ORDER BY course_id").fetchall() == sorted(PRACTICE)
        assert one_column(db, "UNION") == [101, 102, 103, 104, 105]
        assert one_column(db, "UNION ALL") == [
            101, 102, 103, 103, 103, 104, 104, 105, 105
        ]
        assert one_column(db, "INTERSECT") == [103, 105]
        assert one_column(db, "EXCEPT") == [101]
        assert one_column(db, "EXCEPT", reverse=True) == [102, 104]
        print("Union, all, intersection and both differences: correct")

        assert labeled_union(db) == [
            (101, "core"), (102, "practice"),
            (103, "core"), (103, "practice"),
            (104, "practice"), (105, "core"), (105, "practice"),
        ]
        assert db.execute("SELECT NULL UNION SELECT NULL").fetchall() == [(None,)]
        assert db.execute("SELECT NULL UNION ALL SELECT NULL").fetchall() == [
            (None,), (None,)
        ]
        print("Duplicate removal uses full row, including NULL and labels: correct")

        try:
            db.execute(
                "SELECT course_id FROM core_candidates UNION "
                "SELECT course_id, title FROM course_catalogue"
            ).fetchall()
        except sqlite3.OperationalError as exc:
            assert "same number" in str(exc).lower()
        else:
            raise AssertionError("Different column counts should have failed")
        print("Incompatible result-column counts rejected: correct")

        assert project_shared(db) == [
            (103, "Data Basics"), (105, "SQL Basics")
        ]
        assert independent_variation(db) == [
            (102, "Git Basics"), (104, "Python Basics")
        ]
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        print("Mini-project, variation, and unchanged course rows: correct")


if __name__ == "__main__":
    main()
