"""Demonstrate targeted and unrestricted SQLite changes on private tables."""

import sqlite3


SEED = [
    (101, "AI Foundations", 7, 95, 4, "intro", 20, "published"),
    (102, "Git Basics", 8, 50, 3, None, None, "published"),
    (103, "Data Basics", 7, 80, 4, "tables", 30, "published"),
    (104, "Python Basics", 8, 65, 3, None, None, "published"),
    (105, "SQL Basics", 7, 70, 3, None, None, "draft"),
    (106, "Query Practice", 8, 45, 2, None, None, "draft"),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT,
            practice_minutes INTEGER,
            status TEXT NOT NULL DEFAULT 'draft'
        )"""
    )
    db.executemany(
        "INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?, ?, ?)", SEED
    )
    db.commit()
    return db


def rows(db):
    return db.execute(
        """SELECT course_id, title, lesson_count, topic_note, status
           FROM course_catalogue ORDER BY course_id"""
    ).fetchall()


def project_changes(db):
    """Correct course 105 and remove the obsolete course 106."""
    updated = db.execute(
        """UPDATE course_catalogue
           SET topic_note = ?, status = ?
           WHERE course_id = ?""",
        ("queries", "published", 105),
    ).rowcount
    deleted = db.execute(
        "DELETE FROM course_catalogue WHERE course_id = ?", (106,)
    ).rowcount
    db.commit()
    return updated, deleted


def selected_update_demo(db):
    """Update both draft rows while leaving published rows alone."""
    changed = db.execute(
        "UPDATE course_catalogue SET status = ? WHERE status = ?",
        ("review", "draft"),
    ).rowcount
    db.commit()
    return changed


def independent_variation(db):
    """After the project, increase lessons for instructor 8's surviving rows."""
    changed = db.execute(
        """UPDATE course_catalogue
           SET lesson_count = lesson_count + 1
           WHERE instructor_id = ?""",
        (8,),
    ).rowcount
    db.commit()
    return changed


def whole_table_update_demo():
    with make_connection() as db:
        changed = db.execute(
            "UPDATE course_catalogue SET status = 'archived'"
        ).rowcount
        db.commit()
        statuses = db.execute(
            "SELECT DISTINCT status FROM course_catalogue"
        ).fetchall()
        return changed, statuses


def whole_table_delete_demo():
    with make_connection() as db:
        changed = db.execute("DELETE FROM course_catalogue").rowcount
        db.commit()
        return changed, db.execute(
            "SELECT COUNT(*) FROM course_catalogue"
        ).fetchone()[0]


def truncate_demo():
    with make_connection() as db:
        try:
            db.execute("TRUNCATE TABLE course_catalogue")
        except sqlite3.OperationalError as exc:
            error = str(exc)
        else:
            raise AssertionError("SQLite unexpectedly accepted TRUNCATE TABLE")
        remaining = db.execute(
            "SELECT COUNT(*) FROM course_catalogue"
        ).fetchone()[0]
        return error, remaining


def main():
    with make_connection() as db:
        print("Preview project IDs:", db.execute(
            "SELECT course_id FROM course_catalogue WHERE course_id IN (105, 106) "
            "ORDER BY course_id"
        ).fetchall())
        print("Project affected (updated, deleted):", project_changes(db))
        print("Project rows:", rows(db))
        print("Independent update count:", independent_variation(db))
        print("Independent rows:", rows(db))
    print("All-row update on a fresh table:", whole_table_update_demo())
    print("All-row delete on a fresh table:", whole_table_delete_demo())
    print("SQLite TRUNCATE attempt:", truncate_demo())


if __name__ == "__main__":
    main()
