# Missing and special numerical values lab

Run with Python 3:

```bash
python -m pip install -r requirements.txt
python missing_and_special_values.py
python check_missing_and_special_values.py
python mini_project_reference.py
```

Predict each detection mask before running. The numeric replacements for infinities are illustrative codes, not observed measurements. Try the controlled variation in the companion notes.
