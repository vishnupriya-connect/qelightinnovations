# Special filtering conditions lab

From this unzipped folder, run:

```sh
python special_filters.py
python check_special_filters.py
```

Use `python3` if needed. Python's standard-library `sqlite3` creates an in-memory catalogue; no installation or account is required. Predict each output before running. Change one range boundary and one `LIKE` pattern, record the results, reproduce the `= NULL` and `NOT IN (..., NULL)` traps, then attempt the independent variation before reading its reference function. The checker validates the supplied reference examples; write and check your own query separately.
