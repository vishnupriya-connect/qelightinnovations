"""Check range, replacement, replay, permutations, and invalid sizes."""

import numpy as np

from random_sampling import make_sample


def main():
    first = make_sample()
    second = make_sample()
    assert all(np.array_equal(a, b) for a, b in zip(first[:-1], second[:-1]))
    population, without, with_replacement, dice, fractions, normal_values, permuted, editable, returned = first
    assert population.tolist() == [10, 20, 30, 40]
    assert without.shape == (3,)
    assert np.all(np.isin(without, population))
    assert np.unique(without).size == without.size
    assert with_replacement.shape == (6,)
    assert np.all(np.isin(with_replacement, population))
    assert np.unique(with_replacement).size < with_replacement.size
    assert dice.shape == (5,)
    assert np.all((dice >= 1) & (dice < 7))
    assert fractions.shape == (5,)
    assert np.all((fractions >= 0) & (fractions < 1))
    assert normal_values.shape == (5,)
    assert np.issubdtype(normal_values.dtype, np.floating)
    assert permuted.shape == editable.shape == population.shape
    assert np.array_equal(np.sort(permuted), np.sort(population))
    assert np.array_equal(np.sort(editable), np.sort(population))
    assert returned is None
    assert population.tolist() == [10, 20, 30, 40]
    rng = np.random.default_rng(1)
    four = rng.choice(population, size=4, replace=False)
    assert np.array_equal(np.sort(four), np.sort(population))
    five = rng.choice(population, size=5, replace=True)
    assert five.shape == (5,)
    try:
        rng.choice(population, size=5, replace=False)
    except ValueError:
        pass
    else:
        raise AssertionError("Oversized no-replacement sample was accepted")
    print("All checks passed.")


if __name__ == "__main__":
    main()
