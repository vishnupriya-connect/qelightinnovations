"""Reference solution for validated practice-minute conversion."""

import numpy as np

from array_type_conversion import whole_minutes_to_int16


def main():
    source = np.array([15.0, 25.0, 35.0], dtype=np.float64)
    converted = whole_minutes_to_int16(source)
    for name, array in [("Source", source), ("Validated result", converted)]:
        print(f"{name}: {array.tolist()}, dtype={array.dtype}, itemsize={array.itemsize}, nbytes={array.nbytes}")

    for name, values in [
        ("Fraction", [15.0, 25.5, 35.0]),
        ("Outside range", [15.0, 40_000.0, 35.0]),
        ("Missing/undefined", [15.0, float("nan"), 35.0]),
    ]:
        try:
            whole_minutes_to_int16(values)
        except ValueError as error:
            print(f"{name}: rejected — {error}")

    wide = np.array([128], dtype=np.int16)
    print("Unsafe narrowing:", wide.tolist(), "→", wide.astype(np.int8).tolist())
    print("Repair: retain int16 for this valid source value")


if __name__ == "__main__":
    main()
