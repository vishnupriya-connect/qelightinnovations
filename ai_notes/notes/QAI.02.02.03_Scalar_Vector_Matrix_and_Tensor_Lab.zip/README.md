# Scalar, vector, matrix, and tensor lab

Run the example and checker from this folder:

```sh
python -m pip install -r requirements.txt
python array_dimensions.py
python check_array_dimensions.py
```

Use `python3` if appropriate. Predict each shape and result before running. Complete the two-day workshop mini-project on your own; only then run `python mini_project_reference.py` to compare with the reference. NumPy `2.3.5` was used to check these examples. Print your installation's version with `python -c "import numpy; print(numpy.__version__)"`.
