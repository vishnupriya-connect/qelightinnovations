# Subqueries lab

Run from this unzipped folder with Python 3:

```sh
python subqueries.py
python check_subqueries.py
```

Use `python3` if needed. Python's standard-library `sqlite3` creates private in-memory tables. Predict the result of each inner query before the outer query. Change the instructor key in the ANY/ALL meaning examples to 99 to see empty-set results. Reproduce an incorrect uncorrelated EXISTS condition and repair it. Attempt the project and independent variation before viewing their reference functions. The checker validates the supplied SQLite examples and confirms that this SQLite runtime rejects literal `> ANY` and `> ALL` syntax.
