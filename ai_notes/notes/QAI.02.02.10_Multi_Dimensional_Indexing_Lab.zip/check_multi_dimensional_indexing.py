"""Verify coordinates, result shapes, guarded reads, and copy updates."""

import numpy as np

from multi_dimensional_indexing import corrected_week, read_scalar, study_data


def run_checks():
    work, weeks = study_data()
    assert work.dtype == np.dtype("int32") and work.shape == (2, 3)
    assert read_scalar(work, (1, 1)) == int(work[1, 1]) == 15
    assert read_scalar(work, (0, 1)) == 8
    assert read_scalar(work, (1, 0)) == 10
    assert int(work[-1, -2]) == 15
    assert work[1].tolist() == [10, 15, 5] and work[1].shape == (3,)
    assert work[:, 1].tolist() == [8, 15] and work[:, 1].shape == (2,)

    assert weeks.shape == (2, 2, 3)
    assert read_scalar(weeks, (1, 0, 1)) == 6
    assert int(weeks[-1, 0, 1]) == 6
    assert weeks[1].tolist() == [[14, 6, 5], [12, 10, 8]]
    assert weeks[1].shape == (2, 3)
    assert weeks[1, 0].tolist() == [14, 6, 5]
    assert weeks[1, 0].shape == (3,)
    assert weeks[1, :, 1].tolist() == [6, 10]
    assert weeks[1, :, 1].shape == (2,)

    revised = corrected_week(weeks, (1, 0, 0), 16)
    assert revised is not weeks
    assert revised[1, 0].tolist() == [16, 6, 5]
    assert revised[1, :, 0].tolist() == [16, 12]
    assert int(weeks[1, 0, 0]) == 14
    assert read_scalar(weeks, (0, 1, 1)) == 15
    assert read_scalar(weeks, (1, 0, 1)) == 6

    for coordinate, error_type in [((1, 0), ValueError), ((2, 0, 1), IndexError)]:
        try:
            read_scalar(weeks, coordinate)
        except error_type:
            pass
        else:
            raise AssertionError(f"Expected {error_type.__name__}: {coordinate}")
    assert weeks[1, 0].tolist() == [14, 6, 5]  # NumPy shorter tuple is valid.
    print("All multi-dimensional indexing checks passed.")


if __name__ == "__main__":
    run_checks()
