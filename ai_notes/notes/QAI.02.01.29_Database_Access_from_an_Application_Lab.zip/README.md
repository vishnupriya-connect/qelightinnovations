# Database access from an application lab

Requires Python 3 and the standard-library `sqlite3` module. No server, credentials, third-party package, or network needed.

Run from this extracted folder:

```sh
python application_database.py
python check_application_database.py
```

Use `python3` if needed. Both scripts create a private temporary SQLite file and clean it after running. Predict the `fetchone()` and `fetchall()` results before executing. The small, sequential `DemoPool` teaches bounded borrowing and cleanup; it is not a production or multithreaded pool. Its expected exhaustion is caught in the demo. Save the output and explain why returning an unfinished transaction requires rollback.
