"""Reference checks for retrieval, duplicate rows, and a controlled failure."""

import sqlite3

from retrieval import make_connection, result, teacher_directory


def main():
    with make_connection() as connection:
        original_names, original_rows = result(
            connection,
            "SELECT course_id, title, instructor_id "
            "FROM course_catalogue ORDER BY course_id;",
        )
        assert original_names == ["course_id", "title", "instructor_id"]
        assert original_rows == [
            (101, "AI Foundations", 7),
            (102, "Git Basics", 8),
            (103, "Data Basics", 7),
            (104, "Python Basics", 8),
        ]

        names, rows = result(
            connection,
            "SELECT title, course_id FROM course_catalogue "
            "ORDER BY course_id;",
        )
        assert names == ["title", "course_id"]
        assert rows[0] == ("AI Foundations", 101)
        print("Changing select-list order changed output order: yes")

        all_names, all_rows = result(
            connection,
            "SELECT * FROM course_catalogue ORDER BY course_id;",
        )
        assert all_names == original_names and all_rows == original_rows
        print("Star returned all three columns: yes")

        renamed_names, renamed_rows = result(
            connection,
            "SELECT c.course_id AS id, c.title AS course "
            "FROM course_catalogue AS c ORDER BY c.course_id;",
        )
        assert renamed_names == ["id", "course"]
        assert renamed_rows[0] == (101, "AI Foundations")
        assert original_names == ["course_id", "title", "instructor_id"]
        print("Aliases changed headings, not source names: yes")

        duplicates = result(
            connection,
            "SELECT instructor_id FROM course_catalogue ORDER BY course_id;",
        )[1]
        distinct_one = result(
            connection,
            "SELECT DISTINCT instructor_id FROM course_catalogue "
            "ORDER BY instructor_id;",
        )[1]
        distinct_pair = result(
            connection,
            "SELECT DISTINCT instructor_id, title FROM course_catalogue "
            "ORDER BY instructor_id, title;",
        )[1]
        assert duplicates == [(7,), (8,), (7,), (8,)]
        assert distinct_one == [(7,), (8,)]
        assert len(distinct_pair) == 4
        print("One-column / two-column distinct rows: 2 / 4")

        try:
            connection.execute(
                "SELECT course_name FROM course_catalogue;"
            ).fetchall()
        except sqlite3.OperationalError as exc:
            assert "no such column" in str(exc)
        else:
            raise AssertionError("Missing column should fail")
        repaired = result(
            connection,
            "SELECT title FROM course_catalogue ORDER BY course_id;",
        )[1]
        assert repaired[0] == ("AI Foundations",)
        print("Wrong column corrected: yes")

        directory_names, directory_rows = teacher_directory(connection)
        assert directory_names == ["teacher_id"]
        assert directory_rows == [(7,), (8,)]
        print("Teacher directory: 7, 8")

        assert result(
            connection,
            "SELECT course_id, title, instructor_id "
            "FROM course_catalogue ORDER BY course_id;",
        ) == (original_names, original_rows)
        print("Source rows unchanged: True")


if __name__ == "__main__":
    main()
