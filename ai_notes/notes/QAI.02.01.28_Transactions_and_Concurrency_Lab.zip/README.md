# Transactions and concurrency lab

Requires Python 3 and its standard-library `sqlite3` module. Run from the extracted folder:

```sh
python transactions_concurrency.py
python check_transactions_concurrency.py
```

Use `python3` if needed. Each run creates a SQLite database inside a temporary folder, opens two connections for the concurrency example, and removes the database when finished. No network, credentials, or external packages are needed.

First predict the two balances after a successful transfer and a later failed transfer. Then trace what each connection can see before and after a commit. The output includes a deterministic zero-wait busy case, a retry of the whole seat operation, and a separate single-statement auto-commit example. Save the predictions and the checker output.
