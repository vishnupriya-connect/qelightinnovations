"""Make Boolean masks, select copies, and assign to matching positions."""

import numpy as np


def study_minutes():
    return np.array([10, 25, 30, 15, 40], dtype=np.int32)


def threshold_report(values, threshold, inclusive=True):
    mask = values >= threshold if inclusive else values > threshold
    return mask, values[mask]


def raised_selected_copy(values, threshold, amount):
    updated = values.copy()
    mask = updated >= threshold
    updated[mask] = updated[mask] + amount
    return updated


def task_grid():
    return np.array([[12, 8, 5], [10, 15, 5]], dtype=np.int32)


def main():
    minutes = study_minutes()
    mask, selected = threshold_report(minutes, 25)
    print("Minutes:", minutes.tolist())
    print("At least 25 mask:", mask.tolist(), "dtype:", mask.dtype)
    print("Selected:", selected.tolist(), "shape:", selected.shape)
    print("Between 20 and 35:", minutes[(minutes >= 20) & (minutes <= 35)].tolist())
    print("At least 30:", threshold_report(minutes, 30)[1].tolist())
    print("Greater than 30:", threshold_report(minutes, 30, False)[1].tolist())
    print("No matches:", threshold_report(minutes, 100, False)[1].tolist())

    selected[0] = 99
    print("Selected copy changed:", selected.tolist(), "; source:", minutes.tolist())
    updated = raised_selected_copy(minutes, 25, 5)
    print("Indexed update:", updated.tolist(), "; source:", minutes.tolist())
    direct = minutes.copy()
    direct[mask] = 99
    print("Direct masked assignment on copy:", direct.tolist())

    work = task_grid()
    element_mask = work >= 10
    print("2D element mask:", element_mask.tolist())
    print("2D selected elements:", work[element_mask].tolist(), work[element_mask].shape)
    row_mask = np.array([False, True])
    print("Selected row:", work[row_mask].tolist(), work[row_mask].shape)
    try:
        _ = minutes[np.array([True, False, True, False])]
    except IndexError as error:
        print("Wrong mask length:", type(error).__name__)


if __name__ == "__main__":
    main()
