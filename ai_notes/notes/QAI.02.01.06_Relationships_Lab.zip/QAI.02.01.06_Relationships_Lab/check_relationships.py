"""Check five different relationship rules using independent fresh databases."""

import sqlite3

from relationships import build_database


CASES = [
    (
        "Second profile for Anu",
        "INSERT INTO profiles (learner_id, bio) VALUES (?, ?)",
        (1, "Another bio"),
        "profiles",
    ),
    (
        "Profile of unknown learner",
        "INSERT INTO profiles (learner_id, bio) VALUES (?, ?)",
        (999, "Unknown person"),
        "profiles",
    ),
    (
        "Lesson points to unknown course",
        "INSERT INTO lessons (lesson_id, course_id, title) VALUES (?, ?, ?)",
        (1004, 999, "Wrong course"),
        "lessons",
    ),
    (
        "Lesson lacks a course",
        "INSERT INTO lessons (lesson_id, course_id, title) VALUES (?, ?, ?)",
        (1004, None, "Missing course"),
        "lessons",
    ),
    (
        "Repeated enrolment pair",
        "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
        (1, 101),
        "enrolments",
    ),
]


def verify_rejection(label, sql, values, table):
    connection = build_database()
    try:
        before = connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
        try:
            connection.execute(sql, values)
        except sqlite3.IntegrityError:
            after = connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
            assert before == after, label + ": rejected operation changed a row count"
            print(label + ": rejected")
        else:
            raise AssertionError(label + ": invalid association was accepted")
    finally:
        connection.close()


def main():
    for case in CASES:
        verify_rejection(*case)
    connection = build_database()
    try:
        # A course can exist without lessons in this schema.
        connection.execute(
            "INSERT INTO courses (course_id, title, capacity) VALUES (?, ?, ?)",
            (103, "Data Introduction", 1),
        )
        empty = connection.execute(
            "SELECT COUNT(*) FROM lessons WHERE course_id = ?", (103,)
        ).fetchone()[0]
        assert empty == 0
        print("New course without lessons: accepted")
    finally:
        connection.close()
    print("Checks passed: 6")


if __name__ == "__main__":
    main()
