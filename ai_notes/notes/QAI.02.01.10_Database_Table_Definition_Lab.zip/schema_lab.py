"""Explore database/table definition in a private temporary SQLite database."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory


def columns(connection, table_name):
    # Fixed identifiers only: never splice untrusted names into SQL.
    if table_name not in {"courses", "course_catalogue", "drafts", "scratch"}:
        raise ValueError("Unknown table name")
    return [row[1] for row in connection.execute(f"PRAGMA table_info({table_name});")]


def make_courses(connection):
    connection.execute(
        """CREATE TABLE courses (
               course_id INTEGER PRIMARY KEY,
               course_title TEXT NOT NULL,
               instructor_id INTEGER NOT NULL
           );"""
    )
    connection.executemany(
        "INSERT INTO courses VALUES (?, ?, ?);",
        [
            (101, "AI Foundations", 7),
            (102, "Git Basics", 8),
            (103, "Data Basics", 9),
        ],
    )
    connection.commit()


def migrate_courses(connection):
    connection.execute(
        "ALTER TABLE courses ADD COLUMN delivery_mode "
        "TEXT NOT NULL DEFAULT 'online';"
    )
    added = columns(connection, "courses")
    connection.execute(
        "ALTER TABLE courses RENAME COLUMN course_title TO title;"
    )
    connection.execute("ALTER TABLE courses RENAME TO course_catalogue;")
    renamed = columns(connection, "course_catalogue")
    connection.execute(
        "ALTER TABLE course_catalogue DROP COLUMN delivery_mode;"
    )
    final = columns(connection, "course_catalogue")
    connection.commit()
    return added, renamed, final


def try_alter_column(connection):
    """Return a clear version-sensitive outcome for SQLite's NOT NULL change."""
    connection.execute("CREATE TABLE drafts (draft_id INTEGER PRIMARY KEY, title TEXT);")
    connection.execute("INSERT INTO drafts VALUES (1, 'Draft syllabus');")
    connection.commit()
    if sqlite3.sqlite_version_info < (3, 53, 0):
        return "Unavailable in this SQLite version"
    connection.execute("ALTER TABLE drafts ALTER COLUMN title SET NOT NULL;")
    connection.commit()
    try:
        connection.execute("INSERT INTO drafts VALUES (2, NULL);")
    except sqlite3.IntegrityError:
        return "NOT NULL enforced"
    raise AssertionError("The new constraint was not enforced")


def run_lab():
    if sqlite3.sqlite_version_info < (3, 35, 0):
        raise RuntimeError("This lab needs SQLite 3.35.0+ for DROP COLUMN")

    with TemporaryDirectory(prefix="qai_schema_") as private_directory:
        path = Path(private_directory) / "course_catalogue.db"
        # Passing a filename selects the SQLite database; it is created if absent.
        connection = sqlite3.connect(path)
        try:
            make_courses(connection)
            before = connection.execute(
                "SELECT course_id, course_title, instructor_id "
                "FROM courses ORDER BY course_id;"
            ).fetchall()
            added, renamed, final = migrate_courses(connection)
            after = connection.execute(
                "SELECT course_id, title, instructor_id "
                "FROM course_catalogue ORDER BY course_id;"
            ).fetchall()
            assert before == after

            connection.execute("CREATE TABLE scratch (note TEXT);")
            connection.execute("DROP TABLE scratch;")
            scratch_exists = bool(connection.execute(
                "SELECT 1 FROM sqlite_schema WHERE type='table' AND name='scratch';"
            ).fetchone())
            column_change = try_alter_column(connection)
            connection.commit()
        finally:
            connection.close()

        # Open the same file again: the committed table definition persists.
        reopened = sqlite3.connect(path)
        try:
            persisted = columns(reopened, "course_catalogue") == final
        finally:
            reopened.close()

        print("Database file exists:", path.is_file())
        print("Created columns: course_id, course_title, instructor_id")
        print("After ADD:", ", ".join(added))
        print("After RENAME:", ", ".join(renamed))
        print("After DROP COLUMN:", ", ".join(final))
        print("Stored rows preserved:", before == after)
        print("Scratch table exists after DROP TABLE:", scratch_exists)
        print("ALTER COLUMN:", column_change)
        print("Definition persisted on reconnect:", persisted)
        # The temporary directory is removed when the with block ends.
    print("Temporary database removed:", not path.exists())


if __name__ == "__main__":
    run_lab()
