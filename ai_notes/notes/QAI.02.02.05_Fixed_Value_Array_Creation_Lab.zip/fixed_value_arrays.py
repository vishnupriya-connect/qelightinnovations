"""Construct arrays with known fills and safely initialize an empty buffer."""

import numpy as np


def standard_arrays():
    shape = (3, 2)
    return (
        np.zeros(shape, dtype=np.int32),
        np.ones(shape, dtype=np.int32),
        np.full(shape, 5, dtype=np.int32),
    )


def planned_minutes(value):
    return np.full((3, 2), value, dtype=np.int32)


def initialized_buffer(shape, value):
    """Write all positions before returning the allocated numeric buffer."""
    buffer = np.empty(shape, dtype=np.int32)
    buffer[:] = value
    return buffer


def diagonal_arrays():
    return (
        np.identity(3, dtype=np.int32),
        np.eye(3, dtype=np.int32),
        np.eye(2, 3, dtype=np.int32),
        np.eye(3, k=1, dtype=np.int32),
    )


def main():
    zeros, ones, fives = standard_arrays()
    for name, array in [("Zeros", zeros), ("Ones", ones), ("Fives", fives)]:
        print(f"{name}: shape={array.shape}, dtype={array.dtype}, values={array.tolist()}")
    eights = planned_minutes(8)
    print("Eights:", eights.tolist(), "total:", int(eights.sum()))
    print("Filled buffer:", initialized_buffer((2, 3), 7).tolist())
    print("Zero-size shape:", np.empty((0, 3), dtype=np.int32).shape)

    identity, eye, wide_eye, shifted = diagonal_arrays()
    print("Identity:", identity.tolist())
    print("Square eye equals identity:", bool(np.array_equal(identity, eye)))
    print("Wide eye:", wide_eye.tolist())
    print("Shifted diagonal:", shifted.tolist())
    try:
        np.ones((-1, 2), dtype=np.int32)
    except ValueError as error:
        print("Negative shape:", type(error).__name__)
    print("Corrected shape:", np.ones((3, 2), dtype=np.int32).shape)


if __name__ == "__main__":
    main()
