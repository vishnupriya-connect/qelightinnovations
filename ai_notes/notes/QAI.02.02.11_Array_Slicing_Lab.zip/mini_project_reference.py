"""Reference solution for the independent three-day slicing task."""

import numpy as np


def main():
    daily = np.array([
        [5, 10, 15, 20],
        [6, 12, 18, 24],
        [7, 14, 21, 28],
    ], dtype=np.int32)
    selections = {
        "Days 1–2, tasks 1 and 3": daily[1:3, 1:4:2],
        "Days reversed": daily[::-1, :],
        "Last two tasks": daily[:, -2:],
        "Empty beyond final day": daily[3:5, :],
    }
    for name, selected in selections.items():
        print(f"{name}: {selected.tolist()} shape={selected.shape}")

    changed = np.array([
        [5, 10, 15, 20],
        [6, 12, 18, 25],
        [7, 14, 21, 28],
    ], dtype=np.int32)
    print("Changed selection:", changed[1:3, 1:4:2].tolist())
    print("Original selection:", daily[1:3, 1:4:2].tolist())


if __name__ == "__main__":
    main()
