"""Check order, repetition, copies, row selection, and boundaries."""

import numpy as np

from fancy_indexing import learner_work, select_positions, session_minutes


def run_checks():
    source = session_minutes()
    selected = select_positions(source, np.array([4, 1, 4, 0], dtype=np.intp))
    assert selected.tolist() == [40, 18, 40, 12]
    assert selected.shape == (4,) and not np.shares_memory(selected, source)
    selected[0] = 99
    assert source.tolist() == [12, 18, 25, 30, 40]
    assert selected.tolist() == [99, 18, 40, 12]
    assert select_positions(source, [0, 4, 0]).tolist() == [12, 40, 12]
    changed = select_positions(source, [0, 4, 0])
    changed[-1] = 99
    assert int(source[0]) == 12

    view = source[1:4]
    copied = source[np.array([1, 2, 3])]
    assert view.tolist() == copied.tolist() == [18, 25, 30]
    assert np.shares_memory(view, source)
    assert not np.shares_memory(copied, source)
    work = learner_work()
    rows = work[[2, 0, 2]]
    assert rows.tolist() == [[14, 6], [12, 8], [14, 6]]
    assert rows.shape == (3, 2) and not np.shares_memory(rows, work)
    assert work[[0, 2], [1, 0]].tolist() == [8, 14]
    assert select_positions(source, []).shape == (0,)
    for array, indexes in [(source, [4, 5]), (work, [3])]:
        try:
            select_positions(array, indexes)
        except IndexError:
            pass
        else:
            raise AssertionError(f"Expected an invalid position: {indexes}")
    print("All fancy-indexing checks passed.")


if __name__ == "__main__":
    run_checks()
