"""A study-data example of zero, one, two, and three axes."""

import numpy as np


def examples():
    scalar = np.array(45, dtype=np.int32)
    vector = np.array([20, 30, 40], dtype=np.int32)
    matrix = np.array([[12, 8, 5], [10, 15, 5]], dtype=np.int32)
    weeks = np.array([
        [[12, 8, 5], [10, 15, 5]],
        [[14, 6, 5], [12, 10, 8]],
    ], dtype=np.int32)
    empty = np.array([], dtype=np.int32)
    return scalar, vector, matrix, weeks, empty


def axis_lengths(array):
    """Return each axis's length in number order."""
    return tuple(array.shape[axis_number] for axis_number in range(array.ndim))


def revise_matrix(matrix):
    revised = matrix.copy()
    revised[1, 2] = 9
    return revised


def main():
    scalar, vector, matrix, weeks, empty = examples()
    for name, array in [
        ("scalar", scalar), ("vector", vector), ("matrix", matrix),
        ("weeks", weeks), ("empty", empty),
    ]:
        print(f"{name}: ndim={array.ndim}, shape={array.shape}, size={array.size}, lengths={axis_lengths(array)}")
    print("Scalar object type:", type(scalar).__name__)
    print("Extracted value type:", type(scalar[()]).__name__)
    print("Vector middle value:", int(vector[1]))
    print("Matrix value [1, 1]:", int(matrix[1, 1]))
    print("Matrix, sum along axis 0:", matrix.sum(axis=0).tolist())
    print("Matrix, sum along axis 1:", matrix.sum(axis=1).tolist())
    print("Weeks value [1, 0, 1]:", int(weeks[1, 0, 1]))
    print("Weeks, sum along axis 0:", weeks.sum(axis=0).tolist())
    print("Weeks, totals per week:", weeks.sum(axis=(1, 2)).tolist())

    revised = revise_matrix(matrix)
    print("Revised matrix, axis 0:", revised.sum(axis=0).tolist())
    print("Revised matrix, axis 1:", revised.sum(axis=1).tolist())
    print("Original matrix, axis 1:", matrix.sum(axis=1).tolist())
    try:
        matrix.sum(axis=2)
    except np.exceptions.AxisError as error:
        print("Invalid axis:", type(error).__name__)
    print("Corrected second learner total:", int(matrix.sum(axis=1)[1]))


if __name__ == "__main__":
    main()
