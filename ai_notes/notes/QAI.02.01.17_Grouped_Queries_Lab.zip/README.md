# Grouped queries lab

Run from this unzipped folder with Python 3:

```sh
python grouped_queries.py
python check_grouped_queries.py
```

Use `python3` if needed. The standard-library `sqlite3` module builds a private in-memory catalogue. Predict the members of each group before running. Change a row-filter boundary, then a group-filter threshold. Attempt the mini-project and the separate lesson-count grouping before inspecting their reference functions. Compare your own query output with the checker and explain any mismatch.
