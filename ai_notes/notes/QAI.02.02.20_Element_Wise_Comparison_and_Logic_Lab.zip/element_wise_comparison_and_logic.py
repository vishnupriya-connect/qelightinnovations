"""Compare corresponding entries and summarize Boolean conditions."""

import numpy as np


def make_arrays():
    scores = np.array([[72, 48, 90], [55, 75, 60]])
    targets = np.array([[70, 50, 90], [60, 70, 65]])
    return scores, targets


def conditions(scores, targets):
    high = scores >= 70
    qualifies = np.logical_and(high, scores < 90)
    attention = np.logical_or(scores < 50, scores == 90)
    return high, qualifies, attention


def main():
    scores, targets = make_arrays()
    high, qualifies, attention = conditions(scores, targets)
    print("Equal:", (scores == targets).tolist())
    print("Not equal:", (scores != targets).tolist())
    print("Greater:", (scores > targets).tolist())
    print("Less:", (scores < targets).tolist())
    print("High:", high.tolist())
    print("Qualifies:", qualifies.tolist())
    print("Attention:", attention.tolist())
    print("Not high:", np.logical_not(high).tolist())
    print("Any low:", bool(np.any(scores < 50)))
    print("All at least 50:", bool(np.all(scores >= 50)))
    print("Any low by learner:", np.any(scores < 50, axis=1).tolist())
    print("All at least 50 by learner:", np.all(scores >= 50, axis=1).tolist())
    changed = scores.copy()
    changed[0, 2] = 85
    _, new_qualifies, new_attention = conditions(changed, targets)
    print("Variation:", bool(changed[0, 2] < targets[0, 2]),
          bool(new_qualifies[0, 2]), bool(new_attention[0, 2]),
          "original:", scores[0, 2])


if __name__ == "__main__":
    main()
