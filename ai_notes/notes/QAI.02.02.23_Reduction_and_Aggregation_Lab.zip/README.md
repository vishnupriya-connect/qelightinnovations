# Reduction and aggregation lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python reduction_and_aggregation.py
python check_reduction_and_aggregation.py
python mini_project_reference.py
```

Predict the row and column totals and the index of each row's maximum before running. Try the controlled variation in the companion notes.
