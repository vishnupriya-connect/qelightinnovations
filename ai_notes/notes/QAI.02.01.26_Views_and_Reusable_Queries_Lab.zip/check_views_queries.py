"""Run checks from the extracted lab folder."""

import sqlite3

from views_queries import (
    create_learning_view, create_snapshot, learning_rows, make_db,
    refresh_snapshot, replace_learning_view, report, short_course_view,
    snapshot_rows,
)


db = make_db()
base_before = db.execute("SELECT * FROM courses ORDER BY course_id").fetchall()
create_learning_view(db)
initial = [(101, 'AI Foundations', 95), (103, 'Data Basics', 80), (105, 'SQL Basics', 70)]
assert learning_rows(db) == initial
assert report(db) == (3, 245)
definition = db.execute("SELECT sql FROM sqlite_schema WHERE type='view' AND name='learning_courses'").fetchone()[0]
assert "duration_minutes >= 70" in definition
assert db.execute("SELECT COUNT(*) FROM learning_courses WHERE course_id = 106").fetchone() == (0,)
print("Creation, named definition, repeat use, and active filter: correct")

try:
    db.execute("CREATE VIEW learning_courses AS SELECT * FROM courses")
except sqlite3.OperationalError:
    pass
else:
    raise AssertionError("Expected duplicate view-name error")
try:
    db.execute("UPDATE learning_courses SET duration_minutes = 10 WHERE course_id = 101")
except sqlite3.OperationalError:
    pass
else:
    raise AssertionError("Expected read-only view error")
assert db.execute("SELECT * FROM courses ORDER BY course_id").fetchall() == base_before
print("Duplicate-name and direct-write failures leave source rows intact: correct")

create_snapshot(db)
assert snapshot_rows(db) == initial
db.execute("UPDATE courses SET duration_minutes = 85 WHERE course_id = 104")
updated = [(101, 'AI Foundations', 95), (103, 'Data Basics', 80), (104, 'Python Basics', 85), (105, 'SQL Basics', 70)]
assert learning_rows(db) == updated
assert snapshot_rows(db) == initial
assert report(db) == (4, 330)
print("Live view updates while the stored snapshot remains unchanged: correct")

replace_learning_view(db)
replaced = [(101, 'AI Foundations', 95), (103, 'Data Basics', 80), (104, 'Python Basics', 85)]
assert learning_rows(db) == replaced
assert report(db) == (3, 260)
assert "duration_minutes >= 80" in db.execute("SELECT sql FROM sqlite_schema WHERE name='learning_courses'").fetchone()[0]
assert short_course_view(db) == [(102, 'Git Basics')]
assert snapshot_rows(db) == initial
refresh_snapshot(db)
assert snapshot_rows(db) == replaced
print("Replacement, independent variation, and explicit refresh: correct")

db.execute("DROP VIEW IF EXISTS learning_courses")
db.execute("DROP VIEW IF EXISTS learning_courses")
assert db.execute("SELECT COUNT(*) FROM courses").fetchone() == (6,)
try:
    learning_rows(db)
except sqlite3.OperationalError:
    pass
else:
    raise AssertionError("Expected missing-view error")
assert snapshot_rows(db) == replaced
print("Drop removes the view name and preserves base and snapshot rows: correct")
db.close()
