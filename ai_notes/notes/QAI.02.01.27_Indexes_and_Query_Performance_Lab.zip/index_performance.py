"""Reproducible index and query-plan demonstration using in-memory SQLite."""

import sqlite3
from statistics import median
from time import perf_counter

QUERY = """SELECT event_id, created_at FROM enrollments
           WHERE course_id = ? AND status = ?
           ORDER BY created_at DESC LIMIT 5"""


def make_db():
    db = sqlite3.connect(":memory:")
    db.executescript("""
        CREATE TABLE enrollments (
            event_id INTEGER PRIMARY KEY,
            course_id INTEGER NOT NULL,
            status TEXT NOT NULL CHECK (status IN ('complete', 'pending')),
            created_at INTEGER NOT NULL
        );
        CREATE TABLE learners (
            learner_id INTEGER PRIMARY KEY,
            email TEXT NOT NULL
        );
    """)
    db.executemany("INSERT INTO enrollments VALUES (?, ?, ?, ?)", (
        (i + 1, i % 100 + 1, 'pending' if i % 3 == 0 else 'complete', i)
        for i in range(6000)
    ))
    db.executemany("INSERT INTO learners VALUES (?, ?)", [
        (1, 'learner1@example.invalid'), (2, 'learner2@example.invalid')
    ])
    return db


def result(db):
    return db.execute(QUERY, (42, 'complete')).fetchall()


def plan(db, sql=QUERY, params=(42, 'complete')):
    return [row[3] for row in db.execute('EXPLAIN QUERY PLAN ' + sql, params)]


def create_composite_index(db):
    db.execute("""CREATE INDEX idx_enroll_course_status_recent
                  ON enrollments (course_id, status, created_at DESC)""")


def create_unique_index(db):
    db.execute("CREATE UNIQUE INDEX ux_learner_email ON learners (email)")


def median_query_ms(db, repetitions=7, executions=200):
    """Illustrative in-process timings; not an assertion about speed."""
    samples = []
    for _ in range(repetitions):
        start = perf_counter()
        for _ in range(executions):
            result(db)
        samples.append((perf_counter() - start) * 1000 / executions)
    return median(samples)


def main():
    db = make_db()
    before_result = result(db)
    before_plan = plan(db)
    before_ms = median_query_ms(db)
    print('Before plan:', before_plan)
    print('Before rows:', before_result)
    create_composite_index(db)
    after_plan = plan(db)
    after_result = result(db)
    after_ms = median_query_ms(db)
    print('After plan:', after_plan)
    print('After rows:', after_result)
    print('Results unchanged:', before_result == after_result)
    print('Illustrative median milliseconds/query (scan, index):',
          round(before_ms, 4), round(after_ms, 4))
    print('Status-only plan:', plan(db,
          'SELECT event_id FROM enrollments WHERE status = ?', ('complete',)))
    db.execute("UPDATE enrollments SET status = 'pending' WHERE event_id = 5942")
    print('After status update:', result(db))
    create_unique_index(db)
    try:
        db.execute("INSERT INTO learners VALUES (3, 'learner1@example.invalid')")
    except sqlite3.IntegrityError:
        print('Duplicate email rejected:', True)
    print('Learner count:', db.execute('SELECT COUNT(*) FROM learners').fetchone()[0])
    db.close()


if __name__ == '__main__':
    main()
