"""Verify axis meanings, output shapes, values, and shape errors."""

import warnings

import numpy as np

from array_joining import make_examples


def main():
    first, extra, new_task, second, a, b = make_examples()
    rows = np.concatenate((first, extra), axis=0)
    columns = np.concatenate((first, new_task), axis=1)
    assert rows.shape == (3, 2)
    assert rows.tolist() == [[10, 20], [30, 40], [50, 60]]
    assert columns.shape == (2, 3)
    assert columns.tolist() == [[10, 20, 7], [30, 40, 9]]
    assert np.array_equal(rows, np.vstack((first, extra)))
    assert np.array_equal(columns, np.hstack((first, new_task)))
    assert np.hstack((a, b)).shape == (6,)
    assert np.vstack((a, b)).shape == (2, 3)
    assert np.column_stack((a, b)).shape == (3, 2)
    assert np.stack((a, b), axis=0).shape == (2, 3)
    assert np.stack((a, b), axis=1).shape == (3, 2)
    if hasattr(np, "row_stack"):
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", DeprecationWarning)
            assert np.array_equal(np.row_stack((a, b)), np.vstack((a, b)))
    joined = np.concatenate((first, second), axis=0)
    stacked = np.stack((first, second), axis=0)
    depth = np.dstack((first, second))
    assert joined.shape == (4, 2)
    assert stacked.shape == depth.shape == (2, 2, 2)
    assert joined[2, 1] == stacked[1, 0, 1] == depth[0, 1, 1] == 60
    assert np.dstack((a, b)).shape == (1, 3, 2)
    changed = second.copy()
    changed[0, 1] = 99
    assert np.concatenate((first, changed), axis=0)[2, 1] == 99
    assert np.stack((first, changed), axis=0)[1, 0, 1] == 99
    assert np.dstack((first, changed))[0, 1, 1] == 99
    assert second[0, 1] == 60
    for action in (
        lambda: np.concatenate((first, np.array([[7, 8, 9]])), axis=0),
        lambda: np.stack((first, extra)),
    ):
        try:
            action()
        except ValueError:
            pass
        else:
            raise AssertionError("Mismatched input shapes should raise ValueError")
    print("All checks passed.")


if __name__ == "__main__":
    main()
