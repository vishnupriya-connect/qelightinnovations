# Aggregate functions lab

Run from this unzipped folder with Python 3:

```sh
python aggregate_functions.py
python check_aggregate_functions.py
```

Use `python3` if needed. The standard-library `sqlite3` module makes an in-memory catalogue, so no external database is needed. Predict the count and average denominators before running. Change the range from 50–80 to 51–79 and explain the output. Reproduce the mistake of treating missing practice estimates as zero; then compare `COUNT(*)`, `COUNT(practice_minutes)` and `AVG(practice_minutes)`. Attempt the instructor variation before inspecting its reference function. The checker verifies supplied examples, not your independent edits.
