# QAI.02.01.07 — Data integrity lab

Python 3 standard library only. Work in this directory:

```sh
python integrity.py
python integrity.py --add-course
python check_integrity.py
```

Use `python3` if necessary. Each run builds an in-memory database; nothing is saved. The checker creates a fresh database for each case. The full walkthrough, independent change, and solved answers are in the companion notes.

Expected first run: foreign keys on, 2 learners, 2 courses, 3 enrolments; course 101 is published (1), course 102 has default published (0). The guided run adds course 103 with default published (0). The checker reports ten deliberate rejections, one normal acceptance at capacity 50, and one rejection at capacity 51 under the tightened 50 limit. The final PASS line confirms all assertions.

Evidence for completion: capture the three command outputs, explain each rejected case in one phrase, show your own new rejection test and one accepted test after modifying the capacity rule.
