"""First NumPy import and simple numerical-operation practice."""

import numpy
import numpy as np


def summary(minutes):
    """Compute two numeric summaries; return plain Python values for display."""
    if not minutes:
        raise ValueError('at least one value is needed for a mean')
    return int(np.sum(minutes)), float(np.mean(minutes))


def main():
    minutes = [20, 30, 10]
    print('NumPy imported:', numpy is np)
    print('Full-name sum:', int(numpy.sum(minutes)))
    print('Alias mean:', float(np.mean(minutes)))
    print('Study minutes:', minutes)
    print('Summary (total, mean):', summary(minutes))
    changed = [20, 30, 40]
    print('Changed summary:', summary(changed))


if __name__ == '__main__':
    main()
