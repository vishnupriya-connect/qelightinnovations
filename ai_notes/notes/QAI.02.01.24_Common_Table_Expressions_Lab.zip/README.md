# Common table expressions lab

Run from this unzipped folder with Python 3:

```sh
python cte_examples.py
python check_cte_examples.py
```

Use `python3` if needed. Python's standard-library `sqlite3` builds private in-memory course and prerequisite tables. Predict the ordinary CTE result, then trace the root (depth 0) and each recursive level. Change the minimum duration and the maximum depth. Attempt a new root before reading the reference function. The checker confirms that a CTE name lasts only one statement and that a depth bound stops a deliberately introduced cycle, although that cycle can still repeat a course in the result.
