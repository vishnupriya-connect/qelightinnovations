# Pandas basics lab

From this folder, run:

```bash
python -m pip install -r requirements.txt
python pandas_basics.py
python check_pandas_basics.py
python mini_project_reference.py
```

Read the labels and values in the printed trace. Predict the second row label, both column labels, and the type of the selected score column before running it. Then try changing Bala's score and comparing the results. The independent mini-project reference prints a small reading log.
