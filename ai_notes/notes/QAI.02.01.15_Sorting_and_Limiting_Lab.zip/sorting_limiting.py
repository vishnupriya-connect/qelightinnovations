"""Sort and page a four-row SQLite course catalogue."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4, "intro"),
    (102, "Git Basics", 8, 50, 3, None),
    (103, "Data Basics", 7, 80, 4, "tables"),
    (104, "Python Basics", 8, 65, 3, None),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT
        );"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?)", COURSES)
    db.commit()
    return db


def ordered_ids(db, order_clause, parameters=()):
    """Use only the fixed ORDER BY clauses supplied in this learning lab."""
    return [row[0] for row in db.execute(
        "SELECT course_id FROM course_catalogue ORDER BY " + order_clause,
        parameters,
    )]


def duration_page(db, page_number, page_size):
    """Get a numbered page (first page is 1) under a complete sort order."""
    if not isinstance(page_number, int) or isinstance(page_number, bool) or page_number < 1:
        raise ValueError("page_number must be a positive integer")
    if not isinstance(page_size, int) or isinstance(page_size, bool) or page_size < 1:
        raise ValueError("page_size must be a positive integer")
    offset = (page_number - 1) * page_size
    return [row[0] for row in db.execute(
        """SELECT course_id FROM course_catalogue
        ORDER BY duration_minutes DESC, course_id ASC
        LIMIT ? OFFSET ?""",
        (page_size, offset),
    )]


def project_page(db):
    """Second alphabetically sorted Basics course with a missing topic note."""
    return db.execute(
        """SELECT course_id, title FROM course_catalogue
        WHERE title LIKE ? AND topic_note IS NULL
        ORDER BY title ASC, course_id ASC
        LIMIT ? OFFSET ?""",
        ("%Basics", 1, 1),
    ).fetchall()


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Title ascending:", ordered_ids(db, "title ASC, course_id ASC"))
        print("Duration ascending:", ordered_ids(db, "duration_minutes ASC, course_id ASC"))
        print("Duration descending:", ordered_ids(db, "duration_minutes DESC, course_id ASC"))
        print("Instructor, then title:", ordered_ids(
            db, "instructor_id ASC, title ASC, course_id ASC"
        ))
        print("First by course ID:", ordered_ids(db, "course_id ASC LIMIT 1"))
        print("Top by duration:", ordered_ids(db, "duration_minutes DESC, course_id ASC LIMIT 1"))
        print("Duration page 1:", duration_page(db, 1, 2))
        print("Duration page 2:", duration_page(db, 2, 2))
        print("Project page:", project_page(db))
        after = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Stored rows unchanged:", before == after)


if __name__ == "__main__":
    main()
