# Join foundations lab

Run from this unzipped folder with Python 3:

```sh
python join_foundations.py
python check_join_foundations.py
```

Use `python3` if needed. Python's standard-library `sqlite3` creates private in-memory course and instructor tables. Predict the matching pairs and the two unmatched source rows. Change the minimum duration, reproduce the wrong-key and ambiguous-name failures, then repair them. Attempt the joined mini-project and instructor-8 variation before inspecting their reference functions. The checker verifies included examples; compare your own query separately.
