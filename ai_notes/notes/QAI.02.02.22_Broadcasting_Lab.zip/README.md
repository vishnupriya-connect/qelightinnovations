# Broadcasting lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python broadcasting.py
python check_broadcasting.py
python mini_project_reference.py
```

Align shapes from the right before running the examples. Trace the last coordinate in each result, then try the controlled variation in the companion notes.
