"""Create, select, slice, and filter labeled Series."""

import pandas as pd


def make_examples():
    minutes = pd.Series(
        [15, 25, 20],
        index=["Mon", "Tue", "Wed"],
        name="study_minutes",
    )
    from_dict = pd.Series({"Mon": 15, "Tue": 25, "Wed": 20})
    targets = pd.Series(30, index=["Mon", "Tue", "Wed"], name="target_minutes")
    return minutes, from_dict, targets


def main():
    minutes, from_dict, targets = make_examples()
    mask = minutes >= 20
    selected = minutes[mask]
    print("Name:", minutes.name)
    print("Length:", len(minutes))
    print("Dtype:", minutes.dtype)
    print("Labels:", minutes.index.tolist())
    print("Values:", minutes.tolist())
    print("Dictionary labels and values:", from_dict.index.tolist(), from_dict.tolist())
    print("Scalar targets:", targets.tolist())
    print("Tuesday by label:", minutes.loc["Tue"])
    print("Second value by position:", minutes.iloc[1])
    print("Label slice:", minutes.loc["Mon":"Tue"].tolist())
    print("Position slice:", minutes.iloc[0:2].tolist())
    print("Mask:", mask.tolist())
    print("Filtered labels:", selected.index.tolist())
    print("Filtered values:", selected.tolist())


if __name__ == "__main__":
    main()
