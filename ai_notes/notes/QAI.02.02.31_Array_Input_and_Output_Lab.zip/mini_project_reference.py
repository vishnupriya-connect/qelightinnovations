"""Reference solution: save and reload a small study-minutes table."""

from pathlib import Path

import numpy as np

minutes = np.array([[12, 15], [20, 25]], dtype=np.int32)
learners = np.array([101, 102], dtype=np.int32)
folder = Path("study_output")
folder.mkdir(exist_ok=True)
npy_path = folder / "minutes.npy"
npz_path = folder / "study.npz"
csv_path = folder / "minutes.csv"
np.save(npy_path, minutes)
np.savez(npz_path, minutes=minutes, learners=learners)
np.savetxt(csv_path, minutes, fmt="%d", delimiter=",")
from_npy = np.load(npy_path, allow_pickle=False)
with np.load(npz_path, allow_pickle=False) as bundle:
    keys = sorted(bundle.files)
    table_ok = np.array_equal(bundle["minutes"], minutes)
    learners_ok = np.array_equal(bundle["learners"], learners)
from_csv = np.loadtxt(csv_path, delimiter=",", dtype=np.int32)
print("npy", from_npy.shape, from_npy.dtype,
      np.array_equal(from_npy, minutes))
print("npz keys", keys)
print("npz arrays", table_ok, learners_ok)
print("csv", from_csv.shape, from_csv.dtype,
      np.array_equal(from_csv, minutes))
print("csv text", " / ".join(csv_path.read_text().strip().splitlines()))
