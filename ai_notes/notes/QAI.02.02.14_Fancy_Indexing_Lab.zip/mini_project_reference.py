"""Reference solution for the independent learner reorder."""

import numpy as np

from fancy_indexing import select_positions


def main():
    records = np.array([[12, 8], [10, 15], [14, 6], [20, 10]], dtype=np.int32)
    requested = np.array([3, 1, 3, 0], dtype=np.intp)
    selected = select_positions(records, requested)
    print("Reordered rows:", selected.tolist(), selected.shape)
    print("Fancy result shares source memory:", bool(np.shares_memory(selected, records)))
    selected[0, 0] = 99
    print("Edited selection first row:", selected[0].tolist())
    print("Original row 3:", records[3].tolist())
    regular = records[1:4]
    print("Regular slice:", regular.tolist(), regular.shape)
    print("Slice shares source memory:", bool(np.shares_memory(regular, records)))
    print("Pairwise coordinates:", records[[0, 2], [1, 0]].tolist())
    try:
        select_positions(records, [4])
    except IndexError as error:
        print("Invalid row:", type(error).__name__, "; valid rows: 0..3")


if __name__ == "__main__":
    main()
