"""Compare reshape, flatten, ravel, resize, and shape assignment."""

import numpy as np


def source_values():
    return np.array([10, 20, 30, 40, 50, 60], dtype=np.int32)


def reshaped_examples():
    source = source_values()
    return source, source.reshape(2, 3), source.reshape(3, 2), source.reshape(2, -1)


def flatten_examples():
    table = np.array([[10, 20, 30], [40, 50, 60]], dtype=np.int32)
    copied = table.flatten()
    raveled = table.ravel()
    skipped = table[:, ::2]
    skipped_raveled = skipped.ravel()
    return table, copied, raveled, skipped, skipped_raveled


def resize_on_fresh_array():
    growing = source_values()
    growing.resize((2, 4))
    return growing


def shape_assignment_on_fresh_array():
    owning = source_values()
    owning.shape = (3, 2)
    return owning


def controlled_eight_values():
    eight = np.array([1, 2, 3, 4, 5, 6, 7, 8], dtype=np.int32)
    return eight, eight.reshape(2, -1)


def main():
    source, two_three, three_two, inferred = reshaped_examples()
    for name, array in [
        ("Original", source), ("2 x 3", two_three),
        ("3 x 2", three_two), ("2 x inferred", inferred),
    ]:
        print(f"{name}: shape={array.shape}, values={array.tolist()}")
    print("Reshape shares source data:", bool(np.shares_memory(two_three, source)))
    try:
        source.reshape(4, 2)
    except ValueError as error:
        print("Incompatible shape:", type(error).__name__)

    table, copied, raveled, skipped, skipped_raveled = flatten_examples()
    print("Flatten:", copied.tolist(), "shares memory:", bool(np.shares_memory(copied, table)))
    print("Ravel:", raveled.tolist(), "shares memory:", bool(np.shares_memory(raveled, table)))
    print("Ravel skipped columns:", skipped_raveled.tolist(),
          "shares selected data:", bool(np.shares_memory(skipped_raveled, skipped)))
    print("In-place resize:", resize_on_fresh_array().tolist())
    print("In-place shape assignment:", shape_assignment_on_fresh_array().tolist())
    print("np.resize repeats to expand:", np.resize(source, (2, 4)).tolist())

    eight, reshaped = controlled_eight_values()
    print("Eight-value inferred shape:", reshaped.shape, reshaped.tolist())
    try:
        eight.reshape(3, -1)
    except ValueError as error:
        print("Eight into three rows:", type(error).__name__)


if __name__ == "__main__":
    main()
