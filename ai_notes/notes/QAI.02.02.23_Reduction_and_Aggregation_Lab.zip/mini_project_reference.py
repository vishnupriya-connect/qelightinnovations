"""Complete reference solution for learner task summaries."""

import numpy as np


def main():
    tasks = np.array([[2, 4, 6], [1, 3, 5]])
    print("learner totals", np.sum(tasks, axis=1).tolist())
    print("learner means", np.mean(tasks, axis=1).tolist())
    print("task totals", np.sum(tasks, axis=0).tolist())
    print("median", np.median(tasks))
    print("min positions", np.argmin(tasks, axis=1).tolist())
    print("max positions", np.argmax(tasks, axis=1).tolist())
    print("variance", np.round(np.var(tasks, axis=1), 3).tolist())
    print("std", np.round(np.std(tasks, axis=1), 3).tolist())
    print("running sum", np.cumsum(tasks, axis=1).tolist())
    print("running product", np.cumprod(tasks, axis=1).tolist())


if __name__ == "__main__":
    main()
