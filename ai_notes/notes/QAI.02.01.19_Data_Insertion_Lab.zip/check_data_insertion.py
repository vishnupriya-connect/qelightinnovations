"""Verify inserted rows, mapped query results, defaults, and rejected inserts."""

import sqlite3

from data_insertion import (
    SEED, add_one, add_queue_default, add_two, copy_long_courses,
    independent_variation, make_connection, new_rows,
)


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == SEED
        add_one(db)
        assert new_rows(db) == [(105, "SQL Basics", None, None, "draft")]
        add_two(db)
        assert new_rows(db) == [
            (105, "SQL Basics", None, None, "draft"),
            (106, "Query Practice", None, None, "draft"),
            (107, "Data Visuals", None, None, "draft"),
        ]
        print("Single and multi-row inserts, omitted nullable/default fields: correct")

        copy_long_courses(db)
        assert db.execute(
            "SELECT * FROM long_course_archive ORDER BY course_id"
        ).fetchall() == [(101, "AI Foundations", 95), (103, "Data Basics", 80)]
        assert db.execute(
            "SELECT COUNT(*) FROM course_catalogue"
        ).fetchone() == (7,)
        print("INSERT from SELECT copies the selected columns and keeps sources: correct")

        add_queue_default(db)
        assert db.execute("SELECT * FROM review_queue").fetchall() == [
            (1, "pending", 0)
        ]
        print("DEFAULT VALUES creates one complete row: correct")

        before = db.execute("SELECT COUNT(*) FROM course_catalogue").fetchone()[0]
        try:
            db.execute(
                """INSERT INTO course_catalogue
                   (course_id, instructor_id, duration_minutes, lesson_count)
                   VALUES (109, 7, 60, 3)"""
            )
        except sqlite3.IntegrityError as exc:
            assert "NOT NULL" in str(exc)
        else:
            raise AssertionError("Omitting required title should have failed")
        assert db.execute("SELECT COUNT(*) FROM course_catalogue").fetchone()[0] == before
        assert db.execute(
            "SELECT 1 FROM course_catalogue WHERE course_id=109"
        ).fetchone() is None
        print("Missing required title rejected without adding a row: correct")

        independent_variation(db)
        assert new_rows(db)[-1] == (
            108, "Linux Basics", None, None, "published"
        )
        assert db.execute(
            "SELECT * FROM course_catalogue WHERE course_id <= 104 ORDER BY course_id"
        ).fetchall() == SEED
        print("Explicit status and independent variation: correct")


if __name__ == "__main__":
    main()
