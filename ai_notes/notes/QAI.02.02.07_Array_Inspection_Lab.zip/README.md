# Array inspection lab

Run in this folder:

```sh
python -m pip install -r requirements.txt
python array_inspection.py
python check_array_inspection.py
```

Use `python3` if needed. Predict all six attributes before running. Complete the three-day results-grid task on your own, then compare with `python mini_project_reference.py`. These examples were checked with NumPy 2.3.5. `nbytes` is the element-data count, not the whole process memory footprint.
