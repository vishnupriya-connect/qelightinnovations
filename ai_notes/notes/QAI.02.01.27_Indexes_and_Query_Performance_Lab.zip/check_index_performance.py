"""Verify semantics and structural evidence without testing elapsed time."""

import sqlite3

from index_performance import (
    create_composite_index, create_unique_index, make_db, plan, result,
)

db = make_db()
assert db.execute('SELECT COUNT(*) FROM enrollments').fetchone() == (6000,)
before = result(db)
assert len(before) == 5
assert all(event_id % 100 == 42 for event_id, _ in before)
pre_plan = plan(db)
assert any('SCAN enrollments' in detail for detail in pre_plan), pre_plan
print('Unindexed report: correct rows and table scan')

create_composite_index(db)
post_plan = plan(db)
assert any('SEARCH enrollments USING' in detail and 'idx_enroll_course_status_recent' in detail for detail in post_plan), post_plan
assert result(db) == before
assert db.execute("SELECT COUNT(*) FROM sqlite_schema WHERE type='index' AND name='idx_enroll_course_status_recent'").fetchone() == (1,)
print('Composite index: selected lookup and unchanged results')

db.execute("UPDATE enrollments SET status = 'pending' WHERE event_id = 5942")
assert 5942 not in [event_id for event_id, _ in result(db)]
assert len(result(db)) == 5
assert any('SEARCH enrollments USING' in detail for detail in plan(db)), plan(db)
print('Index maintenance: updated row leaves filtered result')

create_unique_index(db)
try:
    db.execute("INSERT INTO learners VALUES (3, 'learner1@example.invalid')")
except sqlite3.IntegrityError:
    pass
else:
    raise AssertionError('A duplicate email should be rejected')
assert db.execute('SELECT COUNT(*) FROM learners').fetchone() == (2,)
db.execute("INSERT INTO learners VALUES (3, 'learner3@example.invalid')")
assert db.execute('SELECT COUNT(*) FROM learners').fetchone() == (3,)
print('Unique index: duplicate rejected, distinct value accepted')

db.execute('DROP INDEX idx_enroll_course_status_recent')
# Force a fresh prepared statement; Python/SQLite may cache the exact old SQL.
post_drop_plan = plan(db, sql=(
    'SELECT event_id, created_at FROM enrollments WHERE course_id = ? AND status = ? '
    'ORDER BY created_at DESC LIMIT 5 /* after drop */'
))
assert any('SCAN enrollments' in detail for detail in post_drop_plan), post_drop_plan
assert len(result(db)) == 5
print('Drop index: query remains correct and reverts to a scan')
db.close()
