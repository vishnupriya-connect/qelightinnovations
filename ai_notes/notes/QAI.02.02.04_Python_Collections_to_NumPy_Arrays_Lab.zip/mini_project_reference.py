"""Reference solution: read after attempting the two-week task."""

import numpy as np


def main():
    records = [
        [[12, 8], [10, 5], [15, 10]],
        [[14, 6], [12, 8], [10, 15]],
    ]
    weeks = np.array(records, dtype=np.int32)
    print("Shape, dimensions, size, type:", weeks.shape, weeks.ndim, weeks.size, weeks.dtype)
    print("Selected value:", int(weeks[1, 2, 1]))
    print("Week totals:", weeks.sum(axis=(1, 2)).tolist())

    records[0][0][0] = 99
    print("Original list changed; existing array value:", int(weeks[0, 0, 0]))
    new_records = [
        [[12, 8], [10, 5], [15, 10]],
        [[14, 6], [12, 8], [10, 20]],
    ]
    changed = np.array(new_records, dtype=np.int32)
    print("New week totals:", changed.sum(axis=(1, 2)).tolist())
    print("Existing array week totals:", weeks.sum(axis=(1, 2)).tolist())

    uneven = [
        [[12, 8], [10, 5], [15, 10]],
        [[14, 6], [12, 8], [10]],
    ]
    try:
        np.array(uneven, dtype=np.int32)
    except ValueError as error:
        print("Uneven input:", type(error).__name__, "(missing measurement requires investigation)")


if __name__ == "__main__":
    main()
