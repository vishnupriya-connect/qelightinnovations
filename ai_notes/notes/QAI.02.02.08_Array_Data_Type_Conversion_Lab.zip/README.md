# Array data-type conversion lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python array_type_conversion.py
python check_array_type_conversion.py
```

Use `python3` if needed. Predict values and dtypes before running. Complete the validated practice-minute mini-project before comparing with `python mini_project_reference.py`. These examples were checked with NumPy 2.3.5. The unsafe narrowing examples are demonstrations of data loss; use the guarded conversion for the actual task.
