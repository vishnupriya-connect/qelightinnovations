"""Check split positions, axis selection, errors, and view behavior."""

import numpy as np

from array_splitting import make_examples


def main():
    table, top, bottom, left, middle, right, values, cube, early, late = make_examples()
    assert table.shape == (4, 6)
    assert top.shape == bottom.shape == (2, 6)
    assert bottom[0, 4] == table[2, 4] == 16
    assert [p.shape for p in (left, middle, right)] == [(4, 2), (4, 3), (4, 1)]
    assert [p[0].tolist() for p in (left, middle, right)] == [[0, 1], [2, 3, 4], [5]]
    assert middle[2, 2] == 16
    assert [p.tolist() for p in np.split(values, [3, 5])] == [
        [0, 1, 2], [3, 4], [5, 6, 7]]
    assert [p.shape for p in np.array_split(values, 3)] == [(3,), (3,), (2,)]
    assert [p.shape for p in np.hsplit(table, 3)] == [(4, 2)] * 3
    assert [p.shape for p in np.vsplit(table, 2)] == [(2, 6)] * 2
    assert [p.shape for p in np.hsplit(values, 2)] == [(4,), (4,)]
    assert cube.shape == (2, 3, 4)
    assert early.shape == late.shape == (2, 3, 2)
    assert cube[1, 2, 3] == late[1, 2, 1] == 23
    assert np.array_equal(late, np.split(cube, 2, axis=2)[1])
    changed = cube.copy()
    changed[1, 2, 3] = 99
    assert np.dsplit(changed, 2)[1][1, 2, 1] == 99
    assert cube[1, 2, 3] == 23
    assert np.shares_memory(cube, late)
    independent = cube.copy()
    part = np.dsplit(independent, 2)[1]
    part[1, 2, 1] = 99
    assert independent[1, 2, 3] == 99
    for action in (
        lambda: np.split(values, 3),
        lambda: np.dsplit(table, 2),
        lambda: np.vsplit(values, 2),
    ):
        try:
            action()
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid split should raise ValueError")
    print("All checks passed.")


if __name__ == "__main__":
    main()
