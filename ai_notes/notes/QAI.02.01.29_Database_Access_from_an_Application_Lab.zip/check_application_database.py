"""Check connection, cursor, query, transaction, close, and bounded reuse."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory

from application_database import (
    DemoPool, PoolExhausted, add_course, connect, course_by_id,
    courses_at_least, initialize, open_database, pool_demo,
)

with TemporaryDirectory(prefix='qai_application_db_check_') as folder:
    path = Path(folder) / 'check.sqlite'
    initialize(path)
    with open_database(path) as db:
        assert course_by_id(db, 103) == (103, 'Data Basics')
        assert course_by_id(db, 999) is None
        assert courses_at_least(db, 70) == [(101, 'AI Foundations'), (103, 'Data Basics')]
        add_course(db, 105, 'SQL Basics', 70)
        assert courses_at_least(db, 70) == [
            (101, 'AI Foundations'), (103, 'Data Basics'), (105, 'SQL Basics')
        ]
        try:
            add_course(db, 105, 'Duplicate', 70)
        except sqlite3.IntegrityError:
            pass
        else:
            raise AssertionError('duplicate ID should be rejected')
        assert not db.in_transaction
    print('Cursor execution, fetch one/all, bound values, and failed-write rollback: correct')

    with open_database(path) as reopened:
        assert course_by_id(reopened, 105) == (105, 'SQL Basics')
    assert pool_demo(path) == (
        True, True, True,
        [(101, 'AI Foundations'), (103, 'Data Basics')], True
    )
    print('Reopen persistence, bounded pool, rollback on return, reuse, and close: correct')

    pool = DemoPool(path, size=1)
    with pool.checkout() as borrower:
        assert course_by_id(borrower, 101) == (101, 'AI Foundations')
        try:
            pool.close()
        except RuntimeError:
            pass
        else:
            raise AssertionError('borrowed connection cannot be closed via pool')
        try:
            with pool.checkout():
                pass
        except PoolExhausted:
            pass
        else:
            raise AssertionError('pool limit should be enforced')
    pool.close()
    assert pool.closed
    print('Pool cannot close while borrowed and rejects excess checkout: correct')

    handle = connect(path)
    handle.close()
    try:
        handle.execute('SELECT 1')
    except sqlite3.ProgrammingError:
        pass
    else:
        raise AssertionError('closed connection should reject queries')
    print('Closed connection cannot execute: correct')
