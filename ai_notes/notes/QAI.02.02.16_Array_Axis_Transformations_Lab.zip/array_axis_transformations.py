"""Rearrange axes while preserving values and tracing their coordinates."""

import numpy as np


def make_examples():
    work = np.array([[12, 8, 5], [10, 15, 5]], dtype=np.int32)
    vector = np.array([12, 8, 5], dtype=np.int32)
    row = np.expand_dims(vector, axis=0)
    column = np.expand_dims(vector, axis=1)
    cube = np.arange(24, dtype=np.int32).reshape(2, 3, 4)
    by_task = cube.transpose(2, 0, 1)
    swapped = cube.swapaxes(0, 2)
    moved = np.moveaxis(cube, 0, 2)
    return work, vector, row, column, cube, by_task, swapped, moved


def main():
    work, vector, row, column, cube, by_task, swapped, moved = make_examples()
    print("Table:", work.shape, work.tolist())
    print("Transposed:", work.T.shape, work.T.tolist())
    print("Same cell:", work[1, 0], work.T[0, 1])
    print("Vector and its .T:", vector.shape, vector.T.shape)
    print("Row and column:", row.shape, column.shape)
    print("Back to vector:", np.squeeze(column, axis=1).shape)
    print("Cube:", cube.shape, cube[1, 2, 3])
    print("Transpose:", by_task.shape, by_task[3, 1, 2])
    print("Swap axes:", swapped.shape, swapped[3, 2, 1])
    print("Move axis:", moved.shape, moved[2, 3, 1])

    changed = cube.copy()
    changed[1, 2, 3] = 99
    print("Variation:", changed.transpose(2, 0, 1)[3, 1, 2],
          changed.swapaxes(0, 2)[3, 2, 1],
          np.moveaxis(changed, 0, 2)[2, 3, 1],
          "original:", cube[1, 2, 3])


if __name__ == "__main__":
    main()
