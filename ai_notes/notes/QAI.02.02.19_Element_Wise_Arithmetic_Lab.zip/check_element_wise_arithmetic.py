"""Check shapes, values, named functions, and error handling."""

import numpy as np

from element_wise_arithmetic import make_arrays, safe_ratio


def main():
    a, b = make_arrays()
    assert a.shape == b.shape == (2, 3)
    assert (a + b).tolist() == [[9, 11, 13], [13, 15, 17]]
    assert (a - b).tolist() == [[5, 5, 5], [7, 7, 7]]
    assert (a * b).tolist() == [[14, 24, 36], [30, 44, 60]]
    assert np.round(a / b, 2).tolist() == [[3.5, 2.67, 2.25], [3.33, 2.75, 2.4]]
    assert (a // b).tolist() == [[3, 2, 2], [3, 2, 2]]
    assert (a % b).tolist() == [[1, 2, 1], [1, 3, 2]]
    assert (a ** 2).tolist() == [[49, 64, 81], [100, 121, 144]]
    assert np.array_equal(np.add(a, b), a + b)
    assert np.array_equal(np.subtract(a, b), a - b)
    assert np.array_equal(np.multiply(a, b), a * b)
    assert np.array_equal(np.divide(a, b), a / b)
    assert np.array_equal(np.mod(a, b), a % b)
    assert np.array_equal(np.power(a, 2), a ** 2)
    assert np.array_equal(safe_ratio(a, b), a / b)
    assert (a + 2).tolist() == [[9, 10, 11], [12, 13, 14]]
    assert (-7 // 3, -7 % 3) == (-3, 2)
    assert np.array_equal(a, b * (a // b) + a % b)
    changed = a.copy()
    changed[0, 1] = 14
    assert [(changed + b)[0, 1], (changed - b)[0, 1],
            (changed * b)[0, 1], (changed // b)[0, 1],
            (changed % b)[0, 1], (changed ** 2)[0, 1]] == [17, 11, 42, 4, 2, 196]
    assert np.isclose((changed / b)[0, 1], 14 / 3)
    assert a[0, 1] == 8
    for bad in (np.array([2, 0, 4]), np.zeros_like(b)):
        try:
            safe_ratio(np.ones_like(bad), bad)
        except ValueError:
            pass
        else:
            raise AssertionError("Zero divisor was accepted")
    print("All checks passed.")


if __name__ == "__main__":
    main()
