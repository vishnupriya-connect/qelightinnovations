# Array joining lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python array_joining.py
python check_array_joining.py
python mini_project_reference.py
```

Predict each shape and trace the value 60 before running. Try the controlled variation in the companion notes on a copy of the second table.
