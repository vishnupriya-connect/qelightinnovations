"""A small, repeatable SQLite demonstration of SQL statement parts."""

import sqlite3


def make_connection():
    connection = sqlite3.connect(":memory:")
    connection.executescript(
        """
        CREATE TABLE courses (
            course_id INTEGER PRIMARY KEY,
            course_title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL
        );
        INSERT INTO courses VALUES (101, 'AI Foundations', 7);
        INSERT INTO courses VALUES (102, 'Git Basics', 8);
        INSERT INTO courses VALUES (103, 'Data Basics', 9);
        """
    )
    return connection


def run_statement(connection, sql, values=()):
    """Return output headings and rows for one read-only SELECT statement."""
    cursor = connection.execute(sql, values)
    names = [item[0] for item in cursor.description]
    return names, cursor.fetchall()


def catalogue_preview(connection):
    return run_statement(
        connection,
        "SELECT course_id, course_title AS label, 'course' AS item_type "
        "FROM courses ORDER BY course_id;",
    )


def independent_variant(connection):
    return run_statement(
        connection,
        "SELECT course_id, course_id + 1000 AS display_id, "
        "'course' AS item_type FROM courses ORDER BY course_id;",
    )


def main():
    with make_connection() as connection:
        before = connection.execute(
            "SELECT course_id, course_title, instructor_id "
            "FROM courses ORDER BY course_id;"
        ).fetchall()
        names, rows = run_statement(
            connection,
            "SELECT course_id, course_title FROM courses ORDER BY course_id;",
        )
        literal_names, literal_rows = run_statement(
            connection,
            "SELECT course_title, 'course' AS item_type, 1 AS example_count "
            "FROM courses ORDER BY course_id;",
        )
        expression_names, expression_rows = run_statement(
            connection,
            "SELECT course_id, course_id + 1000 AS display_id "
            "FROM courses ORDER BY course_id;",
        )
        after = connection.execute(
            "SELECT course_id, course_title, instructor_id "
            "FROM courses ORDER BY course_id;"
        ).fetchall()

        assert literal_names == ["course_title", "item_type", "example_count"]
        assert expression_names == ["course_id", "display_id"]
        print("Columns:", ", ".join(names))
        print("Rows:", ", ".join(map(str, rows)))
        print("Literal first row:", literal_rows[0])
        print("Expression first row:", expression_rows[0])
        print("Before/after stored rows equal:", before == after)


if __name__ == "__main__":
    main()
