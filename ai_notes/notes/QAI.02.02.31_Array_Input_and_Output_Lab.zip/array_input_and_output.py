"""Guided NumPy array file round trips."""

from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np


def round_trip(folder: Path) -> dict:
    scores = np.array([[10, 20, 30], [40, 50, 60]], dtype=np.int32)
    task_ids = np.array([101, 102], dtype=np.int32)

    binary_path = folder / "scores.npy"
    archive_path = folder / "course_arrays.npz"
    csv_path = folder / "scores.csv"
    changed_path = folder / "scores_changed.npy"

    np.save(binary_path, scores)
    loaded_binary = np.load(binary_path, allow_pickle=False)

    np.savez(archive_path, scores=scores, task_ids=task_ids)
    with np.load(archive_path, allow_pickle=False) as archive:
        archive_keys = set(archive.files)
        loaded_archive_scores = archive["scores"].copy()
        loaded_task_ids = archive["task_ids"].copy()

    np.savetxt(csv_path, scores, fmt="%d", delimiter=",")
    loaded_text = np.loadtxt(csv_path, delimiter=",", dtype=np.int32)

    changed_scores = scores.copy()
    changed_scores[1, 2] = 99
    np.save(changed_path, changed_scores)
    loaded_changed = np.load(changed_path, allow_pickle=False)
    loaded_original_again = np.load(binary_path, allow_pickle=False)

    assert np.array_equal(scores, loaded_binary)
    assert np.array_equal(scores, loaded_archive_scores)
    assert np.array_equal(scores, loaded_text)
    assert np.array_equal(task_ids, loaded_task_ids)
    assert loaded_binary.shape == scores.shape
    assert loaded_binary.dtype == scores.dtype
    assert loaded_text.dtype == scores.dtype
    assert loaded_changed[1, 2] == 99
    assert loaded_original_again[1, 2] == 60

    return {
        "scores": scores,
        "task_ids": task_ids,
        "binary": loaded_binary,
        "archive_scores": loaded_archive_scores,
        "archive_task_ids": loaded_task_ids,
        "archive_keys": archive_keys,
        "text": loaded_text,
        "csv_text": csv_path.read_text(encoding="utf-8"),
        "csv_path": csv_path,
        "changed": loaded_changed,
        "original_again": loaded_original_again,
    }


def main() -> None:
    with TemporaryDirectory() as temporary:
        result = round_trip(Path(temporary))
        print("Binary:", result["binary"].tolist())
        print("Binary shape and dtype:", result["binary"].shape, result["binary"].dtype)
        print("Archive arrays:", sorted(result["archive_keys"]))
        print("Text:", result["text"].tolist())
        print("Text shape and dtype:", result["text"].shape, result["text"].dtype)
        print("All original values match:", all(
            np.array_equal(result["scores"], result[name])
            for name in ("binary", "archive_scores", "text")
        ))
        print("Changed last score:", result["changed"][1, 2])
        print("Original last score:", result["original_again"][1, 2])
        print("All round trips matched.")


if __name__ == "__main__":
    main()
