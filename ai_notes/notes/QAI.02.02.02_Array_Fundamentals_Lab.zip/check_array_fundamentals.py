"""Executable checks for the supplied lab and its boundary cases."""

import numpy as np

from array_fundamentals import describe, learner_total, revise_value, study_minutes


def run_checks():
    original = study_minutes()
    assert isinstance(original, np.ndarray)
    assert original.tolist() == [[20, 10], [30, 15], [40, 20]]
    assert describe(original) == {
        "ndim": 2, "shape": (3, 2), "size": 6,
        "dtype": "int32", "itemsize": 4, "data_bytes": 24,
    }
    assert int(original[1, 0]) == 30
    assert learner_total(original, 1) == 45

    revised = revise_value(original, 1, 1, 18)
    assert revised is not original
    assert learner_total(revised, 1) == 48
    assert original[1, 1] == 15
    assert describe(revised) == describe(original)

    independent = revise_value(original, 2, 0, 50)
    assert learner_total(independent, 2) == 70
    assert original[2, 0] == 40

    try:
        _ = original[3, 0]
    except IndexError:
        pass
    else:
        raise AssertionError("Expected an invalid first index to fail")

    empty = np.array([], dtype=np.int32)
    assert describe(empty) == {
        "ndim": 1, "shape": (0,), "size": 0,
        "dtype": "int32", "itemsize": 4, "data_bytes": 0,
    }
    assert learner_total(empty.reshape(1, 0), 0) == 0
    print("All array fundamentals checks passed.")


if __name__ == "__main__":
    run_checks()
