# Multi-dimensional indexing lab

Run in this folder:

```sh
python -m pip install -r requirements.txt
python multi_dimensional_indexing.py
python check_multi_dimensional_indexing.py
```

Use `python3` if needed. Predict both the values and shapes of selected sub-arrays before running. Complete the independent two-day task, then compare with `python mini_project_reference.py`. The supplied examples were checked with NumPy 2.3.5. Selections with `:` in this lab are read-only demonstrations; view and copy behavior is covered in a later lesson.
