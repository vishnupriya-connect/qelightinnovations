"""Complete reference solution for a practice question bank."""

import numpy as np


def main():
    questions = np.array([101, 102, 103, 104])
    rng = np.random.default_rng(31)
    dice = rng.integers(1, 7, size=8)
    uniform = rng.random(5)
    normal = rng.normal(loc=10, scale=2, size=5)
    with_replacement = rng.choice(questions, size=6, replace=True)
    without_replacement = rng.choice(questions, size=3, replace=False)
    permutation = rng.permutation(questions)
    shuffled = questions.copy()
    returned = rng.shuffle(shuffled)
    print("dice", dice.shape, bool(np.all((dice >= 1) & (dice < 7))))
    print("uniform", uniform.shape, bool(np.all((uniform >= 0) & (uniform < 1))))
    print("normal", normal.shape)
    print("with replacement", with_replacement.shape,
          bool(np.all(np.isin(with_replacement, questions))),
          np.unique(with_replacement).size < with_replacement.size)
    print("without replacement", without_replacement.shape,
          bool(np.all(np.isin(without_replacement, questions))),
          np.unique(without_replacement).size == without_replacement.size)
    print("permutation", permutation.shape,
          bool(np.array_equal(np.sort(permutation), np.sort(questions))))
    print("shuffle", shuffled.shape,
          bool(np.array_equal(np.sort(shuffled), np.sort(questions))), returned)
    print("original", questions.tolist())


if __name__ == "__main__":
    main()
