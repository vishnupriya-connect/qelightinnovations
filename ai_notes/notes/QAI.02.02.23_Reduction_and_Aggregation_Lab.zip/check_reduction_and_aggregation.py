"""Check whole, row, column, indexed, and cumulative results."""

import numpy as np

from reduction_and_aggregation import make_counts


def main():
    counts = make_counts()
    assert counts.shape == (2, 3)
    assert np.sum(counts) == 21 and np.mean(counts) == 3.5
    assert counts.sum() == np.sum(counts)
    assert np.sum(counts, axis=1).shape == (2,)
    assert np.sum(counts, axis=0).shape == (3,)
    assert np.sum(counts, axis=1).tolist() == [6, 15]
    assert np.sum(counts, axis=0).tolist() == [5, 7, 9]
    assert np.mean(counts, axis=1).tolist() == [2.0, 5.0]
    assert np.mean(counts, axis=0).tolist() == [2.5, 3.5, 4.5]
    assert (np.min(counts), np.max(counts), np.median(counts)) == (1, 6, 3.5)
    assert np.min(counts, axis=1).tolist() == [1, 4]
    assert np.max(counts, axis=0).tolist() == [4, 5, 6]
    assert np.median(counts, axis=1).tolist() == [2.0, 5.0]
    assert np.allclose(np.var(counts, axis=1), [2 / 3, 2 / 3])
    assert np.allclose(np.std(counts, axis=1), np.sqrt([2 / 3, 2 / 3]))
    assert np.isclose(np.var(counts), 35 / 12)
    assert np.isclose(np.std(counts) ** 2, np.var(counts))
    assert np.var(counts, ddof=1) != np.var(counts)
    assert (np.argmin(counts), np.argmax(counts)) == (0, 5)
    assert np.argmin(counts, axis=1).tolist() == [0, 0]
    assert np.argmax(counts, axis=1).tolist() == [2, 2]
    assert counts[1, np.argmax(counts[1])] == 6
    assert np.cumsum(counts, axis=1).tolist() == [[1, 3, 6], [4, 9, 15]]
    assert np.cumprod(counts, axis=1).tolist() == [[1, 2, 6], [4, 20, 120]]
    assert np.cumsum(counts, axis=0).tolist() == [[1, 2, 3], [5, 7, 9]]
    assert np.cumsum(counts).shape == np.cumprod(counts).shape == (6,)
    ties = np.array([4, 1, 1])
    assert np.argmin(ties) == 1
    changed = counts.copy()
    changed[1, 2] = 9
    assert np.sum(changed, axis=1)[1] == 18
    assert np.sum(changed, axis=0)[2] == 12
    assert np.max(changed, axis=1)[1] == 9
    assert counts[1, 2] == 6
    print("All checks passed.")


if __name__ == "__main__":
    main()
