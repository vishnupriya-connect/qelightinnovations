"""Reference solution for the two-learner, three-activity task."""

import numpy as np

from fixed_value_arrays import initialized_buffer


def main():
    shape = (2, 3)
    recorded = np.zeros(shape, dtype=np.int32)
    weights = np.ones(shape, dtype=np.int32)
    planned = np.full(shape, 7, dtype=np.int32)
    for name, array in [("Recorded counts", recorded), ("Weights", weights), ("Plan", planned)]:
        print(f"{name}: shape={array.shape}, total={int(array.sum())}, values={array.tolist()}")

    identity = np.identity(3, dtype=np.int32)
    eye = np.eye(2, 3, dtype=np.int32)
    print("Identity:", identity.shape, identity.tolist())
    print("Rectangular eye:", eye.shape, eye.tolist())
    filled_buffer = initialized_buffer(shape, 4)
    print("Filled buffer:", filled_buffer.shape, int(filled_buffer.sum()), filled_buffer.tolist())


if __name__ == "__main__":
    main()
