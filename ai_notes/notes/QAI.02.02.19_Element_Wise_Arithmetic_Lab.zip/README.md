# Element-wise arithmetic lab

Run with Python 3:

```bash
python -m pip install -r requirements.txt
python element_wise_arithmetic.py
python check_element_wise_arithmetic.py
python mini_project_reference.py
```

Predict every result at coordinate `[0, 1]` before running. Try the controlled variation described in the companion notes.
