"""Reference for the independent three-day results-grid task."""

import numpy as np

from array_inspection import inspect_array, require_layout


def main():
    rows = [
        [1.5, 2.0, 2.5, 3.0],
        [2.5, 3.0, 3.5, 4.0],
        [3.5, 4.0, 4.5, 5.0],
    ]
    grid = np.array(rows, dtype=np.float32)
    print("Display:")
    print(grid)
    print("Representation:", repr(grid))
    print("Inspection:", inspect_array(grid))
    print("Calculated element bytes:", grid.size * grid.itemsize)
    print("Validated:", require_layout(grid, (3, 4), np.float32))

    wider = grid.astype(np.float64)
    print("Wider type:", inspect_array(wider))
    swapped = np.array([
        [1.5, 2.0, 2.5], [3.0, 2.5, 3.0],
        [3.5, 4.0, 3.5], [4.0, 4.5, 5.0],
    ], dtype=np.float32)
    print("Swapped shape:", inspect_array(swapped))
    try:
        require_layout(swapped, (3, 4), np.float32)
    except ValueError as error:
        print("Detected:", error)


if __name__ == "__main__":
    main()
