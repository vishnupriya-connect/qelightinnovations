"""Choose between values and bound readings element by element."""

import numpy as np


def make_examples():
    readings = np.array([[-5, 45, 110], [20, 75, 95]])
    thresholds = np.array([[0, 50, 100], [10, 80, 90]])
    return readings, thresholds


def bounded(readings, lower, upper):
    """Require a meaningful interval before clipping."""
    if lower > upper:
        raise ValueError("Lower bound must not exceed upper bound")
    return np.clip(readings, lower, upper)


def main():
    readings, thresholds = make_examples()
    condition = readings >= 50
    print("Condition:", condition.tolist())
    print("Selected:", np.where(condition, readings, 0).tolist())
    print("Clipped:", bounded(readings, 0, 100).tolist())
    print("Lower bound:", np.maximum(readings, 0).tolist())
    print("Upper bound:", np.minimum(readings, 100).tolist())
    print("Element-wise thresholds:", np.maximum(readings, thresholds).tolist())
    print("Source:", readings.tolist())
    changed = readings.copy()
    changed[0, 1] = 55
    print("Variation:", bool(changed[0, 1] >= 50),
          np.where(changed >= 50, changed, 0)[0, 1],
          bounded(changed, 0, 100)[0, 1],
          "original:", readings[0, 1])


if __name__ == "__main__":
    main()
