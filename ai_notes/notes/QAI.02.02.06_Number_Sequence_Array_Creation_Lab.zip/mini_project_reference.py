"""Reference solution for the independent checkpoint plans."""

import numpy as np


def main():
    plans = {
        "Every 3, stop before 16": np.arange(3, 16, 3),
        "Five inclusive percentages": np.linspace(0, 100, num=5),
        "Four powers of two": np.logspace(0, 3, num=4, base=2),
        "Four exclusive percentages": np.linspace(0, 100, num=4, endpoint=False),
        "Changed step to 4": np.arange(3, 16, 4),
    }
    for label, array in plans.items():
        print(f"{label}: {array.tolist()} (size {array.size})")


if __name__ == "__main__":
    main()
