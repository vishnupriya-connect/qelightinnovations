"""Check element positions, domains, approximate results, and function kinds."""

import numpy as np

from universal_functions import make_examples, real_logs, real_roots


def main():
    differences, counts, exponents, angles, measurements = make_examples()
    assert differences.shape == np.abs(differences).shape == np.square(differences).shape == (2, 3)
    assert np.abs(differences).tolist() == [[3.0, 0.0, 4.0], [5.0, 1.0, 2.0]]
    assert np.square(differences).tolist() == [[9.0, 0.0, 16.0], [25.0, 1.0, 4.0]]
    assert real_roots(counts).tolist() == [0.0, 1.0, 2.0, 3.0]
    growth = np.exp(exponents)
    assert np.allclose(growth, [1, np.e, np.e ** 2])
    assert np.allclose(real_logs(growth), exponents)
    assert np.round(growth, 3).tolist() == [1.0, 2.718, 7.389]
    assert np.allclose(np.sin(angles), [0, 1, 0], atol=1e-12)
    assert np.allclose(np.cos(angles), [1, 0, -1], atol=1e-12)
    assert np.round(np.sin(angles), 6).tolist() == [0.0, 1.0, 0.0]
    assert np.floor(measurements).tolist() == [-2.0, -2.0, 1.0, 1.0]
    assert np.ceil(measurements).tolist() == [-1.0, -1.0, 2.0, 2.0]
    assert np.round(measurements).tolist() == [-2.0, -1.0, 1.0, 2.0]
    assert np.round([2.5, 3.5]).tolist() == [2.0, 4.0]
    assert np.add([1, 2, 3], [10, 20, 30]).tolist() == [11, 22, 33]
    assert isinstance(np.abs, np.ufunc)
    assert isinstance(np.add, np.ufunc)
    assert not isinstance(np.round, np.ufunc)
    changed = differences.copy()
    changed[0, 0] = -6
    assert np.abs(changed)[0, 0] == 6
    assert np.square(changed)[0, 0] == 36
    assert differences[0, 0] == -3
    for function, bad in (
        (real_roots, np.array([-1.0, 4.0])),
        (real_logs, np.array([0.0, 1.0])),
        (real_logs, np.array([-1.0, 1.0])),
    ):
        try:
            function(bad)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid real-domain input was accepted")
    print("All checks passed.")


if __name__ == "__main__":
    main()
