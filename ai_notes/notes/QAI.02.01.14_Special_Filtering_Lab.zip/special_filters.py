"""Run special SQL filters against a small, private course catalogue."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4, "intro"),
    (102, "Git Basics", 8, 50, 3, None),
    (103, "Data Basics", 7, 80, 4, "tables"),
    (104, "Python Basics", 8, 65, 3, None),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT
        );"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?);", COURSES)
    db.commit()
    return db


def ids(db, condition, parameters=()):
    """Return ordered course IDs. Pass values with bound parameters."""
    query = (
        "SELECT course_id FROM course_catalogue WHERE "
        + condition
        + " ORDER BY course_id;"
    )
    return [row[0] for row in db.execute(query, parameters)]


def selected_courses(db):
    """Reference project: short Basics courses that need topic notes."""
    return db.execute(
        """SELECT course_id, title
        FROM course_catalogue
        WHERE title LIKE ?
          AND topic_note IS NULL
          AND duration_minutes BETWEEN ? AND ?
        ORDER BY course_id;""",
        ("%Basics", 50, 65),
    ).fetchall()


def independent_variation(db):
    """Reference variation: longer courses with a topic note."""
    return ids(
        db,
        "duration_minutes BETWEEN ? AND ? AND topic_note IS NOT NULL",
        (65, 95),
    )


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("IN 101, 104:", ids(db, "course_id IN (?, ?)", (101, 104)))
        print("NOT IN 101, 104:", ids(db, "course_id NOT IN (?, ?)", (101, 104)))
        print("BETWEEN 50 and 80:", ids(db, "duration_minutes BETWEEN ? AND ?", (50, 80)))
        print("Prefix Data:", ids(db, "title LIKE ?", ("Data%",)))
        print("Suffix Basics:", ids(db, "title LIKE ?", ("%Basics",)))
        print("Substring Basic:", ids(db, "title LIKE ?", ("%Basic%",)))
        print("One-character ending:", ids(db, "title LIKE ?", ("Git Basic_",)))
        print("Missing notes:", ids(db, "topic_note IS NULL"))
        print("Present notes:", ids(db, "topic_note IS NOT NULL"))
        print("Project rows:", selected_courses(db))
        print("Independent variation:", independent_variation(db))
        after = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Stored rows unchanged:", before == after)


if __name__ == "__main__":
    main()
