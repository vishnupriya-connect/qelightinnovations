# Array references, views, and copies lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python array_references_views_copies.py
python check_array_references_views_copies.py
```

Use `python3` if needed. Predict identity, memory sharing, and before/after values first. Complete the study-record mini-project, then compare with `python mini_project_reference.py`. Examples were checked with NumPy 2.3.5. The object-array demonstration uses Python's standard `copy.deepcopy` for the nested dictionary and list.
