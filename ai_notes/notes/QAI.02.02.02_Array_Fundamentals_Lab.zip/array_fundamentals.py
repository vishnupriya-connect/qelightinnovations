"""Inspect and change a small NumPy array of study minutes."""

import numpy as np


def study_minutes():
    return np.array([[20, 10], [30, 15], [40, 20]], dtype=np.int32)


def describe(array):
    return {
        "ndim": array.ndim,
        "shape": array.shape,
        "size": array.size,
        "dtype": str(array.dtype),
        "itemsize": array.itemsize,
        "data_bytes": array.size * array.itemsize,
    }


def learner_total(array, learner_index):
    return int(np.sum(array[learner_index]))


def revise_value(array, learner_index, activity_index, new_value):
    revised = array.copy()
    revised[learner_index, activity_index] = new_value
    return revised


def main():
    original = study_minutes()
    print("Array type:", type(original).__name__)
    print("Original:", original.tolist())
    print("Properties:", describe(original))
    print("B reading:", int(original[1, 0]))
    print("B total:", learner_total(original, 1))

    revised = revise_value(original, 1, 1, 18)
    print("Revised B total:", learner_total(revised, 1))
    print("Original B practice:", int(original[1, 1]))
    print("Revised properties:", describe(revised))

    try:
        print(original[3, 0])
    except IndexError as error:
        print("Invalid index:", type(error).__name__)


if __name__ == "__main__":
    main()
