# Database and table definition lab

From this unzipped folder, use Python 3:

```sh
python schema_lab.py
python check_schema_lab.py
```

Use `python3` if needed. The lab requires SQLite 3.35.0 or newer (`python -c "import sqlite3; print(sqlite3.sqlite_version)"`). It uses a private temporary database file and an in-memory database. It does not access an existing database or require a server.

Predict each schema change before running. Attempt the independent `course_tags` variation in the lesson before opening its reference in `check_schema_lab.py`. Record your predicted and actual columns, the error and fix, and the unchanged row values.
