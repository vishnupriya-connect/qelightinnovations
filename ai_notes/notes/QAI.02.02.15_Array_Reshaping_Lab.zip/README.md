# Array reshaping lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python array_reshaping.py
python check_array_reshaping.py
```

Use `python3` if needed. Predict element count, shape, value order, and memory sharing before running. Complete the independent score-grid task, then compare with `python mini_project_reference.py`. Examples were checked with NumPy 2.3.5. The resize and shape-assignment demonstrations use separate, fresh owning arrays.
