"""Use SQLite expressions to build calculated columns for a course catalogue."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4),
    (102, "Git Basics", 8, 50, 3),
    (103, "Data Basics", 7, 80, 4),
    (104, "Python Basics", 8, 65, 3),
]


def make_connection():
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE course_catalogue (
               course_id INTEGER PRIMARY KEY,
               title TEXT NOT NULL,
               instructor_id INTEGER NOT NULL,
               duration_minutes INTEGER NOT NULL,
               lesson_count INTEGER NOT NULL
           );"""
    )
    connection.executemany(
        "INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?);", COURSES
    )
    connection.commit()
    return connection


def query(connection, sql):
    cursor = connection.execute(sql)
    return [column[0] for column in cursor.description], cursor.fetchall()


def course_preview(connection):
    """One complete, read-only calculated catalogue preview."""
    return query(
        connection,
        "SELECT course_id, title, duration_minutes, "
        "duration_minutes + 10 AS extended_minutes, "
        "duration_minutes % 30 AS leftover_minutes, "
        "title || ' (' || course_id || ')' AS label "
        "FROM course_catalogue ORDER BY course_id;",
    )


def lesson_split(connection):
    """Reference for the independent whole-minutes/remainder variation."""
    return query(
        connection,
        "SELECT course_id, duration_minutes / lesson_count AS whole_minutes, "
        "duration_minutes % lesson_count AS leftover_minutes "
        "FROM course_catalogue ORDER BY course_id;",
    )


def main():
    with make_connection() as connection:
        before = query(
            connection, "SELECT course_id, duration_minutes "
            "FROM course_catalogue ORDER BY course_id;"
        )[1]
        calculations = query(
            connection,
            "SELECT course_id, duration_minutes + 10 AS plus_10, "
            "duration_minutes - 5 AS minus_5, "
            "duration_minutes * 2 AS twice, "
            "duration_minutes / lesson_count AS whole_per_lesson, "
            "duration_minutes % lesson_count AS leftover "
            "FROM course_catalogue ORDER BY course_id;",
        )
        precedence = query(
            connection,
            "SELECT duration_minutes + 10 * lesson_count AS without_grouping, "
            "(duration_minutes + 10) * lesson_count AS with_grouping "
            "FROM course_catalogue ORDER BY course_id;",
        )[1]
        first_real_average = query(
            connection,
            "SELECT duration_minutes * 1.0 / lesson_count AS average "
            "FROM course_catalogue ORDER BY course_id;",
        )[1][0][0]
        label = query(
            connection,
            "SELECT title || ' (' || course_id || ')' AS label "
            "FROM course_catalogue ORDER BY course_id;",
        )[1][0][0]
        divide_by_zero = query(connection, "SELECT 1 / 0 AS result;")[1][0][0]
        after = query(
            connection, "SELECT course_id, duration_minutes "
            "FROM course_catalogue ORDER BY course_id;"
        )[1]

        print("Arithmetic headings:", ", ".join(calculations[0]))
        print("Arithmetic first row:", calculations[1][0])
        print("Precedence first row:", precedence[0])
        print("Real division first row:", first_real_average)
        print("First text label:", label)
        print("Divide by zero is NULL:", divide_by_zero is None)
        print("Source durations unchanged:", before == after)


if __name__ == "__main__":
    main()
