"""Read forward, reverse, stepped, row, and column slices."""

import numpy as np


def example_arrays():
    minutes = np.array([10, 20, 30, 40, 50, 60], dtype=np.int32)
    work = np.array([
        [10, 11, 12, 13],
        [20, 21, 22, 23],
        [30, 31, 32, 33],
        [40, 41, 42, 43],
    ], dtype=np.int32)
    return minutes, work


def one_dimensional_slices(minutes):
    return {
        "range": minutes[1:5],
        "front": minutes[:3],
        "tail": minutes[3:],
        "negative_start": minutes[-3:],
        "step": minutes[1:6:2],
        "reverse": minutes[::-1],
        "reverse_step": minutes[5:1:-2],
        "clipped": minutes[4:99],
        "empty": minutes[2:2],
    }


def two_dimensional_slices(work):
    return {
        "rows": work[1:3, :],
        "columns": work[:, 1:3],
        "block": work[1:4:2, 0:4:2],
        "reverse_rows": work[::-1, :],
        "reverse_columns": work[:, ::-1],
        "wrong_stop": work[1:3, 1:2],
        "correct_stop": work[1:3, 1:3],
    }


def changed_source_slice():
    changed = np.array([10, 20, 30, 45, 50, 60], dtype=np.int32)
    return changed[1:6:2], changed[::-1]


def main():
    minutes, work = example_arrays()
    for name, selection in one_dimensional_slices(minutes).items():
        print(f"1D {name}: {selection.tolist()} shape={selection.shape}")
    for name, selection in two_dimensional_slices(work).items():
        print(f"2D {name}: {selection.tolist()} shape={selection.shape}")
    stepped, reversed_values = changed_source_slice()
    print("Changed stepped:", stepped.tolist())
    print("Changed reversed first three:", reversed_values[:3].tolist())
    try:
        _ = minutes[::0]
    except ValueError as error:
        print("Zero step:", type(error).__name__)


if __name__ == "__main__":
    main()
