"""Check equality, inequalities, logic, reductions, and one variation."""

import numpy as np

from element_wise_comparison_and_logic import conditions, make_arrays


def main():
    scores, targets = make_arrays()
    assert scores.shape == targets.shape == (2, 3)
    assert (scores == targets).tolist() == [[False, False, True], [False, False, False]]
    assert (scores != targets).tolist() == [[True, True, False], [True, True, True]]
    assert (scores > targets).tolist() == [[True, False, False], [False, True, False]]
    assert (scores < targets).tolist() == [[False, True, False], [True, False, True]]
    assert (scores >= targets)[0, 2] and (scores <= targets)[0, 2]
    high, qualifies, attention = conditions(scores, targets)
    assert high.dtype == np.dtype("bool") and high.shape == scores.shape
    assert high.tolist() == [[True, False, True], [False, True, False]]
    assert qualifies.tolist() == [[True, False, False], [False, True, False]]
    assert attention.tolist() == [[False, True, True], [False, False, False]]
    assert np.logical_not(high).tolist() == [[False, True, False], [True, False, True]]
    assert np.array_equal(qualifies, (scores >= 70) & (scores < 90))
    assert np.array_equal(attention, (scores < 50) | (scores == 90))
    assert np.array_equal(np.logical_not(high), ~high)
    assert bool(np.any(scores < 50)) is True
    assert bool(np.all(scores >= 50)) is False
    assert np.any(scores < 50, axis=1).tolist() == [True, False]
    assert np.all(scores >= 50, axis=1).tolist() == [False, True]
    assert np.any(scores < 50, axis=0).tolist() == [False, True, False]
    try:
        bool(high)
    except ValueError:
        pass
    else:
        raise AssertionError("A multi-element array is not a single truth value")
    changed = scores.copy()
    changed[0, 2] = 85
    _, new_qualifies, new_attention = conditions(changed, targets)
    assert changed[0, 2] < targets[0, 2]
    assert new_qualifies[0, 2] and not new_attention[0, 2]
    assert scores[0, 2] == 90
    print("All checks passed.")


if __name__ == "__main__":
    main()
