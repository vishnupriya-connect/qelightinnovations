"""Run ordinary, multiple, and bounded recursive CTEs on course data."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95),
    (102, "Git Basics", 8, 50),
    (103, "Data Basics", 7, 80),
    (104, "Python Basics", 8, 65),
    (105, "SQL Basics", 42, 70),
]
# (course_id, prerequisite_id): course_id requires prerequisite_id.
PREREQUISITES = [(103, 101), (104, 101), (105, 103)]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY, title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL, duration_minutes INTEGER NOT NULL
        )"""
    )
    db.execute(
        """CREATE TABLE course_prerequisites (
            course_id INTEGER NOT NULL, prerequisite_id INTEGER NOT NULL
        )"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?)", COURSES)
    db.executemany("INSERT INTO course_prerequisites VALUES (?, ?)", PREREQUISITES)
    db.commit()
    return db


def long_courses(db, minimum=70):
    return db.execute(
        """WITH long_courses AS (
             SELECT course_id, title, duration_minutes
             FROM course_catalogue WHERE duration_minutes >= ?
           )
           SELECT course_id, title FROM long_courses ORDER BY course_id""",
        (minimum,),
    ).fetchall()


def multiple_ctes(db, minimum=70):
    return db.execute(
        """WITH long_courses AS (
             SELECT course_id, duration_minutes FROM course_catalogue
             WHERE duration_minutes >= ?
           ),
           duration_summary AS (
             SELECT COUNT(*) AS course_count,
                    SUM(duration_minutes) AS total_minutes FROM long_courses
           )
           SELECT course_count, total_minutes FROM duration_summary""",
        (minimum,),
    ).fetchone()


def path_from(db, root_id=101, max_depth=2):
    """Bound recursion by depth; root is included at depth zero."""
    if not isinstance(max_depth, int) or isinstance(max_depth, bool) or max_depth < 0:
        raise ValueError("max_depth must be a nonnegative integer")
    return db.execute(
        """WITH RECURSIVE path(course_id, depth) AS (
             SELECT course_id, 0 FROM course_catalogue WHERE course_id = ?
             UNION ALL
             SELECT edge.course_id, path.depth + 1
             FROM course_prerequisites AS edge
             JOIN path ON edge.prerequisite_id = path.course_id
             WHERE path.depth < ?
           )
           SELECT path.course_id, c.title, path.depth
           FROM path JOIN course_catalogue AS c ON c.course_id = path.course_id
           ORDER BY path.depth, path.course_id""",
        (root_id, max_depth),
    ).fetchall()


def main():
    with make_connection() as db:
        before_courses = db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall()
        before_edges = db.execute(
            "SELECT * FROM course_prerequisites ORDER BY course_id"
        ).fetchall()
        print("Long courses:", long_courses(db))
        print("Multiple CTE summary:", multiple_ctes(db))
        print("Root 101 through depth 2:", path_from(db))
        print("Root 103 through depth 2:", path_from(db, 103, 2))
        print("Root 101 through depth 1:", path_from(db, 101, 1))
        print("Stored tables unchanged:", before_courses == db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() and before_edges == db.execute(
            "SELECT * FROM course_prerequisites ORDER BY course_id"
        ).fetchall())


if __name__ == "__main__":
    main()
