"""Isolated positive and negative cases with repeatable assertions."""
import sqlite3
from integrity import open_connection, seed


def new_db(max_capacity=100):
    db = open_connection(max_capacity=max_capacity)
    seed(db)
    return db


def rejected(name, statement, values, table, message_part, max_capacity=100):
    db = new_db(max_capacity)
    before = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    try:
        with db:
            db.execute(statement, values)
    except sqlite3.IntegrityError as exc:
        after = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        assert before == after, name
        assert message_part in str(exc), f"{name}: unexpected error: {exc}"
        print(f"REJECT {name}: {exc}; rows unchanged")
    else:
        raise AssertionError(f"Unexpected acceptance: {name}")
    finally:
        db.close()


def accepted(name, statement, values, max_capacity=100):
    db = new_db(max_capacity)
    with db:
        db.execute(statement, values)
    print(f"ACCEPT {name}")
    db.close()


if __name__ == "__main__":
    rejected("duplicate learner ID", "INSERT INTO learners VALUES (?, ?, ?)",
             (1, "another@example.org", "Other"), "learners", "UNIQUE constraint failed")
    rejected("duplicate course code", "INSERT INTO courses "
             "(course_id, course_code, title, capacity) VALUES (?, ?, ?, ?)",
             (103, "AI-FOUND", "Other", 20), "courses", "UNIQUE constraint failed")
    rejected("missing learner name", "INSERT INTO learners VALUES (?, ?, ?)",
             (3, "meera@example.org", None), "learners", "NOT NULL constraint failed")
    rejected("blank learner name", "INSERT INTO learners VALUES (?, ?, ?)",
             (3, "meera@example.org", "  "), "learners", "CHECK constraint failed")
    for capacity in (0, 101):
        rejected(f"capacity {capacity}",
                 "INSERT INTO courses (course_id, course_code, title, capacity) "
                 "VALUES (?, ?, ?, ?)",
                 (103, "DATA-INTRO", "Data Introduction", capacity),
                 "courses", "CHECK constraint failed")
    rejected("invalid published value", "INSERT INTO courses "
             "(course_id, course_code, title, capacity, published) VALUES (?, ?, ?, ?, ?)",
             (103, "DATA-INTRO", "Data Introduction", 20, 2),
             "courses", "CHECK constraint failed")
    rejected("unknown learner", "INSERT INTO enrolments VALUES (?, ?)",
             (999, 101), "enrolments", "FOREIGN KEY constraint failed")
    rejected("duplicate enrolment pair", "INSERT INTO enrolments VALUES (?, ?)",
             (1, 101), "enrolments", "UNIQUE constraint failed")
    rejected("explicit null published value", "INSERT INTO courses "
             "(course_id, course_code, title, capacity, published) VALUES (?, ?, ?, ?, ?)",
             (103, "DATA-INTRO", "Data Introduction", 20, None),
             "courses", "NOT NULL constraint failed")
    accepted("capacity 50 under stricter rule", "INSERT INTO courses "
             "(course_id, course_code, title, capacity) VALUES (?, ?, ?, ?)",
             (103, "DATA-INTRO", "Data Introduction", 50), max_capacity=50)
    rejected("capacity 51 under stricter rule", "INSERT INTO courses "
             "(course_id, course_code, title, capacity) VALUES (?, ?, ?, ?)",
             (103, "DATA-INTRO", "Data Introduction", 51), "courses",
             "CHECK constraint failed", max_capacity=50)
    print("PASS: 10 invalid cases rejected; 1 valid case accepted; stricter limit verified")
