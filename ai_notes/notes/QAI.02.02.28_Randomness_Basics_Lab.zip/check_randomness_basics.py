"""Check seed replay, state advance, child streams, and snapshot restore."""

from copy import deepcopy

import numpy as np

from randomness_basics import same_seed_batches


def main():
    first_l, first_r, second_l, second_r = same_seed_batches()
    assert first_l.shape == first_r.shape == second_l.shape == second_r.shape == (3,)
    assert np.array_equal(first_l, first_r)
    assert np.array_equal(second_l, second_r)
    reference = np.random.default_rng(42)
    assert np.array_equal(first_l, reference.random(3))
    assert np.array_equal(second_l, reference.random(3))
    a = np.random.default_rng(7)
    b = np.random.default_rng(7)
    assert a is not b
    assert a.random() == b.random()
    a.random()
    ref = np.random.default_rng(7)
    ref.random()
    assert b.random() == ref.random()
    root = np.random.SeedSequence(2026)
    child_a, child_b = root.spawn(2)
    sim_a, sim_b = np.random.default_rng(child_a), np.random.default_rng(child_b)
    repeated_root = np.random.SeedSequence(2026)
    repeated_a, repeated_b = repeated_root.spawn(2)
    assert sim_a is not sim_b
    assert np.array_equal(sim_a.random(5), np.random.default_rng(repeated_a).random(5))
    assert np.array_equal(sim_b.random(5), np.random.default_rng(repeated_b).random(5))
    rng = np.random.default_rng(11)
    rng.random(2)
    snapshot = deepcopy(rng.bit_generator.state)
    observed = rng.random(3)
    rng.bit_generator.state = snapshot
    assert np.array_equal(observed, rng.random(3))
    x = np.random.default_rng(42)
    y = np.random.default_rng(42)
    fourth_x = x.random(4)[3]
    y.random(3)
    control = np.random.default_rng(42)
    control.random(3)
    assert fourth_x == control.random() == y.random()
    print("All checks passed.")


if __name__ == "__main__":
    main()
