"""Read and update positions in a one-dimensional study log."""

import numpy as np


def study_minutes():
    return np.array([12, 18, 15, 20], dtype=np.int32)


def read_at(array, index):
    """Read an element; NumPy reports an out-of-bounds index."""
    return int(array[index])


def updated_copy(array, index, new_value):
    updated = array.copy()
    updated[index] = new_value
    return updated


def main():
    original = study_minutes()
    print("Source:", original.tolist(), "shape:", original.shape)
    for index in (0, 1, 2, 3, -4, -3, -2, -1):
        print(f"Index {index}: {read_at(original, index)}")

    corrected = updated_copy(original, 2, 17)
    corrected[-1] = 22
    print("Updated copy:", corrected.tolist())
    print("Original:", original.tolist())

    controlled = updated_copy(original, 2, 19)
    print("Controlled [2] and [-2]:", read_at(controlled, 2), read_at(controlled, -2))
    print("Original [2]:", read_at(original, 2))
    for invalid in (4, -5):
        try:
            read_at(original, invalid)
        except IndexError as error:
            print(f"Invalid {invalid}: {type(error).__name__}")
    print("Repaired day 4:", read_at(original, 3))
    print("Repaired first day:", read_at(original, -4))


if __name__ == "__main__":
    main()
