"""Estimate the frequency of an even die face in repeated batches."""

import numpy as np


def run_even_die(n, rng):
    if n <= 0:
        raise ValueError("Number of trials must be positive")
    rolls = rng.integers(1, 7, size=n)
    successes = int(np.sum(rolls % 2 == 0))
    return rolls, successes, successes / n


def compare_events(rolls):
    if rolls.size == 0:
        raise ValueError("At least one trial is required")
    even_count = int(np.sum(rolls % 2 == 0))
    at_least_five_count = int(np.sum(rolls >= 5))
    return ((even_count, even_count / rolls.size),
            (at_least_five_count, at_least_five_count / rolls.size))


def main():
    rng = np.random.default_rng(42)
    rolls, successes, estimate = run_even_die(12, rng)
    print("One run rolls:", rolls.tolist())
    print("One run:", rolls.size, successes, round(estimate, 3))
    print("Event variation (same sample):", compare_events(rolls))
    repeated_rng = np.random.default_rng(19)
    for number in range(3):
        sample, count, fraction = run_even_die(12, repeated_rng)
        print("Repeated run", number + 1, sample.size, count, round(fraction, 3))
    first = run_even_die(12, np.random.default_rng(42))
    replay = run_even_die(12, np.random.default_rng(42))
    print("Reproducible:", np.array_equal(first[0], replay[0]),
          first[1:] == replay[1:])


if __name__ == "__main__":
    main()
