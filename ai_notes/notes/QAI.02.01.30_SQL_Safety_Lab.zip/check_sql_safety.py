"""Check data binding, identifier allowlist, read-only access, and auditing."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory

from sql_safety import (
    AUDIT_EVENTS, open_editor, open_reader, safe_search, setup,
    sorted_courses, unsafe_search, update_duration,
)

with TemporaryDirectory(prefix='qai_sql_safety_check_') as folder:
    path = Path(folder) / 'check.sqlite'
    setup(path)
    reader, editor = open_reader(path), open_editor(path)
    try:
        payload = "x' OR 1=1 --"
        assert unsafe_search(reader, payload) == [(101,), (102,), (103,), (104,)]
        assert safe_search(reader, payload) == []
        assert safe_search(reader, "O'Brien's SQL") == [(104,)]
        assert editor.execute('SELECT COUNT(*) FROM courses').fetchone() == (4,)
        print('Controlled unsafe filter expansion versus bound value: correct')

        assert sorted_courses(reader, 'id')[0][0] == 101
        assert [r[0] for r in sorted_courses(reader, 'title')] == [101, 103, 102, 104]
        try:
            sorted_courses(reader, 'title; DROP TABLE courses')
        except ValueError:
            pass
        else:
            raise AssertionError('unexpected sort key accepted')
        quote_cursor = reader.execute('SELECT quote(?)', ("O'Brien",))
        assert quote_cursor.fetchone() == ("'O''Brien'",)
        quote_cursor.close()
        print('Identifier allowlist and escaped value representation: correct')

        try:
            reader.execute('UPDATE courses SET duration=1 WHERE course_id=101')
        except sqlite3.OperationalError:
            if reader.in_transaction:
                reader.rollback()
        else:
            raise AssertionError('read-only connection allowed write')
        try:
            update_duration(reader, role='reader', actor='learner', course_id=104, duration=70)
        except PermissionError:
            pass
        else:
            raise AssertionError('reader role allowed write')
        assert AUDIT_EVENTS[-1] == {'event': 'write_denied', 'role': 'reader'}
        before_cursor = reader.execute('SELECT duration FROM courses WHERE course_id=104')
        assert before_cursor.fetchone() == (65,)
        before_cursor.close()
        print('Read-only connection and application reader policy: correct')

        update_duration(editor, role='editor', actor='trainer', course_id=104, duration=70)
        after_cursor = reader.execute('SELECT duration FROM courses WHERE course_id=104')
        assert after_cursor.fetchone() == (70,)
        after_cursor.close()
        assert editor.execute('SELECT actor, action, course_id, old_value, new_value FROM audit_log').fetchall() == [
            ('trainer', 'UPDATE_DURATION', 104, 65, 70)
        ]
        try:
            update_duration(editor, role='editor', actor='trainer', course_id=999, duration=70)
        except ValueError:
            pass
        else:
            raise AssertionError('unknown course should fail')
        assert editor.execute('SELECT COUNT(*) FROM audit_log').fetchone() == (1,)
        assert not editor.in_transaction
        print('Editor write and audit commit together; failed write leaves no audit: correct')
    finally:
        reader.close()
        editor.close()
