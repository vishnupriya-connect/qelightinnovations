# Indexes and query performance lab

Requires Python 3 and standard-library `sqlite3`. No server, third-party package, or external dataset is needed.

From the extracted folder:

```sh
python index_performance.py
python check_index_performance.py
```

Use `python3` if needed. The database is regenerated in memory on each run. The program prints the actual query plan and indicative local timing; timing varies by machine and is not graded. The checker verifies result correctness, scan versus indexed lookup, update behavior, uniqueness, and removal of the index. Save the plan lines and the result rows as evidence. Synthetic addresses use the reserved `.invalid` domain.
