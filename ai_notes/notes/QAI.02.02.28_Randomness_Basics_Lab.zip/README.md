# Randomness basics lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python randomness_basics.py
python check_randomness_basics.py
python mini_project_reference.py
```

The programs check relationships between sequences instead of depending on exact printed values. Predict which generator is at which position before running, then try the controlled variation in the companion notes.
