# Simulation lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python simulation.py
python check_simulation.py
python mini_project_reference.py
```

Trace the illustrative sample in the notes first. The checker verifies counts and replay without depending on a particular NumPy random sequence.
