"""Check filled values, shapes, safe initialization, and diagonals."""

import numpy as np

from fixed_value_arrays import (
    diagonal_arrays, initialized_buffer, planned_minutes, standard_arrays,
)


def run_checks():
    zeros, ones, fives = standard_arrays()
    for array, value in [(zeros, 0), (ones, 1), (fives, 5)]:
        assert array.shape == (3, 2)
        assert array.size == 6 and array.dtype == np.dtype("int32")
        assert array.tolist() == [[value, value]] * 3
    assert int(zeros.sum()) == 0
    assert int(ones.sum()) == 6
    assert int(fives.sum()) == 30
    assert planned_minutes(8).tolist() == [[8, 8]] * 3
    assert int(planned_minutes(8).sum()) == 48
    assert initialized_buffer((2, 3), 7).tolist() == [[7, 7, 7]] * 2

    zero_size = np.empty((0, 3), dtype=np.int32)
    assert zero_size.shape == (0, 3) and zero_size.size == 0
    identity, eye, wide, shifted = diagonal_arrays()
    assert identity.tolist() == [[1, 0, 0], [0, 1, 0], [0, 0, 1]]
    assert np.array_equal(identity, eye)
    assert wide.shape == (2, 3) and wide.tolist() == [[1, 0, 0], [0, 1, 0]]
    assert shifted.tolist() == [[0, 1, 0], [0, 0, 1], [0, 0, 0]]
    try:
        np.ones((-1, 2), dtype=np.int32)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected a negative-shape error")
    assert np.ones((3, 2), dtype=np.int32).shape == (3, 2)
    print("All fixed-value array checks passed.")


if __name__ == "__main__":
    run_checks()
