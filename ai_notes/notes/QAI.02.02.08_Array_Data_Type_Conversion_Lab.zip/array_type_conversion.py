"""Examine explicit casts, promotion, and guarded whole-number conversion."""

import numpy as np


def whole_minutes_to_int16(values):
    """Reject missing, fractional, and out-of-range values before casting."""
    array = np.asarray(values, dtype=np.float64)
    if not np.all(np.isfinite(array)):
        raise ValueError("Expected finite measurements")
    if not np.all(array == np.trunc(array)):
        raise ValueError("Expected whole-minute measurements")
    limits = np.iinfo(np.int16)
    if not np.all((array >= limits.min) & (array <= limits.max)):
        raise ValueError("Measurement outside int16 range")
    return array.astype(np.int16)


def conversion_examples():
    counts = np.array([20, 30], dtype=np.int32)
    durations = counts.astype(np.float64)
    promoted = counts + np.array([0.5, 0.25], dtype=np.float64)
    truncated = np.array([2.9, -2.9], dtype=np.float64).astype(np.int32)
    boolean = np.array([0, 2, -3], dtype=np.int32).astype(np.bool_)
    strings = np.array(["10", "20"])
    parsed = strings.astype(np.int32)
    objects = np.array([1, "2"], dtype=object)
    wrapped = np.array([128, 300], dtype=np.int16).astype(np.int8)
    underflowed = np.array([1e-50], dtype=np.float64).astype(np.float32)
    imprecise = np.array([16_777_217], dtype=np.int64).astype(np.float32)
    return locals()


def main():
    e = conversion_examples()
    for name in (
        "counts", "durations", "promoted", "truncated", "boolean",
        "strings", "parsed", "objects", "wrapped", "underflowed", "imprecise",
    ):
        array = e[name]
        print(f"{name}: {array.tolist()} (dtype={array.dtype})")

    for label, values in [
        ("Valid", [20.0, 30.0]),
        ("Fractional", [20.0, 30.5]),
        ("Out of range", [20.0, 40_000.0]),
        ("Not finite", [20.0, float("nan")]),
    ]:
        try:
            converted = whole_minutes_to_int16(values)
            print(f"{label}: {converted.tolist()} (dtype={converted.dtype})")
        except ValueError as error:
            print(f"{label}: rejected — {error}")

    try:
        np.array(["10", "unknown"]).astype(np.int32)
    except ValueError as error:
        print("Unusable numeric text:", type(error).__name__)
    try:
        np.array([128], dtype=np.int16).astype(np.int8, casting="safe")
    except TypeError as error:
        print("Unsafe dtype-level cast:", type(error).__name__)


if __name__ == "__main__":
    main()
