"""Reference solution: a tiny reading log."""

import pandas as pd

reading = pd.DataFrame(
    {"book": ["River", "Sky"], "pages": [12, 15]},
    index=["D1", "D2"],
)
print("rows", reading.index.tolist())
print("columns", reading.columns.tolist())
print("pages", reading["pages"].tolist())
print("column type", type(reading["pages"]).__name__)
print("D2 pages", reading.loc["D2", "pages"])
