"""Complete reference solution for displaying temperature readings."""

import numpy as np


def main():
    temperatures = np.array([[-3, 18, 42], [5, 31, 12]])
    bounded = np.clip(temperatures, 0, 35)
    outside = (temperatures < 0) | (temperatures > 35)
    alerts = np.where(outside, 1, 0)
    warm = np.where(bounded >= 20, bounded, 0)
    print("bounded", bounded.tolist())
    print("alerts", alerts.tolist())
    print("warm", warm.tolist())
    print("lower at 10", np.maximum(temperatures, 10).tolist())
    print("upper at 30", np.minimum(temperatures, 30).tolist())
    print("original", temperatures.tolist())


if __name__ == "__main__":
    main()
