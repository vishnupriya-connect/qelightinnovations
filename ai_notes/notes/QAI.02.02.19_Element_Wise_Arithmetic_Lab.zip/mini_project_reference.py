"""Complete reference solution for the study-time mini-project."""

import numpy as np


def main():
    planned = np.array([[12, 15], [20, 22]])
    done = np.array([[5, 7], [8, 10]])
    remaining = np.subtract(planned, done)
    combined = np.add(planned, done)
    ratio = np.divide(done, planned)
    groups = done // 5
    leftover = np.mod(done, 5)
    squared = np.power(done, 2)
    print("remaining", remaining.tolist())
    print("combined", combined.tolist())
    print("ratio", np.round(ratio, 3).tolist())
    print("groups", groups.tolist())
    print("leftover", leftover.tolist())
    print("squared", squared.tolist())


if __name__ == "__main__":
    main()
