# Random sampling lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python random_sampling.py
python check_random_sampling.py
python mini_project_reference.py
```

Predict which draws can repeat and which operations mutate their inputs. The checker tests properties rather than hard-coded draws. Try the controlled variation in the companion notes.
