"""Check mask meanings, update behavior, and mismatched lengths."""

import numpy as np

from boolean_indexing import raised_selected_copy, study_minutes, task_grid, threshold_report


def run_checks():
    source = study_minutes()
    mask, selected = threshold_report(source, 25)
    assert mask.dtype == np.dtype("bool") and mask.shape == source.shape
    assert mask.tolist() == [False, True, True, False, True]
    assert selected.tolist() == [25, 30, 40] and selected.shape == (3,)
    assert not np.shares_memory(source, selected)
    selected[0] = 99
    assert source.tolist() == [10, 25, 30, 15, 40]
    assert source[(source >= 20) & (source <= 35)].tolist() == [25, 30]
    assert threshold_report(source, 30)[0].tolist() == [False, False, True, False, True]
    assert threshold_report(source, 30)[1].tolist() == [30, 40]
    assert threshold_report(source, 30, False)[1].tolist() == [40]
    empty_mask, empty = threshold_report(source, 100, False)
    assert empty_mask.tolist() == [False] * 5 and empty.shape == (0,)

    updated = raised_selected_copy(source, 25, 5)
    assert updated.tolist() == [10, 30, 35, 15, 45]
    assert source.tolist() == [10, 25, 30, 15, 40]
    direct = source.copy()
    direct[mask] = 99
    assert direct.tolist() == [10, 99, 99, 15, 99]

    work = task_grid()
    element_mask = work >= 10
    assert element_mask.shape == work.shape
    assert element_mask.tolist() == [[True, False, False], [True, True, False]]
    assert work[element_mask].tolist() == [12, 10, 15]
    assert work[element_mask].shape == (3,)
    row_mask = np.array([False, True])
    assert work[row_mask].tolist() == [[10, 15, 5]]
    assert work[row_mask].shape == (1, 3)
    for array, bad_mask in [
        (source, np.array([True, False, True, False])),
        (work, np.array([True, False, True])),
    ]:
        try:
            _ = array[bad_mask]
        except IndexError:
            pass
        else:
            raise AssertionError("Expected mask-shape mismatch")
    print("All Boolean-indexing checks passed.")


if __name__ == "__main__":
    run_checks()
