"""A single course/enrolment example: anomalies, migration, and queries."""
import sqlite3

SAMPLE = [
    (1, "Anu", 101, "AI Foundations", 7, "Nisha", "2026-09-01"),
    (2, "Ravi", 101, "AI Foundations", 7, "Nisha", "2026-09-02"),
    (1, "Anu", 102, "Git Basics", 8, "Kiran", "2026-09-03"),
]


def connect():
    db = sqlite3.connect(":memory:")
    db.execute("PRAGMA foreign_keys = ON")
    assert db.execute("PRAGMA foreign_keys").fetchone()[0] == 1
    return db


def create_flat(db, rows=SAMPLE):
    db.execute("""
        CREATE TABLE enrolment_sheet (
            learner_id INTEGER NOT NULL,
            learner_name TEXT NOT NULL,
            course_id INTEGER NOT NULL,
            course_title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            instructor_name TEXT NOT NULL,
            joined_on TEXT NOT NULL,
            PRIMARY KEY (learner_id, course_id)
        )
    """)
    db.executemany("INSERT INTO enrolment_sheet VALUES (?, ?, ?, ?, ?, ?, ?)", rows)
    db.commit()


def show_anomalies():
    db = connect()
    create_flat(db)
    db.execute("UPDATE enrolment_sheet SET course_title = ? WHERE learner_id = ? AND course_id = ?",
               ("AI Basics", 1, 101))
    titles = db.execute("SELECT course_title FROM enrolment_sheet "
                        "WHERE course_id = 101 ORDER BY learner_id").fetchall()
    assert titles == [("AI Basics",), ("AI Foundations",)]
    print("After changing one enrolment row, course 101 titles:",
          ", ".join(title for (title,) in titles))
    db.close()

    db = connect()
    create_flat(db)
    db.execute("DELETE FROM enrolment_sheet WHERE learner_id = 1 AND course_id = 102")
    missing = db.execute("SELECT COUNT(*) FROM enrolment_sheet WHERE course_id = 102").fetchone()[0]
    assert missing == 0
    print("After removing the last enrolment, remaining course 102 rows:", missing)
    db.close()


def records_by_key(rows, id_index, value_indices, label):
    """Reject inconsistent repeated facts; do not arbitrarily keep one value."""
    mapping = {}
    for row in rows:
        identifier = row[id_index]
        values = tuple(row[i] for i in value_indices)
        if identifier in mapping and mapping[identifier] != values:
            raise ValueError(f"Conflicting {label} details for ID {identifier}")
        mapping[identifier] = values
    return mapping


def migrate(db):
    rows = db.execute("SELECT * FROM enrolment_sheet ORDER BY learner_id, course_id").fetchall()
    learners = records_by_key(rows, 0, (1,), "learner")
    courses = records_by_key(rows, 2, (3, 4), "course")
    instructors = records_by_key(rows, 4, (5,), "instructor")
    # Every key and referenced value is checked before making the four tables.
    # executescript can commit an existing transaction; start a new one explicitly.
    db.executescript("""
        BEGIN;
        CREATE TABLE learners (
            learner_id INTEGER PRIMARY KEY,
            learner_name TEXT NOT NULL
        );
        CREATE TABLE instructors (
            instructor_id INTEGER PRIMARY KEY,
            instructor_name TEXT NOT NULL
        );
        CREATE TABLE courses (
            course_id INTEGER PRIMARY KEY,
            course_title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL REFERENCES instructors(instructor_id)
        );
        CREATE TABLE enrolments (
            learner_id INTEGER NOT NULL REFERENCES learners(learner_id),
            course_id INTEGER NOT NULL REFERENCES courses(course_id),
            joined_on TEXT NOT NULL,
            PRIMARY KEY (learner_id, course_id)
        );
    """)
    try:
        db.executemany("INSERT INTO learners VALUES (?, ?)",
                       [(key, *values) for key, values in sorted(learners.items())])
        db.executemany("INSERT INTO instructors VALUES (?, ?)",
                       [(key, *values) for key, values in sorted(instructors.items())])
        db.executemany("INSERT INTO courses VALUES (?, ?, ?)",
                       [(key, *values) for key, values in sorted(courses.items())])
        db.executemany("INSERT INTO enrolments VALUES (?, ?, ?)",
                       [(row[0], row[2], row[6]) for row in rows])
        db.commit()
    except Exception:
        db.rollback()
        raise


def reconstructed(db):
    return db.execute("""
        SELECT l.learner_id, l.learner_name, c.course_id, c.course_title,
               i.instructor_id, i.instructor_name, e.joined_on
        FROM enrolments AS e
        JOIN learners AS l ON l.learner_id = e.learner_id
        JOIN courses AS c ON c.course_id = e.course_id
        JOIN instructors AS i ON i.instructor_id = c.instructor_id
        ORDER BY l.learner_id, c.course_id
    """).fetchall()


def main():
    show_anomalies()
    db = connect()
    create_flat(db)
    migrate(db)
    assert reconstructed(db) == sorted(SAMPLE, key=lambda row: (row[0], row[2]))
    for table in ("learners", "instructors", "courses", "enrolments"):
        count = db.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"{table.title()}: {count}")
    print("Reconstructed enrolment rows match the original:", len(reconstructed(db)))
    db.close()


if __name__ == "__main__":
    main()
