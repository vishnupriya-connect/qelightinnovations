"""Check distinct identity, memory sharing, and mutation behavior."""

from array_references_views_copies import (
    alias_demo, controlled_change, explicit_view_demo, numeric_copy_demo,
    object_copy_demo, slice_view_demo,
)


def run_checks():
    assert alias_demo() == (True, True, [11, 20, 30, 40], [11, 20, 30, 40])
    assert slice_view_demo() == (False, True, [10, 25, 30, 40], [25, 30])
    assert explicit_view_demo() == (False, True, [10, 20, 30, 45], [10, 20, 30, 45])
    assert numeric_copy_demo() == (False, False, [10, 20, 30, 40], [25, 30])
    assert controlled_change(False) == ([10, 20, 35, 40], [35, 40], True)
    assert controlled_change(True) == ([10, 20, 30, 40], [35, 40], False)
    assert object_copy_demo() == (
        False, True, [10, 20, 30], [10, 20, 30], [10, 20, 30, 40], False,
    )
    print("All references, views, and copies checks passed.")


if __name__ == "__main__":
    run_checks()
