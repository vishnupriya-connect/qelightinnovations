"""Check right alignment, resulting values, and shape errors."""

import numpy as np

from broadcasting import make_examples


def main():
    minutes, task_bonus, learner_bonus, weekly, correction = make_examples()
    scalar = minutes + 5
    tasks = minutes + task_bonus
    learners = minutes + learner_bonus
    matrix = weekly + correction
    assert minutes.shape == (2, 3)
    assert task_bonus.shape == (3,)
    assert learner_bonus.shape == (2, 1)
    assert scalar.shape == tasks.shape == learners.shape == (2, 3)
    assert scalar.tolist() == [[15, 25, 35], [45, 55, 65]]
    assert tasks.tolist() == [[11, 22, 33], [41, 52, 63]]
    assert learners.tolist() == [[110, 120, 130], [240, 250, 260]]
    assert minutes[1, 2] + task_bonus[2] == tasks[1, 2] == 63
    assert minutes[1, 2] + learner_bonus[1, 0] == learners[1, 2] == 260
    assert weekly.shape == (2, 3, 4)
    assert correction.shape == (3, 4)
    assert matrix.shape == (2, 3, 4)
    assert weekly[1, 2, 3] == 23
    assert correction[2, 3] == 12
    assert matrix[1, 2, 3] == 35
    assert np.array_equal(matrix[0] - weekly[0], correction)
    assert np.array_equal(matrix[1] - weekly[1], correction)
    changed = task_bonus.copy()
    changed[2] = 9
    assert (minutes + changed)[:, 2].tolist() == [39, 69]
    assert (minutes + task_bonus)[:, 2].tolist() == [33, 63]
    assert task_bonus[2] == 3
    for bad in (
        lambda: minutes + np.array([100, 200]),
        lambda: weekly + np.ones((2, 3)),
    ):
        try:
            bad()
        except ValueError:
            pass
        else:
            raise AssertionError("An incompatible shape was accepted")
    print("All checks passed.")


if __name__ == "__main__":
    main()
