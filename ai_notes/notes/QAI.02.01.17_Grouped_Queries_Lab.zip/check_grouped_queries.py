"""Verify separate groups, WHERE/HAVING, boundaries, and empty group results."""

from grouped_queries import (
    COURSES,
    group_after_row_filter,
    group_filter,
    instructor_summaries,
    lesson_count_variation,
    make_connection,
    project_report,
)


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        assert before == COURSES
        assert instructor_summaries(db) == [
            (7, 2, 175, 87.5, 2),
            (8, 2, 115, 57.5, 0),
        ]
        assert db.execute(
            "SELECT instructor_id, COUNT(practice_minutes), SUM(practice_minutes) "
            "FROM course_catalogue GROUP BY instructor_id ORDER BY instructor_id"
        ).fetchall() == [(7, 2, 50), (8, 0, None)]
        print("One aggregate row per instructor and missing values: correct")

        assert group_after_row_filter(db, 65) == [(7, 2, 175), (8, 1, 65)]
        assert group_after_row_filter(db, 80) == [(7, 2, 175)]
        assert group_after_row_filter(db, 200) == []
        assert group_filter(db, 150) == [(7, 2, 175)]
        assert group_filter(db, 115) == [(7, 2, 175), (8, 2, 115)]
        print("WHERE removes rows; HAVING removes groups: correct")

        assert project_report(db) == [(7, 2, 175, 87.5, 2)]
        assert project_report(db, 50, 2) == [
            (7, 2, 175, 87.5, 2), (8, 2, 115, 57.5, 0)
        ]
        assert project_report(db, 60, 3) == []
        print("Combined filter and changed thresholds: correct")

        assert lesson_count_variation(db) == [(4, 2, 175, 87.5)]
        assert lesson_count_variation(db, 55) == [
            (3, 2, 115, 57.5), (4, 2, 175, 87.5)
        ]
        assert db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall() == before
        print("Independent grouping variation and unchanged data: correct")


if __name__ == "__main__":
    main()
