# Array slicing lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python array_slicing.py
python check_array_slicing.py
```

Use `python3` if needed. Predict the selected indexes, values, and shapes before running. Complete the three-day slicing mini-project independently, then compare with `python mini_project_reference.py`. The examples were checked with NumPy 2.3.5. Slices can share source data; this lab reads them and makes changed-input variations from independent arrays.
