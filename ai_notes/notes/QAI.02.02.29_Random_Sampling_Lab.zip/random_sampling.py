"""Draw from populations and distributions with a local generator."""

import numpy as np


def make_sample(seed=2026):
    population = np.array([10, 20, 30, 40])
    rng = np.random.default_rng(seed)
    without = rng.choice(population, size=3, replace=False)
    with_replacement = rng.choice(population, size=6, replace=True)
    dice = rng.integers(1, 7, size=5)
    fractions = rng.random(5)
    normal_values = rng.normal(loc=50, scale=10, size=5)
    permuted = rng.permutation(population)
    editable = population.copy()
    returned = rng.shuffle(editable)
    return (population, without, with_replacement, dice, fractions,
            normal_values, permuted, editable, returned)


def main():
    population, without, with_replacement, dice, fractions, normal_values, permuted, editable, returned = make_sample()
    print("Population:", population.tolist())
    print("Without replacement:", without.tolist(),
          "distinct:", np.unique(without).size == without.size)
    print("With replacement:", with_replacement.tolist(),
          "repeated:", np.unique(with_replacement).size < with_replacement.size)
    print("Dice:", dice.tolist(),
          "in [1, 7):", bool(np.all((dice >= 1) & (dice < 7))))
    print("Uniform floats:", np.round(fractions, 3).tolist(),
          "in [0, 1):", bool(np.all((fractions >= 0) & (fractions < 1))))
    print("Normal floats:", np.round(normal_values, 3).tolist(),
          "shape:", normal_values.shape)
    print("Permutation:", permuted.tolist(), "original:", population.tolist())
    print("Shuffled copy:", editable.tolist(), "return:", returned)
    print("Same-seed replay:",
          all(np.array_equal(a, b) for a, b in zip(make_sample()[:-1],
                                                    make_sample()[:-1])))
    rng = np.random.default_rng(1)
    for size, replace in ((4, False), (5, True)):
        sample = rng.choice(population, size=size, replace=replace)
        print("Variation:", size, replace, sample.shape)
    try:
        rng.choice(population, size=5, replace=False)
    except ValueError:
        print("Five without replacement: ValueError")


if __name__ == "__main__":
    main()
