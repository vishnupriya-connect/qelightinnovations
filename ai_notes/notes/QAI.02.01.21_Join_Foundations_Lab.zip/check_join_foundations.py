"""Verify join keys, unmatched rows, ambiguous names, and projects."""

import sqlite3

from join_foundations import (
    COURSES, INSTRUCTORS, independent_variation, joined_rows, make_connection,
    project_rows,
)


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall() == INSTRUCTORS

        assert joined_rows(db) == [
            (101, "AI Foundations", "Asha"),
            (102, "Git Basics", "Ben"),
            (103, "Data Basics", "Asha"),
            (104, "Python Basics", "Ben"),
        ]
        assert db.execute(
            "SELECT c.course_id FROM course_catalogue AS c "
            "JOIN instructors AS i ON c.course_id = i.instructor_id"
        ).fetchall() == []
        assert db.execute(
            "SELECT COUNT(*) FROM course_catalogue AS c JOIN instructors AS i"
        ).fetchone() == (15,)
        print("Correct and wrong keys, and missing ON: correct")

        assert db.execute(
            "SELECT course_id, instructor_id FROM course_catalogue WHERE course_id=105"
        ).fetchone() == (105, 42)
        assert db.execute(
            "SELECT instructor_id, instructor_name FROM instructors WHERE instructor_id=9"
        ).fetchone() == (9, "Cora")
        assert (105, "SQL Basics", "Asha") not in joined_rows(db)
        print("Unmatched course and instructor identified: correct")

        try:
            db.execute(
                "SELECT instructor_id FROM course_catalogue AS c "
                "JOIN instructors AS i ON c.instructor_id = i.instructor_id"
            ).fetchall()
        except sqlite3.OperationalError as exc:
            assert "ambiguous" in str(exc).lower()
        else:
            raise AssertionError("Unqualified shared column should be ambiguous")
        cursor = db.execute(
            "SELECT c.instructor_id, i.instructor_id FROM course_catalogue AS c "
            "JOIN instructors AS i ON c.instructor_id = i.instructor_id "
            "ORDER BY c.course_id"
        )
        assert [column[0] for column in cursor.description] == [
            "instructor_id", "instructor_id"
        ]
        assert cursor.fetchall() == [(7, 7), (8, 8), (7, 7), (8, 8)]
        renamed = db.execute(
            "SELECT c.instructor_id AS course_instructor_id, "
            "i.instructor_id AS matched_instructor_id "
            "FROM course_catalogue AS c JOIN instructors AS i "
            "ON c.instructor_id = i.instructor_id"
        )
        assert [column[0] for column in renamed.description] == [
            "course_instructor_id", "matched_instructor_id"
        ]
        print("Ambiguous input name and duplicate output names: correct")

        assert project_rows(db) == [
            (101, "AI Foundations", "Asha", 95),
            (103, "Data Basics", "Asha", 80),
            (104, "Python Basics", "Ben", 65),
        ]
        assert project_rows(db, 70) == [
            (101, "AI Foundations", "Asha", 95),
            (103, "Data Basics", "Asha", 80),
        ]
        assert independent_variation(db) == [
            (102, "Git Basics", "Ben"),
            (104, "Python Basics", "Ben"),
        ]
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall() == INSTRUCTORS
        print("Project, boundary change, variation, unchanged tables: correct")


if __name__ == "__main__":
    main()
