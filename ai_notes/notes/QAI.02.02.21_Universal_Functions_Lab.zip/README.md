# Universal functions lab

Run with Python 3:

```bash
python -m pip install -r requirements.txt
python universal_functions.py
python check_universal_functions.py
python mini_project_reference.py
```

Trace the first signed difference through absolute value and square, then compare floor, ceiling, and round for a negative fractional input. Try the controlled variation in the notes.
