# SQL safety lab

Requires Python 3 and the standard-library `sqlite3` module. Run from this folder:

```sh
python sql_safety.py
python check_sql_safety.py
```

Use `python3` if needed. The program creates a disposable SQLite file with four invented course titles. Its intentionally unsafe query is run only against that local data to expose an altered `WHERE` result; it does not execute a destructive command. The read-only SQLite connection, small application role check, bound values, sort-key allowlist, and audit entries are each demonstrated. SQLite has no built-in database users and roles like a client-server database; the application role check here is illustrative and is not a complete authorization system. The temporary file is removed at the end.
