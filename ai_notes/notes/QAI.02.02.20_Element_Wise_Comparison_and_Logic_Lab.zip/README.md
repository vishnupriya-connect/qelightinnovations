# Element-wise comparison and logic lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python element_wise_comparison_and_logic.py
python check_element_wise_comparison_and_logic.py
python mini_project_reference.py
```

Predict all conditions at coordinate `[0, 2]` before running. Then try the controlled variation in the companion notes.
