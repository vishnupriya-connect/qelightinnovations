"""Check detection, aggregation, replacement, and missing-row safeguards."""

import warnings

import numpy as np

from missing_and_special_values import available_summary, make_examples


def main():
    study, special = make_examples()
    assert study.shape == (2, 3)
    assert np.isnan(study).tolist() == [[False, True, False],
                                       [False, False, True]]
    assert np.isnan(special).tolist() == [True, False, False, False]
    assert np.isinf(special).tolist() == [False, True, True, False]
    assert np.isfinite(special).tolist() == [False, False, False, True]
    assert not (np.nan == np.nan)
    assert np.isnan(np.sum(study)) and np.isnan(np.mean(study))
    totals, means = available_summary(study)
    assert totals.tolist() == [30.0, 20.0]
    assert means.tolist() == [15.0, 10.0]
    missing_mask = np.isnan(study)
    display = np.nan_to_num(study, nan=0.0)
    assert display.tolist() == [[10.0, 0.0, 20.0], [5.0, 15.0, 0.0]]
    assert missing_mask[0, 1] and np.isnan(study[0, 1])
    assert np.mean(display, axis=1).tolist() != means.tolist()
    codes = np.nan_to_num(special, nan=0.0, posinf=100.0, neginf=-100.0)
    assert codes.tolist() == [0.0, 100.0, -100.0, 5.0]
    assert np.isnan(special[0]) and np.isposinf(special[1])
    empty = np.array([np.nan, np.nan])
    assert np.nansum(empty) == 0.0
    assert np.all(np.isnan(empty))
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always", RuntimeWarning)
        result = np.nanmean(empty)
    assert np.isnan(result) and any(issubclass(w.category, RuntimeWarning) for w in caught)
    for invalid in (
        np.array([[np.nan, np.nan], [2.0, 3.0]]),
        np.array([[1.0, np.inf], [2.0, 3.0]]),
    ):
        try:
            available_summary(invalid)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid row should not have a reported mean")
    changed = study.copy()
    changed[0, 1] = 30.0
    new_totals, new_means = available_summary(changed)
    assert new_totals[0] == 60 and new_means[0] == 20
    assert np.isnan(study[0, 1])
    print("All checks passed.")


if __name__ == "__main__":
    main()
