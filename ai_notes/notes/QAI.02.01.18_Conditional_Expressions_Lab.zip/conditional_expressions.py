"""Derive display categories and null fallbacks without changing stored rows."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4, "intro", 20),
    (102, "Git Basics", 8, 50, 3, None, None),
    (103, "Data Basics", 7, 80, 4, "tables", 30),
    (104, "Python Basics", 8, 65, 3, None, None),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT,
            practice_minutes INTEGER
        )"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?, ?)", COURSES)
    db.commit()
    return db


def duration_categories(db, extended=80, standard=60):
    """Test the higher boundary first so it cannot be swallowed by the lower one."""
    return db.execute(
        """SELECT course_id,
                  CASE WHEN duration_minutes >= ? THEN 'Extended'
                       WHEN duration_minutes >= ? THEN 'Standard'
                       ELSE 'Short'
                  END AS duration_band
           FROM course_catalogue ORDER BY course_id""",
        (extended, standard),
    ).fetchall()


def note_display(db):
    return db.execute(
        """SELECT course_id, COALESCE(topic_note, 'Not recorded') AS displayed_note
           FROM course_catalogue ORDER BY course_id"""
    ).fetchall()


def project_view(db):
    """Reference mini-project: labelled Basics courses and readable notes."""
    return db.execute(
        """SELECT course_id, title,
                  CASE WHEN duration_minutes >= 80 THEN 'Extended'
                       WHEN duration_minutes >= 60 THEN 'Standard'
                       ELSE 'Short' END AS duration_band,
                  COALESCE(topic_note, 'Needs note') AS displayed_note
           FROM course_catalogue
           WHERE title LIKE '%Basics'
           ORDER BY course_id"""
    ).fetchall()


def independent_variation(db):
    """Reference variation: status of recorded practice estimates."""
    return db.execute(
        """SELECT course_id,
                  CASE WHEN practice_minutes IS NULL THEN 'Unestimated'
                       WHEN practice_minutes >= 25 THEN 'More practice'
                       ELSE 'Less practice' END AS practice_category,
                  COALESCE(topic_note, 'Needs note') AS displayed_note
           FROM course_catalogue ORDER BY course_id"""
    ).fetchall()


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Duration categories:", duration_categories(db))
        print("Displayed notes:", note_display(db))
        print("Basics project:", project_view(db))
        print("Independent variation:", independent_variation(db))
        after = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Stored rows unchanged:", before == after)


if __name__ == "__main__":
    main()
