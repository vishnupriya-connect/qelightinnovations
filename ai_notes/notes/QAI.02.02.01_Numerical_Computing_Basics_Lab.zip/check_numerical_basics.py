"""Check imports, namespace expectation, examples, and boundary case."""

import math

import numpy
import numpy as np

from numerical_basics import summary


assert numpy is np
assert int(numpy.sum([20, 30, 10])) == 60
assert float(np.mean([20, 30, 10])) == 20.0
assert summary([20, 30, 10]) == (60, 20.0)
assert summary([20, 30, 40])[0] == 90
assert math.isclose(summary([20, 30, 40])[1], 30.0)
print('Both imports, total, mean, and controlled change: correct')

separate_scope = {}
try:
    exec('import numpy\nanswer = np.sum([1, 2])', separate_scope)
except NameError:
    pass
else:
    raise AssertionError('Importing only numpy should not create an np name')
assert separate_scope['numpy'] is numpy
print('Full-name import does not create the alias in a separate namespace: correct')

try:
    summary([])
except ValueError:
    pass
else:
    raise AssertionError('Empty input should be rejected before calculating a mean')
print('Empty data produces a clear error: correct')
