"""Read coordinates and sub-arrays from study tables and a weekly stack."""

import numpy as np


def study_data():
    work = np.array([[12, 8, 5], [10, 15, 5]], dtype=np.int32)
    weeks = np.array([
        [[12, 8, 5], [10, 15, 5]],
        [[14, 6, 5], [12, 10, 8]],
    ], dtype=np.int32)
    return work, weeks


def read_scalar(array, coordinate):
    """Require a complete tuple coordinate for one numerical item."""
    if not isinstance(coordinate, tuple) or len(coordinate) != array.ndim:
        raise ValueError(f"Expected {array.ndim} positions for one reading")
    return int(array[coordinate])


def corrected_week(weeks, coordinate, new_value):
    if not isinstance(coordinate, tuple) or len(coordinate) != weeks.ndim:
        raise ValueError(f"Expected {weeks.ndim} positions for one update")
    result = weeks.copy()
    result[coordinate] = new_value
    return result


def main():
    work, weeks = study_data()
    print("2D shape:", work.shape)
    print("[1, 1] and tuple (1, 1):", int(work[1, 1]), read_scalar(work, (1, 1)))
    print("[0, 1] versus [1, 0]:", int(work[0, 1]), int(work[1, 0]))
    print("Learner row:", work[1].tolist(), work[1].shape)
    print("Exercise column:", work[:, 1].tolist(), work[:, 1].shape)
    print("Negative coordinate:", int(work[-1, -2]))

    print("3D shape:", weeks.shape)
    print("Week 1/learner 0/exercises:", read_scalar(weeks, (1, 0, 1)))
    print("Week 1 table:", weeks[1].tolist(), weeks[1].shape)
    print("Week 1/learner 0 row:", weeks[1, 0].tolist(), weeks[1, 0].shape)
    print("Week 1 exercises column:", weeks[1, :, 1].tolist(), weeks[1, :, 1].shape)

    corrected = corrected_week(weeks, (1, 0, 0), 16)
    print("Corrected row:", corrected[1, 0].tolist())
    print("Corrected reading column:", corrected[1, :, 0].tolist())
    print("Original reading:", int(weeks[1, 0, 0]))

    print("Wrong-order coordinate:", read_scalar(weeks, (0, 1, 1)))
    print("Repaired coordinate:", read_scalar(weeks, (1, 0, 1)))
    for coordinate in ((1, 0), (2, 0, 1)):
        try:
            read_scalar(weeks, coordinate)
        except (ValueError, IndexError) as error:
            print("Invalid single-reading request:", coordinate, type(error).__name__)


if __name__ == "__main__":
    main()
