# Course catalogue normalisation lab

Requires Python 3 and its standard library. Run inside this folder:

```sh
python normalisation.py
python check_normalisation.py
```

Use `python3` if necessary. The program shows two anomalies in a flat enrolment sheet, then validates dependencies, creates four related tables, and verifies a joined view gives back the original information. The checker demonstrates a single instructor edit, deleting the last enrolment without losing the course, adding a course before enrolment, a rejected foreign key, and a rejected conflicting import. Each run builds a new in-memory database.

To practice, copy the files, add instructor 9 and course 103 with no enrolments, then add a learner and enrol them. Print the joined rows and explain why course 103 exists before enrolment. A complete worked version is in the accompanying notes.
