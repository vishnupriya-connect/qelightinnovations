"""Complete reference solution for a reproducible trial log."""

from copy import deepcopy

import numpy as np


def main():
    first = np.random.default_rng(31)
    second = np.random.default_rng(31)
    draw_a = first.random(3)
    draw_b = second.random(3)
    first.random()
    next_b = second.random()
    reference = np.random.default_rng(31)
    reference.random(3)
    expected_next = reference.random()
    saved = deepcopy(second.bit_generator.state)
    observed = second.random(2)
    second.bit_generator.state = saved
    replayed = second.random(2)
    print("first shapes", draw_a.shape, draw_b.shape)
    print("first match", np.array_equal(draw_a, draw_b))
    print("second position matches reference", next_b == expected_next)
    print("saved state replays", np.array_equal(observed, replayed))
    print("separate objects", first is not second)


if __name__ == "__main__":
    main()
