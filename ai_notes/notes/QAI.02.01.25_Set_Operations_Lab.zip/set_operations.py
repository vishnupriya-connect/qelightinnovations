"""Compare UNION, UNION ALL, INTERSECT, and EXCEPT on two candidate lists."""

import sqlite3


COURSES = [
    (101, "AI Foundations"), (102, "Git Basics"),
    (103, "Data Basics"), (104, "Python Basics"),
    (105, "SQL Basics"),
]
CORE = [(101,), (103,), (103,), (105,)]
PRACTICE = [(102,), (103,), (104,), (104,), (105,)]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        "CREATE TABLE course_catalogue (course_id INTEGER PRIMARY KEY, title TEXT NOT NULL)"
    )
    db.execute("CREATE TABLE core_candidates (course_id INTEGER NOT NULL)")
    db.execute("CREATE TABLE practice_candidates (course_id INTEGER NOT NULL)")
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?)", COURSES)
    db.executemany("INSERT INTO core_candidates VALUES (?)", CORE)
    db.executemany("INSERT INTO practice_candidates VALUES (?)", PRACTICE)
    db.commit()
    return db


def one_column(db, operation, reverse=False):
    """Use a fixed allowlist for SQL keywords; bind only data values elsewhere."""
    if operation not in ("UNION", "UNION ALL", "INTERSECT", "EXCEPT"):
        raise ValueError("unsupported set operation")
    first, second = ("practice_candidates", "core_candidates") if reverse else (
        "core_candidates", "practice_candidates"
    )
    return [row[0] for row in db.execute(
        "SELECT course_id FROM " + first + " " + operation +
        " SELECT course_id FROM " + second + " ORDER BY course_id"
    )]


def labeled_union(db):
    """The complete output row, including source, controls duplicate removal."""
    return db.execute(
        """SELECT course_id, 'core' AS source FROM core_candidates
           UNION
           SELECT course_id, 'practice' AS source FROM practice_candidates
           ORDER BY course_id, source"""
    ).fetchall()


def project_shared(db):
    """Reference project: unique IDs recommended by both lists with titles."""
    return db.execute(
        """WITH shared_ids AS (
             SELECT course_id FROM core_candidates
             INTERSECT
             SELECT course_id FROM practice_candidates
           )
           SELECT c.course_id, c.title
           FROM shared_ids AS s
           JOIN course_catalogue AS c ON c.course_id = s.course_id
           ORDER BY c.course_id"""
    ).fetchall()


def independent_variation(db):
    """Reference variation: only in practice list, with titles."""
    return db.execute(
        """WITH practice_only AS (
             SELECT course_id FROM practice_candidates
             EXCEPT
             SELECT course_id FROM core_candidates
           )
           SELECT c.course_id, c.title
           FROM practice_only AS p
           JOIN course_catalogue AS c ON c.course_id = p.course_id
           ORDER BY c.course_id"""
    ).fetchall()


def main():
    with make_connection() as db:
        before = [db.execute("SELECT * FROM " + table + " ORDER BY 1").fetchall()
                  for table in ("course_catalogue", "core_candidates", "practice_candidates")]
        print("UNION:", one_column(db, "UNION"))
        print("UNION ALL:", one_column(db, "UNION ALL"))
        print("INTERSECT:", one_column(db, "INTERSECT"))
        print("Core EXCEPT practice:", one_column(db, "EXCEPT"))
        print("Practice EXCEPT core:", one_column(db, "EXCEPT", reverse=True))
        print("UNION with source labels:", labeled_union(db))
        print("Project shared:", project_shared(db))
        print("Independent variation:", independent_variation(db))
        after = [db.execute("SELECT * FROM " + table + " ORDER BY 1").fetchall()
                 for table in ("course_catalogue", "core_candidates", "practice_candidates")]
        print("Stored tables unchanged:", before == after)


if __name__ == "__main__":
    main()
