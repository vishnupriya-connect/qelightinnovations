"""Complete reference solution for partial study records."""

import numpy as np


def main():
    records = np.array([[12.0, np.nan, 18.0],
                        [np.nan, 20.0, 22.0]])
    missing = np.isnan(records)
    display = np.nan_to_num(records, nan=0.0)
    print("missing", missing.tolist())
    print("missing counts", np.sum(missing, axis=1).tolist())
    print("available sums", np.nansum(records, axis=1).tolist())
    print("available means", np.nanmean(records, axis=1).tolist())
    print("display", display.tolist())
    print("original missing", bool(np.isnan(records[0, 1])))


if __name__ == "__main__":
    main()
