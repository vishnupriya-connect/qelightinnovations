# DataFrame fundamentals lab

Run from this folder:

```bash
python -m pip install -r requirements.txt
python dataframe_fundamentals.py
python check_dataframe_fundamentals.py
python mini_project_reference.py
```

Predict the table's row labels, column labels, shape, and value at `"L2"` / `"score"` before running. Then add a third learner to the dictionary, list-of-dictionaries, and list-of-lists examples. Restore the original data before running the checker.
