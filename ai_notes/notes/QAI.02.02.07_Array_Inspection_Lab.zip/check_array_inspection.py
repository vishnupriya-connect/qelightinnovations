"""Check array properties and the layout validator's failure cases."""

import numpy as np

from array_inspection import inspect_array, require_layout, study_grid


def run_checks():
    original = study_grid()
    assert original.tolist() == [[20, 10], [30, 15], [40, 20]]
    assert inspect_array(original) == {
        "shape": (3, 2), "ndim": 2, "size": 6,
        "dtype": "int16", "itemsize": 2, "nbytes": 12,
    }
    assert require_layout(original, (3, 2), np.int16) == inspect_array(original)
    assert len(original.shape) == original.ndim
    assert original.size * original.itemsize == original.nbytes

    wider = original.astype(np.int32)
    assert wider.tolist() == original.tolist()
    assert inspect_array(wider) == {
        "shape": (3, 2), "ndim": 2, "size": 6,
        "dtype": "int32", "itemsize": 4, "nbytes": 24,
    }
    swapped = np.array([[20, 10, 30], [15, 40, 20]], dtype=np.int16)
    assert (swapped.size, swapped.nbytes) == (6, 12)
    assert swapped.shape == (2, 3)
    for array, message in [(swapped, "Expected shape"), (wider, "Expected dtype")]:
        try:
            require_layout(array, (3, 2), np.int16)
        except ValueError as error:
            assert message in str(error)
        else:
            raise AssertionError(f"Expected rejection: {message}")

    assert inspect_array(np.array(7, dtype=np.int16)) == {
        "shape": (), "ndim": 0, "size": 1,
        "dtype": "int16", "itemsize": 2, "nbytes": 2,
    }
    assert inspect_array(np.empty((0, 2), dtype=np.int16)) == {
        "shape": (0, 2), "ndim": 2, "size": 0,
        "dtype": "int16", "itemsize": 2, "nbytes": 0,
    }
    try:
        inspect_array([[1, 2]])
    except TypeError:
        pass
    else:
        raise AssertionError("Expected a list to be rejected")
    print("All array-inspection checks passed.")


if __name__ == "__main__":
    run_checks()
