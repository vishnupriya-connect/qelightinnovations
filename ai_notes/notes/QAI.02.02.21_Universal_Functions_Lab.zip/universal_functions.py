"""Apply unary and binary NumPy functions to small arrays."""

import numpy as np


def make_examples():
    differences = np.array([[-3, 0, 4], [5, -1, 2]], dtype=np.float64)
    counts = np.array([0, 1, 4, 9], dtype=np.float64)
    exponents = np.array([0.0, 1.0, 2.0])
    angles = np.array([0.0, np.pi / 2, np.pi])
    measurements = np.array([-1.6, -1.2, 1.2, 1.6])
    return differences, counts, exponents, angles, measurements


def real_roots(values):
    if np.any(values < 0):
        raise ValueError("Real square roots require nonnegative input")
    return np.sqrt(values)


def real_logs(values):
    if np.any(values <= 0):
        raise ValueError("Real logarithms require positive input")
    return np.log(values)


def main():
    differences, counts, exponents, angles, measurements = make_examples()
    print("Absolute:", np.abs(differences).tolist())
    print("Square:", np.square(differences).tolist())
    print("Roots:", real_roots(counts).tolist())
    growth = np.exp(exponents)
    print("Exponential:", np.round(growth, 3).tolist())
    print("Logarithm of exponential:", np.round(real_logs(growth), 6).tolist())
    print("Sine:", np.round(np.sin(angles), 6).tolist())
    print("Cosine:", np.round(np.cos(angles), 6).tolist())
    print("Round:", np.round(measurements).tolist())
    print("Floor:", np.floor(measurements).tolist())
    print("Ceil:", np.ceil(measurements).tolist())
    print("Binary add:", np.add([1, 2, 3], [10, 20, 30]).tolist())
    changed = differences.copy()
    changed[0, 0] = -6
    print("Variation:", np.abs(changed)[0, 0],
          np.square(changed)[0, 0], "original:", differences[0, 0])


if __name__ == "__main__":
    main()
