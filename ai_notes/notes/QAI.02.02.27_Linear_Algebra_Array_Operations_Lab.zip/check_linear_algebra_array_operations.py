"""Check product meanings, shape rules, solving, rank, and eigenpairs."""

import numpy as np

from linear_algebra_array_operations import make_examples


def main():
    A, B, u, w, b, singular = make_examples()
    assert A.shape == B.shape == (2, 2)
    assert (A * B).tolist() == [[2.0, 2.0], [3.0, 8.0]]
    assert (A @ B).tolist() == [[5.0, 8.0], [7.0, 10.0]]
    assert np.array_equal(A @ B, np.matmul(A, B))
    assert np.array_equal(A @ B, np.dot(A, B))
    assert (A @ u).tolist() == [5.0, 4.0]
    assert np.dot(u, w) == np.inner(u, w) == 10.0
    assert np.outer(u, w).tolist() == [[6.0, 8.0], [3.0, 4.0]]
    x = np.linalg.solve(A, b)
    assert np.allclose(x, [2.0, 1.0])
    assert np.allclose(A @ x, b)
    assert np.isclose(np.linalg.det(A), 3.0)
    inverse = np.linalg.inv(A)
    assert np.allclose(A @ inverse, np.eye(2))
    assert np.allclose(inverse @ A, np.eye(2))
    assert np.linalg.matrix_rank(A) == 2
    assert np.isclose(np.linalg.det(singular), 0)
    assert np.linalg.matrix_rank(singular) == 1
    for action in (
        lambda: np.linalg.inv(singular),
        lambda: np.linalg.solve(singular, np.array([1.0, 2.0])),
    ):
        try:
            action()
        except np.linalg.LinAlgError:
            pass
        else:
            raise AssertionError("Singular matrix was accepted")
    try:
        np.ones((2, 3)) @ np.ones((2, 3))
    except ValueError:
        pass
    else:
        raise AssertionError("Mismatched inner dimensions were accepted")
    values, vectors = np.linalg.eig(A)
    assert np.allclose(np.sort(values), [1.0, 3.0])
    assert all(np.allclose(A @ vectors[:, i], values[i] * vectors[:, i])
               for i in range(len(values)))
    changed_b = b.copy()
    changed_b[:] = [6.0, 6.0]
    assert np.allclose(np.linalg.solve(A, changed_b), [2.0, 2.0])
    assert b.tolist() == [5.0, 4.0]
    print("All checks passed.")


if __name__ == "__main__":
    main()
