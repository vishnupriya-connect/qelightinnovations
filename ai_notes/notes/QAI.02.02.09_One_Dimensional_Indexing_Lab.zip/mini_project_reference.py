"""Reference for the five-session indexed-update task."""

import numpy as np

from one_dimensional_indexing import read_at, updated_copy


def main():
    source = np.array([25, 30, 20, 35, 15], dtype=np.int32)
    for name, positive, negative in [
        ("First", 0, -5), ("Last", 4, -1), ("Second-last", 3, -2),
    ]:
        print(f"{name}: [{positive}]={read_at(source, positive)}, "
              f"[{negative}]={read_at(source, negative)}")
    print("Original total:", int(source.sum()))
    revised = updated_copy(source, 0, 28)
    revised[-1] = 18
    print("Source:", source.tolist(), "total:", int(source.sum()))
    print("Copy:", revised.tolist(), "total:", int(revised.sum()))
    try:
        read_at(source, 5)
    except IndexError as error:
        print("Out of bounds:", type(error).__name__, "; valid: 0..4 or -5..-1")
    print("Repaired last position:", read_at(source, 4))


if __name__ == "__main__":
    main()
