# Set operations lab

Run from this unzipped folder with Python 3:

```sh
python set_operations.py
python check_set_operations.py
```

Use `python3` if needed. Python's standard-library `sqlite3` builds private in-memory candidate and course tables. Predict both inputs, all five set-operation outputs, and the repeated IDs under UNION ALL before running. Reverse EXCEPT to diagnose direction, then add a source label and see that duplicate removal compares entire rows. Attempt the shared-course project and practice-only variation before inspecting their reference functions. The checker verifies the supplied examples; compare your own SQL separately.
