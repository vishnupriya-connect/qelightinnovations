"""Calculate aggregate values from a small SQLite course catalogue."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4, "intro", 20),
    (102, "Git Basics", 8, 50, 3, None, None),
    (103, "Data Basics", 7, 80, 4, "tables", 30),
    (104, "Python Basics", 8, 65, 3, None, None),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT,
            practice_minutes INTEGER
        );"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?, ?)", COURSES)
    db.commit()
    return db


def catalogue_summary(db):
    return db.execute(
        """SELECT COUNT(*), COUNT(topic_note), COUNT(DISTINCT instructor_id),
                  SUM(duration_minutes), AVG(duration_minutes),
                  MIN(duration_minutes), MAX(duration_minutes)
           FROM course_catalogue"""
    ).fetchone()


def practice_summary(db):
    return db.execute(
        """SELECT COUNT(*), COUNT(practice_minutes),
                  SUM(practice_minutes), AVG(practice_minutes),
                  MIN(practice_minutes), MAX(practice_minutes)
           FROM course_catalogue"""
    ).fetchone()


def range_report(db, minimum=50, maximum=80):
    """Reference mini-project: one summary row for the inclusive duration range."""
    return db.execute(
        """SELECT COUNT(*) AS course_count,
                  SUM(lesson_count) AS lesson_total,
                  AVG(duration_minutes) AS average_duration,
                  COUNT(DISTINCT instructor_id) AS instructor_count,
                  COUNT(practice_minutes) AS recorded_practice_count,
                  SUM(practice_minutes) AS recorded_practice_total
           FROM course_catalogue
           WHERE duration_minutes BETWEEN ? AND ?""",
        (minimum, maximum),
    ).fetchone()


def instructor_report(db, instructor_id):
    """Reference independent variation: summary of one instructor's courses."""
    return db.execute(
        """SELECT COUNT(*), SUM(duration_minutes), AVG(duration_minutes),
                  MIN(duration_minutes), MAX(duration_minutes),
                  COUNT(practice_minutes), SUM(practice_minutes)
           FROM course_catalogue
           WHERE instructor_id = ?""",
        (instructor_id,),
    ).fetchone()


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Catalogue:", catalogue_summary(db))
        print("Practice:", practice_summary(db))
        print("Range project:", range_report(db))
        print("Instructor 7:", instructor_report(db, 7))
        print("Instructor 8:", instructor_report(db, 8))
        print("No matching rows:", db.execute(
            "SELECT COUNT(*), SUM(duration_minutes), AVG(duration_minutes), "
            "MIN(duration_minutes), MAX(duration_minutes) "
            "FROM course_catalogue WHERE duration_minutes > ?", (200,)
        ).fetchone())
        after = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Stored rows unchanged:", before == after)


if __name__ == "__main__":
    main()
