"""In-memory course enrolment database demonstrating keys and valid links."""

import argparse
import sqlite3


def open_database():
    connection = sqlite3.connect(":memory:")
    # Set this on EACH SQLite connection before beginning a transaction.
    connection.execute("PRAGMA foreign_keys = ON")
    status = connection.execute("PRAGMA foreign_keys").fetchone()
    if status != (1,):
        connection.close()
        raise RuntimeError("SQLite foreign-key enforcement is unavailable")
    return connection


def create_tables(connection):
    connection.execute(
        "CREATE TABLE learners ("
        "learner_id INTEGER PRIMARY KEY, "
        "email TEXT NOT NULL UNIQUE, "
        "full_name TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE courses ("
        "course_id INTEGER PRIMARY KEY, "
        "course_code TEXT NOT NULL UNIQUE, "
        "title TEXT NOT NULL)"
    )
    connection.execute(
        "CREATE TABLE enrolments ("
        "learner_id INTEGER NOT NULL, "
        "course_id INTEGER NOT NULL, "
        "PRIMARY KEY (learner_id, course_id), "
        "FOREIGN KEY (learner_id) REFERENCES learners(learner_id), "
        "FOREIGN KEY (course_id) REFERENCES courses(course_id))"
    )


def seed(connection):
    connection.executemany(
        "INSERT INTO learners (learner_id, email, full_name) VALUES (?, ?, ?)",
        [
            (1, "anu@example.invalid", "Anu"),
            (2, "ravi@example.invalid", "Ravi"),
        ],
    )
    connection.executemany(
        "INSERT INTO courses (course_id, course_code, title) VALUES (?, ?, ?)",
        [
            (101, "AI-FOUND", "AI Foundations"),
            (102, "GIT-BASICS", "Git Basics"),
        ],
    )
    connection.executemany(
        "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
        [(1, 101), (2, 101), (1, 102)],
    )


def build_database():
    connection = open_database()
    try:
        create_tables(connection)
        seed(connection)
    except Exception:
        connection.close()
        raise
    return connection


def summary(connection):
    enabled = connection.execute("PRAGMA foreign_keys").fetchone()[0]
    print("Foreign-key enforcement:", "on" if enabled == 1 else "off")
    for label, table in (
        ("Learners", "learners"),
        ("Courses", "courses"),
        ("Enrolments", "enrolments"),
    ):
        count = connection.execute("SELECT COUNT(*) FROM " + table).fetchone()[0]
        print(f"{label}: {count}")
    names = [
        row[0]
        for row in connection.execute(
            "SELECT l.full_name FROM enrolments AS e "
            "JOIN learners AS l ON e.learner_id = l.learner_id "
            "WHERE e.course_id = ? ORDER BY l.full_name",
            (101,),
        )
    ]
    print("Course 101 learners:", ", ".join(names))


def main():
    parser = argparse.ArgumentParser(description="Local relational-keys exercise")
    parser.add_argument("--add-learner", action="store_true")
    args = parser.parse_args()
    connection = build_database()
    try:
        if args.add_learner:
            connection.execute(
                "INSERT INTO learners (learner_id, email, full_name) VALUES (?, ?, ?)",
                (3, "maya@example.invalid", "Maya"),
            )
            connection.execute(
                "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
                (3, 102),
            )
        summary(connection)
    finally:
        connection.close()


if __name__ == "__main__":
    main()
