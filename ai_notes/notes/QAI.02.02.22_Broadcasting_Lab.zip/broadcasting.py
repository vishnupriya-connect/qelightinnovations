"""Broadcast scalars, vectors, and a matrix across labelled axes."""

import numpy as np


def make_examples():
    minutes = np.array([[10, 20, 30], [40, 50, 60]])
    task_bonus = np.array([1, 2, 3])
    learner_bonus = np.array([100, 200]).reshape(2, 1)
    weekly = np.arange(24).reshape(2, 3, 4)
    correction = np.array([[1, 2, 3, 4],
                           [5, 6, 7, 8],
                           [9, 10, 11, 12]])
    return minutes, task_bonus, learner_bonus, weekly, correction


def main():
    minutes, task_bonus, learner_bonus, weekly, correction = make_examples()
    scalar = minutes + 5
    tasks = minutes + task_bonus
    learners = minutes + learner_bonus
    matrix = weekly + correction
    print("Scalar:", scalar.shape, scalar.tolist())
    print("Task vector:", tasks.shape, tasks.tolist())
    print("Learner column:", learners.shape, learners.tolist())
    print("Matrix:", matrix.shape, matrix[1, 2, 3])
    print("Trace:", minutes[1, 2], task_bonus[2], tasks[1, 2],
          learner_bonus[1, 0], learners[1, 2])
    changed_bonus = task_bonus.copy()
    changed_bonus[2] = 9
    print("Variation:", (minutes + changed_bonus)[:, 2].tolist(),
          "original:", task_bonus[2])
    try:
        minutes + np.array([100, 200])
    except ValueError as error:
        print("Incompatible shapes:", minutes.shape, (2,), type(error).__name__)


if __name__ == "__main__":
    main()
