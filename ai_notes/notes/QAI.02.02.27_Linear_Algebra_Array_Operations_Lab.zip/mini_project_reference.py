"""Complete reference solution for two linked quantities."""

import numpy as np


def main():
    C = np.array([[3.0, 1.0], [1.0, 3.0]])
    D = np.array([[1.0, 0.0], [2.0, 1.0]])
    p = np.array([2.0, 1.0])
    q = np.array([4.0, 3.0])
    t = np.array([7.0, 5.0])
    x = np.linalg.solve(C, t)
    values, vectors = np.linalg.eig(C)
    pair_ok = all(np.allclose(C @ vectors[:, i], values[i] * vectors[:, i])
                  for i in range(len(values)))
    print("element-wise", (C * D).tolist())
    print("matrix", (C @ D).tolist())
    print("dot", np.dot(p, q))
    print("outer", np.outer(p, q).tolist())
    print("solution", np.round(x, 6).tolist())
    print("verified", bool(np.allclose(C @ x, t)))
    print("determinant", round(float(np.linalg.det(C)), 6),
          "rank", np.linalg.matrix_rank(C))
    print("inverse", np.round(np.linalg.inv(C), 3).tolist())
    print("eigenvalues", np.sort(np.round(values, 6)).tolist())
    print("eigenpair verified", pair_ok)


if __name__ == "__main__":
    main()
