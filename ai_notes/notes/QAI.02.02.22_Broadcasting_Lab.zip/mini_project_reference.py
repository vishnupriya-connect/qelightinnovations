"""Complete reference solution for task and learner bonuses."""

import numpy as np


def main():
    base = np.array([[20, 30, 40], [25, 35, 45]])
    task_bonus = np.array([1, 2, 3])
    learner_bonus = np.array([10, 20]).reshape(2, 1)
    scalar = base + 5
    tasks = base + task_bonus
    combined = base + task_bonus + learner_bonus
    print("scalar", scalar.shape, scalar.tolist())
    print("tasks", tasks.shape, tasks.tolist())
    print("combined", combined.shape, combined.tolist())
    print("trace", base[1, 2], task_bonus[2], learner_bonus[1, 0], combined[1, 2])


if __name__ == "__main__":
    main()
