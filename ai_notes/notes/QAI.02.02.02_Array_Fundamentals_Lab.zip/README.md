# Array fundamentals lab

Run with Python and NumPy installed in the same environment:

```sh
python -m pip install -r requirements.txt
python array_fundamentals.py
python check_array_fundamentals.py
```

Use `python3` where your environment requires it. Predict the outputs first. Change C's reading from 40 to 50 in a scratch copy and confirm a total of 70. For the independent workshop task, write your own program before opening `mini_project_reference.py`; compare your output afterward.

The code specifies `np.int32` so the four-byte item size is consistent across machines. Your installed NumPy version can be printed with `python -c "import numpy; print(numpy.__version__)"`.
