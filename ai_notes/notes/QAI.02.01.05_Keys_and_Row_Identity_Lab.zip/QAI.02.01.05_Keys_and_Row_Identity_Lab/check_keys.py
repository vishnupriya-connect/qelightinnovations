"""Independent negative cases: each uses a fresh copy of the small database."""

import sqlite3

from db_keys import build_database


CASES = [
    (
        "Duplicate learner ID",
        "INSERT INTO learners (learner_id, email, full_name) VALUES (?, ?, ?)",
        (1, "new@example.invalid", "New person"),
        "learners",
    ),
    (
        "Duplicate course code",
        "INSERT INTO courses (course_id, course_code, title) VALUES (?, ?, ?)",
        (103, "AI-FOUND", "Another course"),
        "courses",
    ),
    (
        "Duplicate enrolment pair",
        "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
        (1, 101),
        "enrolments",
    ),
    (
        "Unknown learner reference",
        "INSERT INTO enrolments (learner_id, course_id) VALUES (?, ?)",
        (999, 101),
        "enrolments",
    ),
    (
        "Missing required email",
        "INSERT INTO learners (learner_id, email, full_name) VALUES (?, ?, ?)",
        (3, None, "New person"),
        "learners",
    ),
]


def check_one(label, sql, values, affected_table):
    connection = build_database()
    try:
        before = connection.execute(
            "SELECT COUNT(*) FROM " + affected_table
        ).fetchone()[0]
        try:
            connection.execute(sql, values)
        except sqlite3.IntegrityError:
            after = connection.execute(
                "SELECT COUNT(*) FROM " + affected_table
            ).fetchone()[0]
            assert before == after, (label, "table changed despite rejected insert")
            print(label + ": rejected")
        else:
            raise AssertionError(label + ": the database accepted invalid data")
    finally:
        connection.close()


def main():
    for case in CASES:
        check_one(*case)
    print("Checks passed:", len(CASES))


if __name__ == "__main__":
    main()
