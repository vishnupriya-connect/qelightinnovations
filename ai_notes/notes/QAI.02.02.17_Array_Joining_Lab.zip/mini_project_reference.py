"""Complete reference solution for combining study sessions."""

import numpy as np


def main():
    morning = np.array([[5, 7], [9, 11]])
    evening = np.array([[6, 8], [10, 12]])
    rows = np.concatenate((morning, evening), axis=0)
    sessions = np.stack((morning, evening), axis=0)
    depth = np.dstack((morning, evening))
    first_task = np.column_stack((morning[:, 0], evening[:, 0]))
    print("rows", rows.shape, rows[3, 0])
    print("sessions", sessions.shape, sessions[1, 1, 0])
    print("depth", depth.shape, depth[1, 0, 1])
    print("first task", first_task.shape, first_task.tolist())


if __name__ == "__main__":
    main()
