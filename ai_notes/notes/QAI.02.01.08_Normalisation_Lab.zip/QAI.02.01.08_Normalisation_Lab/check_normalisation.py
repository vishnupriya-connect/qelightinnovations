"""Run deliberate failures and valid edits against the same small database."""
import sqlite3
from normalisation import SAMPLE, connect, create_flat, migrate, reconstructed


def ready():
    db = connect()
    create_flat(db)
    migrate(db)
    return db


def main():
    db = ready()
    # Changing an instructor once is reflected in every reconstructed row.
    db.execute("UPDATE instructors SET instructor_name = ? WHERE instructor_id = ?",
               ("Nisha Rao", 7))
    names = {row[5] for row in reconstructed(db) if row[4] == 7}
    assert names == {"Nisha Rao"}
    print("PASS: one instructor edit updates every reconstructed row")

    # The course survives deleting its last enrolment.
    db.execute("DELETE FROM enrolments WHERE learner_id = 1 AND course_id = 102")
    assert db.execute("SELECT COUNT(*) FROM courses WHERE course_id = 102").fetchone()[0] == 1
    print("PASS: course 102 survives deletion of its last enrolment")

    # New course can be added before any learner joins.
    db.execute("INSERT INTO courses VALUES (?, ?, ?)", (103, "Data Basics", 7))
    assert db.execute("SELECT COUNT(*) FROM enrolments WHERE course_id = 103").fetchone()[0] == 0
    print("PASS: course 103 exists before any enrolment")
    try:
        db.execute("INSERT INTO enrolments VALUES (?, ?, ?)", (999, 103, "2026-09-04"))
    except sqlite3.IntegrityError:
        print("PASS: unknown learner cannot enrol")
    else:
        raise AssertionError("Missing foreign-key enforcement")
    db.close()

    # A messy import requires explicit review before migration.
    bad_rows = SAMPLE + [(3, "Meera", 101, "AI Foundations", 7, "Nisha Rao", "2026-09-04")]
    db = connect()
    create_flat(db, bad_rows)
    try:
        migrate(db)
    except ValueError as exc:
        assert str(exc) == "Conflicting instructor details for ID 7"
        assert db.execute("SELECT COUNT(*) FROM sqlite_master "
                          "WHERE type = 'table' AND name = 'instructors'").fetchone()[0] == 0
        print("PASS: conflicting instructor names flagged before migration")
    else:
        raise AssertionError("Conflicting import was silently accepted")
    db.close()


if __name__ == "__main__":
    main()
