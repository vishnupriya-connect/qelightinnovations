"""Meaningful result, boundary, and independent-variation checks."""

from calculated_columns import (
    COURSES,
    course_preview,
    lesson_split,
    make_connection,
    query,
)


def main():
    with make_connection() as connection:
        before = query(
            connection, "SELECT course_id, title, instructor_id, "
            "duration_minutes, lesson_count "
            "FROM course_catalogue ORDER BY course_id;"
        )[1]
        assert before == COURSES

        names, rows = query(
            connection,
            "SELECT course_id, duration_minutes + 10 AS plus_10, "
            "duration_minutes - 5 AS minus_5, "
            "duration_minutes * 2 AS twice, "
            "duration_minutes / lesson_count AS whole_per_lesson, "
            "duration_minutes % lesson_count AS leftover "
            "FROM course_catalogue ORDER BY course_id;",
        )
        assert names == [
            "course_id", "plus_10", "minus_5", "twice",
            "whole_per_lesson", "leftover"
        ]
        assert rows == [
            (101, 105, 90, 190, 23, 3),
            (102, 60, 45, 100, 16, 2),
            (103, 90, 75, 160, 20, 0),
            (104, 75, 60, 130, 21, 2),
        ]
        print("Four arithmetic rows: correct")

        grouping = query(
            connection,
            "SELECT duration_minutes + 10 * lesson_count, "
            "(duration_minutes + 10) * lesson_count "
            "FROM course_catalogue ORDER BY course_id;",
        )[1]
        assert grouping == [(135, 420), (80, 180), (120, 360), (95, 225)]
        print("Precedence and parentheses: correct")

        assert query(connection, "SELECT 5 / 2, 5 / 2.0, 5 % 2;")[1] == [
            (2, 2.5, 1)
        ]
        assert query(connection, "SELECT 1 / 0, 1 % 0;")[1] == [(None, None)]
        print("Integer/real division and zero divisor: correct")

        preview_names, preview_rows = course_preview(connection)
        assert preview_names == [
            "course_id", "title", "duration_minutes",
            "extended_minutes", "leftover_minutes", "label"
        ]
        assert preview_rows == [
            (101, "AI Foundations", 95, 105, 5, "AI Foundations (101)"),
            (102, "Git Basics", 50, 60, 20, "Git Basics (102)"),
            (103, "Data Basics", 80, 90, 20, "Data Basics (103)"),
            (104, "Python Basics", 65, 75, 5, "Python Basics (104)"),
        ]
        print("Catalogue preview: four expected rows")

        split_names, split_rows = lesson_split(connection)
        assert split_names == ["course_id", "whole_minutes", "leftover_minutes"]
        assert split_rows == [
            (101, 23, 3), (102, 16, 2), (103, 20, 0), (104, 21, 2)
        ]
        assert all(
            whole * count + leftover == duration
            for (_, _, _, duration, count), (_, whole, leftover)
            in zip(COURSES, split_rows)
        )
        print("Lesson split reconstructs each duration: yes")

        after = query(
            connection, "SELECT course_id, title, instructor_id, "
            "duration_minutes, lesson_count "
            "FROM course_catalogue ORDER BY course_id;"
        )[1]
        assert before == after
        print("Stored source unchanged: True")


if __name__ == "__main__":
    main()
