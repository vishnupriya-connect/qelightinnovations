"""Split arrays by equal counts or explicit cut positions."""

import numpy as np


def make_examples():
    table = np.arange(24, dtype=np.int32).reshape(4, 6)
    top, bottom = np.split(table, 2, axis=0)
    left, middle, right = np.split(table, [2, 5], axis=1)
    values = np.arange(8, dtype=np.int32)
    cube = np.arange(24, dtype=np.int32).reshape(2, 3, 4)
    early, late = np.dsplit(cube, 2)
    return table, top, bottom, left, middle, right, values, cube, early, late


def main():
    table, top, bottom, left, middle, right, values, cube, early, late = make_examples()
    print("Table:", table.shape)
    print("Equal row split:", top.shape, bottom.shape, bottom[0, 4])
    print("Column cuts:", [p.shape for p in (left, middle, right)], middle[2, 2])
    print("Unequal vector split:", [p.tolist() for p in np.split(values, [3, 5])])
    print("Near-equal vector split:", [p.tolist() for p in np.array_split(values, 3)])
    print("Horizontal:", [p.shape for p in np.hsplit(table, 3)])
    print("Vertical:", [p.shape for p in np.vsplit(table, 2)])
    print("Depth:", cube.shape, early.shape, late.shape, late[1, 2, 1])
    changed = cube.copy()
    changed[1, 2, 3] = 99
    print("Copied source:", np.dsplit(changed, 2)[1][1, 2, 1], "original:", cube[1, 2, 3])
    print("Pieces are views:", np.shares_memory(cube, late))


if __name__ == "__main__":
    main()
