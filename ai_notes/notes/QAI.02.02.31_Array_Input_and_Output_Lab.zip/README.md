# QAI.02.02.31 — Array input and output lab

Save and load a NumPy array in binary and text formats. The examples use only temporary files, except for the independent mini-project reference, which creates `study_output/`.

## Run

```bash
python -m pip install -r requirements.txt
python array_input_and_output.py
python check_array_input_and_output.py
python mini_project_reference.py
```

The guided program saves one `.npy` file, a named `.npz` archive, and a comma-delimited `.csv` file. It verifies the values, shape, and dtype after loading and then changes one score in a separately saved copy. The checker prints `All checks passed.` when the round trips work.

Try changing the last score from `60` to `99` in `array_input_and_output.py`. Save the changed array to a new path and confirm that the original file still loads with `60`.
