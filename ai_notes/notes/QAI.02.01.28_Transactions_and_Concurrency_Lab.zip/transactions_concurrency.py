"""Transactions on a temporary SQLite file, with two independent connections."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory


def connect(path, timeout=1):
    # Explicit SQL BEGIN / COMMIT / ROLLBACK, independent of Python defaults.
    return sqlite3.connect(path, isolation_level=None, timeout=timeout)


def setup(path):
    db = connect(path)
    assert db.execute('PRAGMA journal_mode=WAL').fetchone()[0] == 'wal'
    db.execute('PRAGMA synchronous=FULL')
    db.executescript("""
        CREATE TABLE accounts (
            owner TEXT PRIMARY KEY,
            balance INTEGER NOT NULL CHECK(balance >= 0)
        );
        INSERT INTO accounts VALUES ('Ada', 100), ('Ben', 40);
        CREATE TABLE transfers (
            transfer_id TEXT PRIMARY KEY,
            amount INTEGER NOT NULL CHECK(amount > 0)
        );
        CREATE TABLE seats (
            resource TEXT PRIMARY KEY,
            available INTEGER NOT NULL CHECK(available >= 0)
        );
        INSERT INTO seats VALUES ('workshop', 2);
        CREATE TABLE settings (revision INTEGER NOT NULL);
        INSERT INTO settings VALUES (0);
    """)
    db.close()


def balances(db):
    return db.execute('SELECT owner, balance FROM accounts ORDER BY owner').fetchall()


def transfer(db, transfer_id, amount):
    if type(amount) is not int or amount <= 0:
        raise ValueError('amount must be a positive integer')
    try:
        db.execute('BEGIN IMMEDIATE')
        source = db.execute("SELECT balance FROM accounts WHERE owner='Ada'").fetchone()[0]
        if source < amount:
            raise ValueError('insufficient funds')
        db.execute("UPDATE accounts SET balance=balance-? WHERE owner='Ada'", (amount,))
        db.execute("UPDATE accounts SET balance=balance+? WHERE owner='Ben'", (amount,))
        db.execute('INSERT INTO transfers VALUES (?, ?)', (transfer_id, amount))
        db.execute('COMMIT')
    except Exception:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise


def transfer_demo(path):
    db = connect(path)
    transfer(db, 'T1', 30)
    after_commit = balances(db)
    try:
        transfer(db, 'T1', 20)  # duplicate receipt ID, after both balance writes
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError('expected duplicate transfer ID')
    after_failure = balances(db)
    receipts = db.execute('SELECT transfer_id, amount FROM transfers').fetchall()
    db.close()
    reopened = connect(path)
    reopened_balances = balances(reopened)
    reopened.close()
    return after_commit, after_failure, receipts, reopened_balances


def concurrency_demo(path):
    a, b = connect(path), connect(path, timeout=0)
    try:
        a.execute('BEGIN IMMEDIATE')
        a.execute("UPDATE seats SET available=available-1 WHERE resource='workshop'")
        own = a.execute("SELECT available FROM seats WHERE resource='workshop'").fetchone()[0]
        other_before = b.execute("SELECT available FROM seats WHERE resource='workshop'").fetchone()[0]
        busy = False
        try:
            b.execute('BEGIN IMMEDIATE')
        except sqlite3.OperationalError as error:
            if error.sqlite_errorcode != sqlite3.SQLITE_BUSY:
                raise
            busy = True
        else:
            b.execute('ROLLBACK')
        a.execute('COMMIT')
        other_after = b.execute("SELECT available FROM seats WHERE resource='workshop'").fetchone()[0]
        # Retry the whole business operation with a fresh transaction and read.
        b.execute('BEGIN IMMEDIATE')
        current = b.execute("SELECT available FROM seats WHERE resource='workshop'").fetchone()[0]
        if current < 1:
            b.execute('ROLLBACK')
            raise AssertionError('no seat remains')
        b.execute("UPDATE seats SET available=available-1 WHERE resource='workshop'")
        b.execute('COMMIT')
        final = a.execute("SELECT available FROM seats WHERE resource='workshop'").fetchone()[0]
        return own, other_before, busy, other_after, final
    finally:
        if a.in_transaction:
            a.execute('ROLLBACK')
        if b.in_transaction:
            b.execute('ROLLBACK')
        a.close()
        b.close()


def autocommit_demo(path):
    a, b = connect(path), connect(path)
    try:
        a.execute('UPDATE settings SET revision=1')  # one statement commits itself
        visible = b.execute('SELECT revision FROM settings').fetchone()[0]
        a.execute('BEGIN')
        a.execute('UPDATE settings SET revision=2')
        a.execute('ROLLBACK')
        after_rollback = b.execute('SELECT revision FROM settings').fetchone()[0]
        return visible, after_rollback
    finally:
        a.close()
        b.close()


def sold_out_variation(path):
    """A complete reference for a one-seat competing-request variation."""
    setup(path)
    a, b = connect(path), connect(path, timeout=0)
    try:
        a.execute("UPDATE seats SET available=1 WHERE resource='workshop'")
        a.execute('BEGIN IMMEDIATE')
        a.execute("UPDATE seats SET available=available-1 WHERE resource='workshop'")
        observed_before = b.execute("SELECT available FROM seats").fetchone()[0]
        busy = False
        try:
            b.execute('BEGIN IMMEDIATE')
        except sqlite3.OperationalError as error:
            if error.sqlite_errorcode != sqlite3.SQLITE_BUSY:
                raise
            busy = True
        else:
            b.execute('ROLLBACK')
        a.execute('COMMIT')
        b.execute('BEGIN IMMEDIATE')
        observed_after = b.execute("SELECT available FROM seats").fetchone()[0]
        if observed_after != 0:
            raise AssertionError('expected sold-out state')
        b.execute('ROLLBACK')  # no booking or decrement on refusal
        final = a.execute("SELECT available FROM seats").fetchone()[0]
        return observed_before, busy, observed_after, final
    finally:
        if a.in_transaction:
            a.execute('ROLLBACK')
        if b.in_transaction:
            b.execute('ROLLBACK')
        a.close()
        b.close()


def main():
    with TemporaryDirectory(prefix='qai_transactions_') as folder:
        path = Path(folder) / 'lesson.sqlite'
        setup(path)
        committed, rolled_back, receipts, reopened = transfer_demo(path)
        print('After committed transfer:', committed)
        print('After failed transfer:', rolled_back)
        print('Transfer receipts:', receipts)
        print('After reopen:', reopened)
        print('Concurrent writer (own, other before, busy, other after, final):', concurrency_demo(path))
        print('Autocommit then rollback (visible, final):', autocommit_demo(path))
        print('Independent sold-out variation (before, busy, after, final):',
              sold_out_variation(Path(folder) / 'variation.sqlite'))


if __name__ == '__main__':
    main()
