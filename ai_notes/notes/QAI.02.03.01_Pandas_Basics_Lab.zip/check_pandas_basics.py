"""Meaningful checks for the lesson's labels and values."""

import pandas as pd

from pandas_basics import make_examples


def main():
    scores, table = make_examples()
    assert isinstance(scores, pd.Series)
    assert scores.ndim == 1
    assert scores.index.tolist() == ["Asha", "Bala", "Charu"]
    assert scores["Bala"] == 9

    assert isinstance(table, pd.DataFrame)
    assert table.ndim == 2
    assert table.shape == (2, 2)
    assert table.index.tolist() == ["L1", "L2"]
    assert table.columns.tolist() == ["name", "score"]
    assert table.axes[0].tolist() == ["L1", "L2"]
    assert table.axes[1].tolist() == ["name", "score"]
    assert isinstance(table["score"], pd.Series)
    assert table["score"].index.tolist() == ["L1", "L2"]
    assert table["score"].tolist() == [7, 9]
    assert table.loc["L2", "score"] == 9

    try:
        table["Score"]
    except KeyError:
        pass
    else:
        raise AssertionError("Column labels must match exactly.")
    print("All checks passed.")


if __name__ == "__main__":
    main()
