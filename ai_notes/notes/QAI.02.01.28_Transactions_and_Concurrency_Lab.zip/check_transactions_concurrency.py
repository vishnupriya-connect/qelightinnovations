"""Independent checks for transfer boundaries and two-connection visibility."""

import sqlite3
from pathlib import Path
from tempfile import TemporaryDirectory

from transactions_concurrency import (
    autocommit_demo, balances, concurrency_demo, connect, setup, transfer,
    transfer_demo,
    sold_out_variation,
)

with TemporaryDirectory(prefix='qai_transactions_check_') as folder:
    path = Path(folder) / 'check.sqlite'
    setup(path)
    committed, failed, receipts, reopened = transfer_demo(path)
    assert committed == failed == reopened == [('Ada', 70), ('Ben', 70)]
    assert receipts == [('T1', 30)]
    assert sum(balance for _, balance in reopened) == 140
    print('Transfer commit, duplicate-ID failure rollback, and reopen: correct')

    db = connect(path)
    try:
        transfer(db, 'T2', 90)
    except ValueError:
        pass
    else:
        raise AssertionError('oversized transfer should fail')
    assert balances(db) == [('Ada', 70), ('Ben', 70)]
    assert db.execute('SELECT COUNT(*) FROM transfers').fetchone() == (1,)
    assert not db.in_transaction
    db.close()
    print('Business rule failure leaves balances and receipts intact: correct')

    assert concurrency_demo(path) == (1, 2, True, 1, 0)
    print('Writer lock, isolation, commit visibility, and fresh retry: correct')
    assert autocommit_demo(path) == (1, 1)
    print('Standalone statement auto-commit and explicit rollback: correct')

    observer = connect(path)
    assert observer.execute('SELECT available FROM seats').fetchone() == (0,)
    try:
        observer.execute("UPDATE seats SET available=-1")
    except sqlite3.IntegrityError:
        pass
    else:
        raise AssertionError('CHECK should reject negative available seats')
    assert observer.execute('SELECT available FROM seats').fetchone() == (0,)
    observer.close()
    print('Database consistency constraint rejects negative seats: correct')

    assert sold_out_variation(Path(folder) / 'variation.sqlite') == (1, True, 0, 0)
    print('One-seat variation refuses stale second request: correct')
