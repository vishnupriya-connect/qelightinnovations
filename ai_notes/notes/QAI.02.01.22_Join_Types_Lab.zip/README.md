# Join types lab

Run from the unzipped folder with Python 3 and SQLite 3.39.0 or later:

```sh
python join_types.py
python check_join_types.py
```

Use `python3` if needed. Check the SQLite version used by Python with `python -c "import sqlite3; print(sqlite3.sqlite_version)"`. The standard-library `sqlite3` module creates only private in-memory tables. Predict which rows survive INNER, LEFT, RIGHT and FULL joins. Change an ON condition and compare it with filtering after a LEFT join. Attempt the unmatched audit and self-join pair query before reading their reference functions. The checker validates supplied examples; assess your own edits separately.
