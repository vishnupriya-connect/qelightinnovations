"""Compare a step, a sample count, and evenly spaced exponents."""

import numpy as np


def example_sequences():
    return {
        "step": np.arange(2, 11, 2, dtype=np.int32),
        "descending": np.arange(10, 1, -3, dtype=np.int32),
        "inclusive": np.linspace(0, 1, num=5),
        "exclusive": np.linspace(0, 1, num=4, endpoint=False),
        "powers_of_ten": np.logspace(0, 3, num=4, base=10),
        "powers_of_two": np.logspace(0, 3, num=4, base=2),
        "excluded_power": np.logspace(0, 3, num=3, endpoint=False, base=10),
    }


def six_checkpoints(endpoint=True):
    return np.linspace(0, 10, num=6, endpoint=endpoint)


def wrong_direction():
    return np.arange(2, 11, -2)


def main():
    for name, array in example_sequences().items():
        print(f"{name}: {array.tolist()} (size {array.size})")
    print("Six including 10:", six_checkpoints().tolist())
    print("Six excluding 10:", six_checkpoints(endpoint=False).tolist())
    print("Wrong direction:", wrong_direction().tolist())
    try:
        np.arange(0, 5, 0)
    except ZeroDivisionError as error:
        print("Zero step:", type(error).__name__)
    print("Corrected step:", np.arange(2, 11, 2).tolist())


if __name__ == "__main__":
    main()
