"""Check schema changes, expected failures, and a bounded independent variant."""

import sqlite3

from schema_lab import columns, make_courses, migrate_courses


def main():
    if sqlite3.sqlite_version_info < (3, 35, 0):
        raise RuntimeError("These checks need SQLite 3.35.0+ for DROP COLUMN")
    with sqlite3.connect(":memory:") as connection:
        make_courses(connection)
        original = connection.execute(
            "SELECT course_id, course_title, instructor_id "
            "FROM courses ORDER BY course_id;"
        ).fetchall()

        try:
            connection.execute("CREATE TABLE courses (other INTEGER);")
        except sqlite3.OperationalError as exc:
            assert "already exists" in str(exc)
        else:
            raise AssertionError("Duplicate table creation should fail")
        print("Duplicate CREATE rejected: yes")

        added, renamed, final = migrate_courses(connection)
        assert added == [
            "course_id", "course_title", "instructor_id", "delivery_mode"
        ]
        assert renamed == [
            "course_id", "title", "instructor_id", "delivery_mode"
        ]
        assert final == ["course_id", "title", "instructor_id"]
        assert connection.execute(
            "SELECT course_id, title, instructor_id "
            "FROM course_catalogue ORDER BY course_id;"
        ).fetchall() == original
        print("Migration preserved rows: yes")

        try:
            connection.execute(
                "ALTER TABLE course_catalogue DROP COLUMN course_id;"
            )
        except sqlite3.OperationalError as exc:
            assert "PRIMARY KEY" in str(exc)
        else:
            raise AssertionError("Dropping the primary key should fail")
        assert columns(connection, "course_catalogue") == final
        print("Primary-key DROP rejected; schema unchanged: yes")

        # Independent variant reference: a separate, bounded table.
        connection.execute(
            "CREATE TABLE course_tags (course_id INTEGER PRIMARY KEY, tag TEXT);"
        )
        connection.execute(
            "INSERT INTO course_tags VALUES (101, 'foundation');"
        )
        connection.execute(
            "ALTER TABLE course_tags ADD COLUMN source TEXT "
            "NOT NULL DEFAULT 'manual';"
        )
        connection.execute(
            "ALTER TABLE course_tags RENAME COLUMN tag TO tag_name;"
        )
        assert [r[1] for r in connection.execute(
            "PRAGMA table_info(course_tags);"
        )] == ["course_id", "tag_name", "source"]
        assert connection.execute(
            "SELECT course_id, tag_name, source FROM course_tags;"
        ).fetchone() == (101, "foundation", "manual")
        print("Independent tag variant: yes")

        connection.execute("CREATE TABLE scratch (x INTEGER);")
        connection.execute("DROP TABLE IF EXISTS scratch;")
        connection.execute("DROP TABLE IF EXISTS scratch;")
        assert connection.execute(
            "SELECT 1 FROM sqlite_schema WHERE name='scratch';"
        ).fetchone() is None
        print("Repeated safe DROP on missing scratch: yes")


if __name__ == "__main__":
    main()
