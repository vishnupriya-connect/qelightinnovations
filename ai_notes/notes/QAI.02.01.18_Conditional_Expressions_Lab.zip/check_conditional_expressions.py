"""Check CASE branch order, boundaries, omitted ELSE, and null replacement."""

from conditional_expressions import (
    COURSES,
    duration_categories,
    independent_variation,
    make_connection,
    note_display,
    project_view,
)


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        assert before == COURSES
        assert duration_categories(db) == [
            (101, "Extended"), (102, "Short"),
            (103, "Extended"), (104, "Standard"),
        ]
        assert duration_categories(db, 81, 66) == [
            (101, "Extended"), (102, "Short"),
            (103, "Standard"), (104, "Short"),
        ]
        print("CASE categories and changed boundaries: correct")

        assert db.execute(
            """SELECT course_id,
                 CASE WHEN duration_minutes >= 60 THEN 'Standard'
                      WHEN duration_minutes >= 80 THEN 'Extended'
                      ELSE 'Short' END
               FROM course_catalogue ORDER BY course_id"""
        ).fetchall() == [
            (101, "Standard"), (102, "Short"),
            (103, "Standard"), (104, "Standard"),
        ]
        assert db.execute(
            """SELECT course_id, CASE WHEN duration_minutes >= 80 THEN 'Extended' END
               FROM course_catalogue ORDER BY course_id"""
        ).fetchall() == [
            (101, "Extended"), (102, None),
            (103, "Extended"), (104, None),
        ]
        print("First true branch and missing ELSE: correct")

        assert note_display(db) == [
            (101, "intro"), (102, "Not recorded"),
            (103, "tables"), (104, "Not recorded"),
        ]
        assert db.execute(
            "SELECT COALESCE(NULL, NULL, 'Fallback'), COALESCE(NULL, NULL)"
        ).fetchone() == ("Fallback", None)
        assert db.execute(
            "SELECT COUNT(topic_note) FROM course_catalogue"
        ).fetchone() == (2,)
        print("COALESCE first present value and unchanged missingness: correct")

        assert project_view(db) == [
            (102, "Git Basics", "Short", "Needs note"),
            (103, "Data Basics", "Extended", "tables"),
            (104, "Python Basics", "Standard", "Needs note"),
        ]
        assert independent_variation(db) == [
            (101, "Less practice", "intro"),
            (102, "Unestimated", "Needs note"),
            (103, "More practice", "tables"),
            (104, "Unestimated", "Needs note"),
        ]
        assert db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall() == before
        print("Mini-project, variation, and unchanged source: correct")


if __name__ == "__main__":
    main()
