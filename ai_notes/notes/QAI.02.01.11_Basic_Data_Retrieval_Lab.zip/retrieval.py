"""A small read-only catalogue projection lab using SQLite."""

import sqlite3


def make_connection():
    connection = sqlite3.connect(":memory:")
    connection.execute(
        """CREATE TABLE course_catalogue (
               course_id INTEGER PRIMARY KEY,
               title TEXT NOT NULL,
               instructor_id INTEGER NOT NULL
           );"""
    )
    connection.executemany(
        "INSERT INTO course_catalogue (course_id, title, instructor_id) "
        "VALUES (?, ?, ?);",
        [
            (101, "AI Foundations", 7),
            (102, "Git Basics", 8),
            (103, "Data Basics", 7),
            (104, "Python Basics", 8),
        ],
    )
    connection.commit()
    return connection


def result(connection, statement):
    """Run one fixed read query and return its output headings and rows."""
    cursor = connection.execute(statement)
    return [item[0] for item in cursor.description], cursor.fetchall()


def teacher_directory(connection):
    """A solved compact directory: each instructor ID occurs once."""
    return result(
        connection,
        "SELECT DISTINCT c.instructor_id AS teacher_id "
        "FROM course_catalogue AS c ORDER BY teacher_id;",
    )


def main():
    with make_connection() as connection:
        original = result(
            connection,
            "SELECT course_id, title, instructor_id "
            "FROM course_catalogue ORDER BY course_id;",
        )[1]
        selected_names, selected_rows = result(
            connection,
            "SELECT course_id, title FROM course_catalogue ORDER BY course_id;",
        )
        all_names, all_rows = result(
            connection,
            "SELECT * FROM course_catalogue ORDER BY course_id;",
        )
        alias_names, alias_rows = result(
            connection,
            "SELECT c.course_id AS id, c.title AS course "
            "FROM course_catalogue AS c ORDER BY c.course_id;",
        )
        repeated_names, repeated_rows = result(
            connection,
            "SELECT instructor_id FROM course_catalogue ORDER BY course_id;",
        )
        unique_names, unique_rows = result(
            connection,
            "SELECT DISTINCT instructor_id FROM course_catalogue "
            "ORDER BY instructor_id;",
        )
        pair_names, pair_rows = result(
            connection,
            "SELECT DISTINCT instructor_id, title FROM course_catalogue "
            "ORDER BY instructor_id, title;",
        )
        after = result(
            connection,
            "SELECT course_id, title, instructor_id "
            "FROM course_catalogue ORDER BY course_id;",
        )[1]

        assert len(all_rows) == 4 and len(alias_rows) == 4
        assert repeated_names == unique_names == ["instructor_id"]
        assert pair_names == ["instructor_id", "title"]
        print("Selected headings:", ", ".join(selected_names))
        print("Selected first row:", selected_rows[0])
        print("All-column headings:", ", ".join(all_names))
        print("Alias headings:", ", ".join(alias_names))
        print("Repeated instructor values:", [row[0] for row in repeated_rows])
        print("Distinct instructor values:", [row[0] for row in unique_rows])
        print("Distinct instructor-title pairs:", len(pair_rows))
        print("Source rows unchanged:", original == after)


if __name__ == "__main__":
    main()
