"""Build regular NumPy arrays from ordinary Python lists."""

import numpy as np


def make_examples():
    one = np.array([20, 30, 40], dtype=np.int32)
    two = np.array([[20, 10], [30, 15], [40, 20]], dtype=np.int32)
    three = np.array([
        [[20, 10], [30, 15]],
        [[40, 20], [50, 25]],
    ], dtype=np.int32)
    return one, two, three


def convert_with_type(values, dtype):
    """Make a numeric array; let NumPy report invalid data."""
    return np.array(values, dtype=dtype)


def revised_table():
    rows = [[20, 10], [30, 18], [40, 20]]
    return convert_with_type(rows, np.int32)


def main():
    one, two, three = make_examples()
    for name, array in [("1D", one), ("2D", two), ("3D", three)]:
        print(f"{name}: shape={array.shape}, ndim={array.ndim}, size={array.size}, dtype={array.dtype}")
    print("3D selected value:", int(three[1, 0, 1]))

    mixed = np.array([20, 30.5, 40])
    print("Mixed numeric values:", mixed.tolist())
    print("Inferred numeric kind:", mixed.dtype.kind)
    fractional = convert_with_type([20, 30.5, 40], np.float64)
    print("Specified fractional type:", fractional.dtype, fractional.itemsize)

    source = [20, 30, 40]
    converted = convert_with_type(source, np.int32)
    source[0] = 99
    print("Source changed; array first value:", int(converted[0]))
    changed = revised_table()
    print("Revised row and shape:", changed[1].tolist(), changed.shape)
    print("Original row:", two[1].tolist())

    for name, values in [
        ("Uneven rows", [[20, 10], [30]]),
        ("Unusable numeric text", ["20", "not recorded", "40"]),
    ]:
        try:
            convert_with_type(values, np.int32)
        except ValueError as error:
            print(f"{name}: {type(error).__name__}")
    corrected = convert_with_type([[20, 10], [30, 15]], np.int32)
    print("Confirmed-value correction:", corrected.tolist(), corrected.shape)


if __name__ == "__main__":
    main()
