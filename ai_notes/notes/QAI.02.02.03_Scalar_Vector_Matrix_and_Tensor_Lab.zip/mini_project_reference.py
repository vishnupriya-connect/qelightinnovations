"""A reference for the independent two-day workshop task."""

import numpy as np

from array_dimensions import axis_lengths


def main():
    days = np.array([
        [[10, 5], [20, 10], [15, 5]],
        [[12, 8], [18, 12], [10, 10]],
    ], dtype=np.int32)
    print("Shape, ndim, size:", days.shape, days.ndim, days.size)
    print("Axis lengths:", axis_lengths(days))
    print("Selected value:", int(days[1, 1, 1]))
    print("Totals per day:", days.sum(axis=(1, 2)).tolist())
    print("Across-day learner/task totals:", days.sum(axis=0).tolist())
    revised = days.copy()
    revised[1, 1, 1] = 17
    print("Revised day 1 total:", int(revised.sum(axis=(1, 2))[1]))
    print("Original day 1 total:", int(days.sum(axis=(1, 2))[1]))
    try:
        days.sum(axis=3)
    except np.exceptions.AxisError as error:
        print("Invalid axis:", type(error).__name__, "; valid non-negative axes: 0, 1, 2")


if __name__ == "__main__":
    main()
