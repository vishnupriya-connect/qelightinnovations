# Python collections to NumPy arrays lab

Run in this folder:

```sh
python -m pip install -r requirements.txt
python collections_to_arrays.py
python check_collections_to_arrays.py
```

Use `python3` if appropriate. Predict shapes and types before running. Complete the two-week activity mini-project independently, then compare with `python mini_project_reference.py`. The examples were checked with NumPy 2.3.5; print your version with `python -c "import numpy; print(numpy.__version__)"`. An uneven or unknown input calls for investigation; the example with a confirmed value is a demonstration, not permission to invent missing measurements.
