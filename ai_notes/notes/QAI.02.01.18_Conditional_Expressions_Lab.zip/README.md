# Conditional SQL expressions lab

Run from this unzipped folder with Python 3:

```sh
python conditional_expressions.py
python check_conditional_expressions.py
```

Use `python3` if needed. The standard-library `sqlite3` module makes an in-memory catalogue. Predict the categories before running. Change the boundaries, reverse the WHEN clauses in a copy, and diagnose the wrong categories. Compare missing values in storage with their COALESCE display labels. Attempt the Basics mini-project and practice-category variation before reading their reference functions. The checker verifies supplied examples; compare your own edits separately.
