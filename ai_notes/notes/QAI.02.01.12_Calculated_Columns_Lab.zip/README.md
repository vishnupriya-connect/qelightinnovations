# SQL expressions and calculated columns lab

From this folder run:

```sh
python calculated_columns.py
python check_calculated_columns.py
```

Use `python3` if needed. Python's built-in `sqlite3` module creates a private in-memory sample. Nothing is written to an existing database. Predict before running, change one expression, document the mismatch and repair, and attempt the independent lesson-split query before opening the reference function and checks.
