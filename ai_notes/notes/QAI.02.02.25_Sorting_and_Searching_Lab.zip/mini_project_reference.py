"""Complete reference solution for reviewing score positions."""

import numpy as np


def main():
    marks = np.array([70, 55, 90, 70, 60])
    ascending = np.sort(marks)
    descending = ascending[::-1]
    original_positions = np.argsort(marks, kind="stable")
    at_least_70 = np.where(marks >= 70)[0]
    left = np.searchsorted(ascending, 70, side="left")
    right = np.searchsorted(ascending, 70, side="right")
    print("ascending", ascending.tolist())
    print("descending", descending.tolist())
    print("original positions", original_positions.tolist())
    print("at least 70", at_least_70.tolist())
    print("insert 70", left, right)
    print("unique", np.unique(marks).tolist())
    print("original", marks.tolist())


if __name__ == "__main__":
    main()
