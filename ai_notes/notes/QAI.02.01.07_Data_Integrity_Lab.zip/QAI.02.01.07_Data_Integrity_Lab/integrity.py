"""Runnable course catalogue demonstrating database-enforced rules."""
import argparse
import sqlite3


def open_connection(max_capacity=100):
    if not isinstance(max_capacity, int) or not 1 <= max_capacity <= 100:
        raise ValueError("max_capacity must be an integer between 1 and 100")
    connection = sqlite3.connect(":memory:")
    connection.execute("PRAGMA foreign_keys = ON")
    assert connection.execute("PRAGMA foreign_keys").fetchone()[0] == 1
    connection.executescript(
        """
        CREATE TABLE learners (
            learner_id INTEGER PRIMARY KEY,
            email TEXT NOT NULL UNIQUE,
            full_name TEXT NOT NULL CHECK (length(trim(full_name)) > 0)
        );
        CREATE TABLE courses (
            course_id INTEGER PRIMARY KEY,
            course_code TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            capacity INTEGER NOT NULL CHECK (capacity BETWEEN 1 AND """ + str(max_capacity) + """),
            published INTEGER NOT NULL DEFAULT 0 CHECK (published IN (0, 1))
        );
        CREATE TABLE enrolments (
            learner_id INTEGER NOT NULL REFERENCES learners(learner_id),
            course_id INTEGER NOT NULL REFERENCES courses(course_id),
            PRIMARY KEY (learner_id, course_id)
        );
        """
    )
    return connection


def seed(connection):
    with connection:
        connection.executemany(
            "INSERT INTO learners VALUES (?, ?, ?)",
            [(1, "anu@example.org", "Anu"), (2, "ravi@example.org", "Ravi")],
        )
        connection.execute(
            "INSERT INTO courses (course_id, course_code, title, capacity, published) "
            "VALUES (?, ?, ?, ?, ?)",
            (101, "AI-FOUND", "AI Foundations", 30, 1),
        )
        # Omitting published invokes its DEFAULT 0.
        connection.execute(
            "INSERT INTO courses (course_id, course_code, title, capacity) "
            "VALUES (?, ?, ?, ?)",
            (102, "GIT-BASIC", "Git Basics", 20),
        )
        connection.executemany(
            "INSERT INTO enrolments VALUES (?, ?)", [(1, 101), (1, 102), (2, 101)]
        )


def summary(connection):
    print("Foreign-key enforcement: on")
    for table in ("learners", "courses", "enrolments"):
        count = connection.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
        print(f"{table.title()}: {count}")
    for course_id, published in connection.execute(
        "SELECT course_id, published FROM courses ORDER BY course_id"
    ):
        print(f"Course {course_id} published: {published}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--add-course", action="store_true")
    args = parser.parse_args()
    db = open_connection()
    seed(db)
    if args.add_course:
        with db:
            db.execute(
                "INSERT INTO courses (course_id, course_code, title, capacity) "
                "VALUES (?, ?, ?, ?)",
                (103, "DATA-INTRO", "Data Introduction", 20),
            )
    summary(db)
    db.close()
