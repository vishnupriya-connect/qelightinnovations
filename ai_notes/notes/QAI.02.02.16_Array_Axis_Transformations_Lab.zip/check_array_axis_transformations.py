"""Check the shapes, values, and coordinate mappings in the guided lab."""

import numpy as np

from array_axis_transformations import make_examples


def main():
    work, vector, row, column, cube, by_task, swapped, moved = make_examples()
    assert work.shape == (2, 3)
    assert work.T.shape == (3, 2)
    assert np.array_equal(work.T, work.transpose())
    assert work[1, 0] == work.T[0, 1] == 10
    assert vector.shape == vector.T.shape == (3,)
    assert row.shape == (1, 3) and column.shape == (3, 1)
    assert np.array_equal(row.T, column)
    assert np.array_equal(column.T, row)
    assert np.array_equal(np.squeeze(row, axis=0), vector)
    assert np.array_equal(np.squeeze(column, axis=1), vector)
    try:
        np.squeeze(row, axis=1)
    except ValueError:
        pass
    else:
        raise AssertionError("Squeezing a non-singleton axis should fail")
    assert cube.shape == (2, 3, 4) and cube.size == 24
    assert by_task.shape == (4, 2, 3)
    assert swapped.shape == (4, 3, 2)
    assert moved.shape == (3, 4, 2)
    assert cube[1, 2, 3] == by_task[3, 1, 2] == swapped[3, 2, 1] == moved[2, 3, 1] == 23
    assert np.array_equal(cube.T, swapped)
    for result in (by_task, swapped, moved):
        assert result.size == cube.size
        assert np.shares_memory(cube, result)
    changed = cube.copy()
    changed[1, 2, 3] = 99
    assert changed.transpose(2, 0, 1)[3, 1, 2] == 99
    assert changed.swapaxes(0, 2)[3, 2, 1] == 99
    assert np.moveaxis(changed, 0, 2)[2, 3, 1] == 99
    assert cube[1, 2, 3] == 23
    print("All checks passed.")


if __name__ == "__main__":
    main()
