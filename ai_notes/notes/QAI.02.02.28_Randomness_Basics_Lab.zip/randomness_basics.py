"""Demonstrate seeded replay and separate generator states."""

from copy import deepcopy

import numpy as np


def same_seed_batches(seed=42):
    left = np.random.default_rng(seed)
    right = np.random.default_rng(seed)
    return (left.random(3), right.random(3),
            left.random(3), right.random(3))


def main():
    first_l, first_r, second_l, second_r = same_seed_batches()
    print("First shapes:", first_l.shape, first_r.shape)
    print("First batches match:", np.array_equal(first_l, first_r))
    print("Next batches match:", np.array_equal(second_l, second_r))
    a = np.random.default_rng(7)
    b = np.random.default_rng(7)
    first_a, first_b = a.random(), b.random()
    a.random()
    next_b = b.random()
    reference = np.random.default_rng(7)
    reference.random()
    print("Separate state:", first_a == first_b,
          next_b == reference.random(), a is not b)
    root = np.random.SeedSequence(2026)
    child_a, child_b = root.spawn(2)
    sim_a = np.random.default_rng(child_a)
    sim_b = np.random.default_rng(child_b)
    repeat_root = np.random.SeedSequence(2026)
    repeat_a, repeat_b = repeat_root.spawn(2)
    print("Spawned child replay:",
          np.array_equal(sim_a.random(3), np.random.default_rng(repeat_a).random(3)),
          np.array_equal(sim_b.random(3), np.random.default_rng(repeat_b).random(3)))
    rng = np.random.default_rng(11)
    rng.random(2)
    saved = deepcopy(rng.bit_generator.state)
    observed = rng.random(3)
    rng.bit_generator.state = saved
    print("Saved-state replay:", np.array_equal(observed, rng.random(3)))
    x = np.random.default_rng(42)
    y = np.random.default_rng(42)
    four = x.random(4)
    y.random(3)
    ref = np.random.default_rng(42)
    ref.random(3)
    print("Variation:", four[3] == ref.random(),
          four[3] == y.random())


if __name__ == "__main__":
    main()
