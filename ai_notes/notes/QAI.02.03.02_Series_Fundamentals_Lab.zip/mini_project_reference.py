"""Reference solution for reading pages by day."""

import pandas as pd

pages = pd.Series(
    {"Mon": 8, "Tue": 12, "Wed": 10, "Thu": 15},
    name="pages",
)
selected = pages[pages >= 10]
print("name", pages.name)
print("length", len(pages))
print("Tue", pages.loc["Tue"])
print("first two", pages.iloc[:2].tolist())
print("at least 10 labels", selected.index.tolist())
print("at least 10 values", selected.tolist())
