"""Check boundaries, wildcard shapes, missing values, and both projects."""

from special_filters import (
    COURSES,
    ids,
    independent_variation,
    make_connection,
    selected_courses,
)


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        assert before == COURSES

        assert ids(db, "course_id IN (?, ?)", (101, 104)) == [101, 104]
        assert ids(db, "course_id NOT IN (?, ?)", (101, 104)) == [102, 103]
        assert ids(db, "course_id NOT IN (?, ?)", (101, None)) == []
        print("Membership and NULL-list trap: correct")

        assert ids(db, "duration_minutes BETWEEN ? AND ?", (50, 80)) == [102, 103, 104]
        assert ids(db, "duration_minutes > ? AND duration_minutes < ?", (50, 80)) == [104]
        assert ids(db, "duration_minutes BETWEEN ? AND ?", (51, 79)) == [104]
        print("Inclusive and strict range boundaries: correct")

        patterns = {
            "Data%": [103],
            "%Basics": [102, 103, 104],
            "%Basic%": [102, 103, 104],
            "Git Basic_": [102],
            "Git Basic__": [],
            "Git Basic": [],
        }
        for pattern, expected in patterns.items():
            assert ids(db, "title LIKE ?", (pattern,)) == expected, pattern
        print("Prefix, suffix, substring, percent, underscore: correct")

        assert ids(db, "topic_note IS NULL") == [102, 104]
        assert ids(db, "topic_note IS NOT NULL") == [101, 103]
        assert ids(db, "topic_note = NULL") == []
        print("Missing and present notes: correct")

        assert selected_courses(db) == [(102, "Git Basics"), (104, "Python Basics")]
        assert independent_variation(db) == [101, 103]
        print("Project and independent variation: correct")

        after = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        assert before == after
        print("Stored rows unchanged: True")


if __name__ == "__main__":
    main()
