"""Calculate on corresponding elements of two arrays."""

import numpy as np


def make_arrays():
    a = np.array([[7, 8, 9], [10, 11, 12]], dtype=np.int32)
    b = np.array([[2, 3, 4], [3, 4, 5]], dtype=np.int32)
    return a, b


def safe_ratio(numerator, denominator):
    """Require nonzero divisors before computing a meaningful ratio."""
    if np.any(denominator == 0):
        raise ValueError("A zero divisor needs an explicit data decision")
    return np.divide(numerator, denominator)


def main():
    a, b = make_arrays()
    print("Inputs:", a.tolist(), b.tolist())
    print("Addition:", (a + b).tolist())
    print("Subtraction:", (a - b).tolist())
    print("Multiplication:", (a * b).tolist())
    print("Division (rounded display):", np.round(safe_ratio(a, b), 2).tolist())
    print("Floor division:", (a // b).tolist())
    print("Remainder:", (a % b).tolist())
    print("Square:", (a ** 2).tolist())
    print("Trace [0, 1]:", a[0, 1], b[0, 1], (a + b)[0, 1],
          (a * b)[0, 1], (a // b)[0, 1], (a % b)[0, 1])
    changed = a.copy()
    changed[0, 1] = 14
    print("Variation:", (changed + b)[0, 1], (changed - b)[0, 1],
          (changed * b)[0, 1], round(float((changed / b)[0, 1]), 3),
          (changed // b)[0, 1], (changed % b)[0, 1],
          (changed ** 2)[0, 1], "original:", a[0, 1])


if __name__ == "__main__":
    main()
