"""A small catalogue for tracing SQL WHERE conditions."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4),
    (102, "Git Basics", 8, 50, 3),
    (103, "Data Basics", 7, 80, 4),
    (104, "Python Basics", 8, 65, 3),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL
        );"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?);", COURSES)
    db.commit()
    return db


def ids(db, statement, parameters=()):
    """Read ordered IDs from a fixed SQL statement; values may be bound."""
    return [row[0] for row in db.execute(statement, parameters).fetchall()]


def long_by_instructor(db, minimum, instructor):
    """Reference for a parameterised, two-condition filter."""
    return ids(
        db,
        "SELECT course_id FROM course_catalogue "
        "WHERE duration_minutes >= ? AND instructor_id = ? "
        "ORDER BY course_id;",
        (minimum, instructor),
    )


def long_or_exception(db):
    """Reference mini-project: long courses by 7, plus the Git exception."""
    return ids(
        db,
        "SELECT course_id FROM course_catalogue "
        "WHERE (instructor_id = 7 AND duration_minutes >= 80) "
        "OR title = 'Git Basics' ORDER BY course_id;",
    )


def main():
    with make_connection() as db:
        before = db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id;"
        ).fetchall()
        query_base = "SELECT course_id FROM course_catalogue WHERE "
        ordered = " ORDER BY course_id;"
        print("At least 80:", ids(db, query_base + "duration_minutes >= 80" + ordered))
        print("Exactly 80:", ids(db, query_base + "duration_minutes = 80" + ordered))
        print("Below 80:", ids(db, query_base + "duration_minutes < 80" + ordered))
        print("Instructor 7 AND at least 80:", long_by_instructor(db, 80, 7))
        print("Instructor 8 OR over 90:", ids(
            db, query_base + "instructor_id = 8 OR duration_minutes > 90" + ordered
        ))
        print("NOT instructor 8:", ids(db, query_base + "NOT (instructor_id = 8)" + ordered))
        print("Ungrouped:", ids(
            db, query_base +
            "title = 'Git Basics' OR instructor_id = 7 "
            "AND duration_minutes >= 90" + ordered
        ))
        print("Grouped:", ids(
            db, query_base +
            "(title = 'Git Basics' OR instructor_id = 7) "
            "AND duration_minutes >= 90" + ordered
        ))
        after = db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id;"
        ).fetchall()
        print("Stored rows unchanged:", before == after)


if __name__ == "__main__":
    main()
