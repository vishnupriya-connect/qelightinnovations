"""Verify the examples, controlled change, and invalid inputs."""

import numpy as np

from collections_to_arrays import convert_with_type, make_examples, revised_table


def run_checks():
    one, two, three = make_examples()
    assert one.tolist() == [20, 30, 40]
    assert two.tolist() == [[20, 10], [30, 15], [40, 20]]
    assert three.tolist() == [
        [[20, 10], [30, 15]], [[40, 20], [50, 25]],
    ]
    assert (one.shape, one.ndim, one.size) == ((3,), 1, 3)
    assert (two.shape, two.ndim, two.size) == ((3, 2), 2, 6)
    assert (three.shape, three.ndim, three.size) == ((2, 2, 2), 3, 8)
    assert all(a.dtype == np.dtype("int32") for a in (one, two, three))
    assert int(three[1, 0, 1]) == 20

    inferred = np.array([20, 30, 40])
    assert inferred.dtype.kind in "iu"
    mixed = np.array([20, 30.5, 40])
    assert mixed.dtype.kind == "f"
    assert mixed.tolist() == [20.0, 30.5, 40.0]
    floating = convert_with_type([20, 30.5, 40], np.float64)
    assert floating.dtype == np.dtype("float64")
    assert floating.itemsize == 8

    source = [20, 30, 40]
    result = convert_with_type(source, np.int32)
    source[0] = 99
    assert int(result[0]) == 20
    changed = revised_table()
    assert changed.shape == (3, 2) and changed.dtype == np.dtype("int32")
    assert int(changed[1, 1]) == 18
    assert changed[0].tolist() == [20, 10]
    assert two[1].tolist() == [30, 15]

    for bad in ([[20, 10], [30]], ["20", "not recorded", "40"]):
        try:
            convert_with_type(bad, np.int32)
        except ValueError:
            pass
        else:
            raise AssertionError(f"Expected ValueError for {bad!r}")
    corrected = convert_with_type([[20, 10], [30, 15]], np.int32)
    assert corrected.shape == (2, 2) and corrected.size == 4
    print("All collections-to-arrays checks passed.")


if __name__ == "__main__":
    run_checks()
