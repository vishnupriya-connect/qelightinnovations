# Row filtering lab

Run with Python 3 from the unzipped folder:

```sh
python row_filter.py
python check_row_filter.py
```

Use `python3` if that is your installed command. The Python standard-library `sqlite3` module builds a private in-memory database. Predict row IDs before running, change a threshold, reproduce and repair a grouping error, and attempt the independent variant before inspecting the supplied reference.
