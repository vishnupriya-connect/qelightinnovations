"""Verify counts, distinctness, null handling, range boundaries, and summaries."""

from aggregate_functions import (
    COURSES,
    catalogue_summary,
    instructor_report,
    make_connection,
    practice_summary,
    range_report,
)


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        assert before == COURSES

        assert catalogue_summary(db) == (4, 2, 2, 290, 72.5, 50, 95)
        assert db.execute(
            "SELECT COUNT(DISTINCT topic_note), COUNT(DISTINCT duration_minutes) "
            "FROM course_catalogue"
        ).fetchone() == (2, 4)
        print("Whole-catalogue counts, distinctness and numeric aggregates: correct")

        assert practice_summary(db) == (4, 2, 50, 25.0, 20, 30)
        assert db.execute(
            "SELECT COUNT(*), COUNT(practice_minutes), SUM(practice_minutes), "
            "AVG(practice_minutes) FROM course_catalogue WHERE instructor_id = 8"
        ).fetchone() == (2, 0, None, None)
        print("Missing numeric values and all-null subset: correct")

        assert range_report(db) == (3, 10, 65.0, 2, 1, 30)
        assert range_report(db, 51, 79) == (1, 3, 65.0, 1, 0, None)
        print("Inclusive range and changed boundaries: correct")

        assert instructor_report(db, 7) == (2, 175, 87.5, 80, 95, 2, 50)
        assert instructor_report(db, 8) == (2, 115, 57.5, 50, 65, 0, None)
        print("Independent instructor variation: correct")

        assert db.execute(
            "SELECT COUNT(*), COUNT(practice_minutes), SUM(duration_minutes), "
            "AVG(duration_minutes), MIN(duration_minutes), MAX(duration_minutes) "
            "FROM course_catalogue WHERE duration_minutes > 200"
        ).fetchone() == (0, 0, None, None, None, None)
        assert db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall() == before
        print("Empty input and unchanged stored rows: correct")


if __name__ == "__main__":
    main()
