"""Complete reference solution for reviewing study results."""

import numpy as np


def main():
    results = np.array([[80, 45, 100], [60, 75, 50]])
    attended = np.array([[True, True, False], [True, False, True]])
    eligible = np.logical_and(results >= 70, attended)
    review = np.logical_or(results < 50, np.logical_not(attended))
    print("eligible", eligible.tolist())
    print("review", review.tolist())
    print("any review", np.any(review, axis=1).tolist())
    print("all attended", np.all(attended, axis=1).tolist())
    print("any eligible", np.any(eligible, axis=1).tolist())


if __name__ == "__main__":
    main()
