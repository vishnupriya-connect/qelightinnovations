"""Create and inspect small DataFrames from four input structures."""

import numpy as np
import pandas as pd


def make_examples():
    learners = pd.DataFrame(
        {"name": ["Asha", "Bala"], "score": [7, 9]},
        index=["L1", "L2"],
    )
    from_rows = pd.DataFrame(
        [
            {"name": "Asha", "score": 7},
            {"name": "Bala", "score": 9},
        ],
        index=["L1", "L2"],
    )
    from_lists = pd.DataFrame(
        [["Asha", 7], ["Bala", 9]],
        index=["L1", "L2"],
        columns=["name", "score"],
    )
    counts = np.array([[7, 2], [9, 3]], dtype=np.int32)
    from_array = pd.DataFrame(
        counts,
        index=["L1", "L2"],
        columns=["score", "tasks"],
    )
    return learners, from_rows, from_lists, from_array


def main():
    learners, from_rows, from_lists, from_array = make_examples()
    print("Learner table:")
    print(learners.to_string())
    print("Rows:", learners.index.tolist())
    print("Columns:", learners.columns.tolist())
    print("Shape:", learners.shape)
    print("Dimensions:", learners.ndim)
    print("Cell L2 / score:", learners.loc["L2", "score"])
    print("Column data types:", {name: str(dtype) for name, dtype in learners.dtypes.items()})
    print("List of dictionaries matches:", from_rows.equals(learners))
    print("List of lists matches:", from_lists.equals(learners))
    print("NumPy table shape:", from_array.shape)
    print("NumPy table L2 / tasks:", from_array.loc["L2", "tasks"])


if __name__ == "__main__":
    main()
