"""Check values, shapes, empty cases, and a controlled variation."""

from array_slicing import (
    changed_source_slice, example_arrays, one_dimensional_slices,
    two_dimensional_slices,
)


def run_checks():
    minutes, work = example_arrays()
    one = one_dimensional_slices(minutes)
    expected_one = {
        "range": [20, 30, 40, 50],
        "front": [10, 20, 30],
        "tail": [40, 50, 60],
        "negative_start": [40, 50, 60],
        "step": [20, 40, 60],
        "reverse": [60, 50, 40, 30, 20, 10],
        "reverse_step": [60, 40],
        "clipped": [50, 60],
        "empty": [],
    }
    for name, values in expected_one.items():
        assert one[name].tolist() == values, name
        assert one[name].shape == (len(values),), name

    two = two_dimensional_slices(work)
    assert two["rows"].tolist() == [[20, 21, 22, 23], [30, 31, 32, 33]]
    assert two["rows"].shape == (2, 4)
    assert two["columns"].tolist() == [[11, 12], [21, 22], [31, 32], [41, 42]]
    assert two["columns"].shape == (4, 2)
    assert two["block"].tolist() == [[20, 22], [40, 42]]
    assert two["block"].shape == (2, 2)
    assert two["reverse_rows"].tolist() == work.tolist()[::-1]
    assert two["reverse_columns"].tolist() == [row[::-1] for row in work.tolist()]
    assert two["wrong_stop"].tolist() == [[21], [31]]
    assert two["wrong_stop"].shape == (2, 1)
    assert two["correct_stop"].tolist() == [[21, 22], [31, 32]]
    assert two["correct_stop"].shape == (2, 2)

    stepped, reverse = changed_source_slice()
    assert stepped.tolist() == [20, 45, 60]
    assert reverse[:3].tolist() == [60, 50, 45]
    assert minutes.tolist() == [10, 20, 30, 40, 50, 60]
    try:
        _ = minutes[::0]
    except ValueError:
        pass
    else:
        raise AssertionError("Expected zero-step slice failure")
    print("All array-slicing checks passed.")


if __name__ == "__main__":
    run_checks()
