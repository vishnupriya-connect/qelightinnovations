"""Complete reference solution for the study-records mini-project."""

import numpy as np


def main():
    records = np.arange(100, 124, dtype=np.int32).reshape(2, 3, 4)
    weeks_last = np.moveaxis(records, 0, 2)
    tasks_first = records.transpose(2, 0, 1)
    exchanged = records.swapaxes(0, 2)
    vector = records[1, 2]
    column = np.expand_dims(vector, axis=1)
    back = np.squeeze(column, axis=1)

    print(weeks_last.shape, weeks_last[2, 3, 1])
    print(tasks_first.shape, tasks_first[3, 1, 2])
    print(exchanged.shape, exchanged[3, 2, 1])
    print(column.shape, back.shape)
    print(back.tolist())


if __name__ == "__main__":
    main()
