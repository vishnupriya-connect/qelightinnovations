# Fancy indexing lab

Run in this folder:

```sh
python -m pip install -r requirements.txt
python fancy_indexing.py
python check_fancy_indexing.py
```

Use `python3` if needed. Predict output order, repetition, shape, and whether storage is shared before running. Complete the learner-reorder mini-project independently, then compare with `python mini_project_reference.py`. The examples were checked with NumPy 2.3.5.
