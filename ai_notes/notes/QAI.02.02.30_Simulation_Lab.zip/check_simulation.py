"""Check simulated ranges, estimates, repeated state, and bad input."""

import numpy as np

from simulation import compare_events, run_even_die


def main():
    rng = np.random.default_rng(42)
    rolls, successes, estimate = run_even_die(12, rng)
    assert rolls.shape == (12,)
    assert np.all((rolls >= 1) & (rolls <= 6))
    assert successes == int(np.sum(rolls % 2 == 0))
    assert estimate == successes / 12
    assert 0 <= estimate <= 1
    example = np.array([1, 2, 6, 3, 4, 5])
    assert (example % 2 == 0).tolist() == [False, True, True, False, True, False]
    assert compare_events(example) == ((3, 0.5), (2, 2 / 6))
    even, high = compare_events(rolls)
    assert even[0] == successes and even[1] == estimate
    assert high[0] == int(np.sum(rolls >= 5))
    assert high[1] == high[0] / rolls.size
    next_sample = run_even_die(12, rng)
    reference = np.random.default_rng(42)
    assert np.array_equal(rolls, run_even_die(12, reference)[0])
    assert np.array_equal(next_sample[0], run_even_die(12, reference)[0])
    short = run_even_die(12, np.random.default_rng(19))[0]
    long = run_even_die(1200, np.random.default_rng(19))[0]
    assert np.array_equal(short, long[:12])
    repeated_rng = np.random.default_rng(31)
    batches = [run_even_die(12, repeated_rng) for _ in range(3)]
    replay_rng = np.random.default_rng(31)
    replay = [run_even_die(12, replay_rng) for _ in range(3)]
    assert all(np.array_equal(a[0], b[0]) and a[1:] == b[1:]
               for a, b in zip(batches, replay))
    for action in (
        lambda: run_even_die(0, rng),
        lambda: run_even_die(-1, rng),
        lambda: compare_events(np.array([], dtype=int)),
    ):
        try:
            action()
        except ValueError:
            pass
        else:
            raise AssertionError("Nonpositive trial count was accepted")
    print("All checks passed.")


if __name__ == "__main__":
    main()
