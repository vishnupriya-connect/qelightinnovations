"""Compare aliasing, shared views, independent numeric copies, and object copies."""

import copy

import numpy as np


def source():
    return np.array([10, 20, 30, 40], dtype=np.int32)


def alias_demo():
    original = source()
    alias = original
    same_object = alias is original
    shared = bool(np.shares_memory(alias, original))
    alias[0] = 11
    return same_object, shared, original.tolist(), alias.tolist()


def slice_view_demo():
    original = source()
    middle = original[1:3]
    same_object = middle is original
    shared = bool(np.shares_memory(middle, original))
    middle[0] = 25
    return same_object, shared, original.tolist(), middle.tolist()


def explicit_view_demo():
    original = source()
    whole_view = original.view()
    same_object = whole_view is original
    shared = bool(np.shares_memory(whole_view, original))
    whole_view[-1] = 45
    return same_object, shared, original.tolist(), whole_view.tolist()


def numeric_copy_demo():
    original = source()
    independent = original[1:3].copy()
    same_object = independent is original
    shared = bool(np.shares_memory(independent, original))
    independent[0] = 25
    return same_object, shared, original.tolist(), independent.tolist()


def controlled_change(use_copy):
    original = source()
    selected = original[2:4].copy() if use_copy else original[2:4]
    selected[0] = 35
    return original.tolist(), selected.tolist(), bool(np.shares_memory(original, selected))


def object_copy_demo():
    records = np.empty(1, dtype=object)
    records[0] = {"minutes": [10, 20]}
    shallow = records.copy()
    array_storage_shared = bool(np.shares_memory(records, shallow))
    nested_object_shared = shallow[0] is records[0]
    shallow[0]["minutes"].append(30)
    deep = copy.deepcopy(records)
    deep[0]["minutes"].append(40)
    return (
        array_storage_shared, nested_object_shared,
        records[0]["minutes"].copy(), shallow[0]["minutes"].copy(),
        deep[0]["minutes"].copy(), deep[0] is records[0],
    )


def main():
    for name, result in [
        ("Alias", alias_demo()),
        ("Slice view", slice_view_demo()),
        ("Explicit view", explicit_view_demo()),
        ("Numeric copy", numeric_copy_demo()),
    ]:
        print(f"{name}: same object, shares memory, source, derived = {result}")
    print("Selected view update:", controlled_change(use_copy=False))
    print("Selected copy update:", controlled_change(use_copy=True))
    print("Object copy:", object_copy_demo())


if __name__ == "__main__":
    main()
