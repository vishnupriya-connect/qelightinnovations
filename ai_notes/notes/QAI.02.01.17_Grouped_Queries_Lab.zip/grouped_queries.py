"""Compare row filters and group filters on a four-course SQLite catalogue."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95, 4, "intro", 20),
    (102, "Git Basics", 8, 50, 3, None, None),
    (103, "Data Basics", 7, 80, 4, "tables", 30),
    (104, "Python Basics", 8, 65, 3, None, None),
]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL,
            lesson_count INTEGER NOT NULL,
            topic_note TEXT,
            practice_minutes INTEGER
        )"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?, ?, ?, ?)", COURSES)
    db.commit()
    return db


def instructor_summaries(db):
    return db.execute(
        """SELECT instructor_id, COUNT(*) AS course_count,
                  SUM(duration_minutes) AS total_duration,
                  AVG(duration_minutes) AS average_duration,
                  COUNT(practice_minutes) AS recorded_practice_count
           FROM course_catalogue
           GROUP BY instructor_id
           ORDER BY instructor_id"""
    ).fetchall()


def group_after_row_filter(db, minimum):
    return db.execute(
        """SELECT instructor_id, COUNT(*), SUM(duration_minutes)
           FROM course_catalogue
           WHERE duration_minutes >= ?
           GROUP BY instructor_id
           ORDER BY instructor_id""",
        (minimum,),
    ).fetchall()


def group_filter(db, minimum_total):
    return db.execute(
        """SELECT instructor_id, COUNT(*), SUM(duration_minutes)
           FROM course_catalogue
           GROUP BY instructor_id
           HAVING SUM(duration_minutes) >= ?
           ORDER BY instructor_id""",
        (minimum_total,),
    ).fetchall()


def project_report(db, minimum_duration=60, minimum_count=2):
    """Summarise qualifying rows by instructor, keeping groups with enough rows."""
    return db.execute(
        """SELECT instructor_id, COUNT(*) AS course_count,
                  SUM(duration_minutes) AS total_duration,
                  AVG(duration_minutes) AS average_duration,
                  COUNT(practice_minutes) AS recorded_practice_count
           FROM course_catalogue
           WHERE duration_minutes >= ?
           GROUP BY instructor_id
           HAVING COUNT(*) >= ?
           ORDER BY instructor_id""",
        (minimum_duration, minimum_count),
    ).fetchall()


def lesson_count_variation(db, minimum_average=70):
    """Independent reference: group by lesson count and keep high averages."""
    return db.execute(
        """SELECT lesson_count, COUNT(*), SUM(duration_minutes), AVG(duration_minutes)
           FROM course_catalogue
           GROUP BY lesson_count
           HAVING AVG(duration_minutes) >= ?
           ORDER BY lesson_count""",
        (minimum_average,),
    ).fetchall()


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        print("Per instructor:", instructor_summaries(db))
        print("Rows at least 65, then group:", group_after_row_filter(db, 65))
        print("Groups totalling at least 150:", group_filter(db, 150))
        print("Project report:", project_report(db))
        print("Lesson-count variation:", lesson_count_variation(db))
        print("Stored rows unchanged:", before == db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall())


if __name__ == "__main__":
    main()
