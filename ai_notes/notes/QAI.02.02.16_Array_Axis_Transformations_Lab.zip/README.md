# Array-axis transformations lab

Run with Python 3:

```bash
python -m pip install -r requirements.txt
python array_axis_transformations.py
python check_array_axis_transformations.py
python mini_project_reference.py
```

The main program demonstrates row and column axes and traces one element through three cube arrangements. Predict each shape and coordinate before running it. The checker verifies the mappings. Try the controlled variation described in the companion notes on a fresh copy of the cube.
