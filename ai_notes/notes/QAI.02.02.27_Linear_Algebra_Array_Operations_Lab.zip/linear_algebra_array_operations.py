"""Trace products and verify linear systems and eigenpairs."""

import numpy as np


def make_examples():
    A = np.array([[2.0, 1.0], [1.0, 2.0]])
    B = np.array([[1.0, 2.0], [3.0, 4.0]])
    u = np.array([2.0, 1.0])
    w = np.array([3.0, 4.0])
    b = np.array([5.0, 4.0])
    singular = np.array([[1.0, 2.0], [2.0, 4.0]])
    return A, B, u, w, b, singular


def main():
    A, B, u, w, b, singular = make_examples()
    print("Element-wise:", (A * B).tolist())
    print("Matrix product:", (A @ B).tolist())
    print("Matrix-vector:", (A @ u).tolist())
    print("Dot and inner:", np.dot(u, w), np.inner(u, w))
    print("Outer:", np.outer(u, w).tolist())
    x = np.linalg.solve(A, b)
    print("Solution:", x.tolist(), "verified:", bool(np.allclose(A @ x, b)))
    print("Determinant:", round(float(np.linalg.det(A)), 6))
    print("Inverse:", np.round(np.linalg.inv(A), 3).tolist())
    print("Rank:", np.linalg.matrix_rank(A))
    print("Singular determinant and rank:",
          round(float(np.linalg.det(singular)), 6),
          np.linalg.matrix_rank(singular))
    values, vectors = np.linalg.eig(A)
    print("Eigenvalues:", np.sort(np.round(values, 6)).tolist())
    print("Eigenpairs verified:",
          [bool(np.allclose(A @ vectors[:, i], values[i] * vectors[:, i]))
           for i in range(len(values))])
    changed_b = b.copy()
    changed_b[:] = [6.0, 6.0]
    changed_x = np.linalg.solve(A, changed_b)
    print("Variation:", changed_x.tolist(), "original:", b.tolist())


if __name__ == "__main__":
    main()
