"""Check creation, index meaning, slicing, and filtering."""

import pandas as pd

from series_fundamentals import make_examples


def main():
    minutes, from_dict, targets = make_examples()
    assert isinstance(minutes, pd.Series)
    assert minutes.name == "study_minutes"
    assert len(minutes) == 3
    assert pd.api.types.is_integer_dtype(minutes.dtype)
    assert minutes.index.tolist() == ["Mon", "Tue", "Wed"]
    assert minutes.tolist() == [15, 25, 20]
    assert from_dict.index.tolist() == minutes.index.tolist()
    assert from_dict.tolist() == minutes.tolist()
    assert targets.name == "target_minutes"
    assert targets.tolist() == [30, 30, 30]
    assert pd.Series([15, 25, 20]).index.tolist() == [0, 1, 2]

    assert minutes.loc["Tue"] == 25
    assert minutes.iloc[1] == 25
    assert minutes.loc["Mon":"Tue"].index.tolist() == ["Mon", "Tue"]
    assert minutes.iloc[0:2].index.tolist() == ["Mon", "Tue"]
    mask = minutes >= 20
    assert mask.tolist() == [False, True, True]
    assert minutes[mask].index.tolist() == ["Tue", "Wed"]
    assert minutes[mask].tolist() == [25, 20]

    try:
        minutes.loc["Fri"]
    except KeyError:
        pass
    else:
        raise AssertionError("A missing label should fail.")
    try:
        minutes.iloc[3]
    except IndexError:
        pass
    else:
        raise AssertionError("A position past the end should fail.")
    print("All checks passed.")


if __name__ == "__main__":
    main()
