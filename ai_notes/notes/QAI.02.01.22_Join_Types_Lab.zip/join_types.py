"""Compare join types, unmatched rows, and join multiplicity in SQLite."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95),
    (102, "Git Basics", 8, 50),
    (103, "Data Basics", 7, 80),
    (104, "Python Basics", 8, 65),
    (105, "SQL Basics", 42, 70),
]
INSTRUCTORS = [(7, "Asha"), (8, "Ben"), (9, "Cora")]
TAGS = [(101, "starter"), (101, "featured"), (102, "starter"), (104, "starter")]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY, title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL, duration_minutes INTEGER NOT NULL
        )"""
    )
    db.execute(
        """CREATE TABLE instructors (
            instructor_id INTEGER PRIMARY KEY, instructor_name TEXT NOT NULL
        )"""
    )
    db.execute(
        "CREATE TABLE course_tags (course_id INTEGER NOT NULL, tag TEXT NOT NULL)"
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?)", COURSES)
    db.executemany("INSERT INTO instructors VALUES (?, ?)", INSTRUCTORS)
    db.executemany("INSERT INTO course_tags VALUES (?, ?)", TAGS)
    db.commit()
    return db


def join_rows(db, kind):
    """Use only the fixed join keywords in this lab; they are not bound values."""
    joins = {
        "inner": "INNER JOIN",
        "left": "LEFT JOIN",
        "right": "RIGHT JOIN",
        "full": "FULL OUTER JOIN",
    }
    if kind not in joins:
        raise ValueError("kind must be inner, left, right or full")
    return db.execute(
        """SELECT c.course_id, c.title, i.instructor_id, i.instructor_name
           FROM course_catalogue AS c """ + joins[kind] + """ instructors AS i
           ON c.instructor_id = i.instructor_id
           ORDER BY COALESCE(c.course_id, 1000 + i.instructor_id)"""
    ).fetchall()


def cross_count(db):
    return db.execute(
        "SELECT COUNT(*) FROM course_catalogue AS c CROSS JOIN instructors AS i"
    ).fetchone()[0]


def same_instructor_pairs(db):
    """Reference variation: each unordered pair of courses sharing a key."""
    return db.execute(
        """SELECT a.course_id, b.course_id, a.instructor_id
           FROM course_catalogue AS a
           JOIN course_catalogue AS b
             ON a.instructor_id = b.instructor_id AND a.course_id < b.course_id
           ORDER BY a.course_id, b.course_id"""
    ).fetchall()


def tag_rows(db):
    return db.execute(
        """SELECT c.course_id, c.title, t.tag
           FROM course_catalogue AS c
           JOIN course_tags AS t ON c.course_id = t.course_id
           ORDER BY c.course_id, t.tag"""
    ).fetchall()


def unmatched_audit(db):
    """Reference mini-project: rows without counterparts on either side."""
    return db.execute(
        """SELECT c.course_id, c.title, c.instructor_id,
                  i.instructor_id, i.instructor_name
           FROM course_catalogue AS c
           FULL OUTER JOIN instructors AS i
             ON c.instructor_id = i.instructor_id
           WHERE c.course_id IS NULL OR i.instructor_id IS NULL
           ORDER BY COALESCE(c.course_id, 1000 + i.instructor_id)"""
    ).fetchall()


def main():
    with make_connection() as db:
        before = [db.execute("SELECT * FROM " + table + " ORDER BY 1, 2").fetchall()
                  for table in ("course_catalogue", "instructors", "course_tags")]
        for kind in ("inner", "left", "right", "full"):
            print(kind.title() + ":", join_rows(db, kind))
        print("Cross count:", cross_count(db))
        print("Tag rows:", tag_rows(db))
        print("Self pairs:", same_instructor_pairs(db))
        print("Unmatched audit:", unmatched_audit(db))
        after = [db.execute("SELECT * FROM " + table + " ORDER BY 1, 2").fetchall()
                 for table in ("course_catalogue", "instructors", "course_tags")]
        print("Stored tables unchanged:", before == after)


if __name__ == "__main__":
    main()
