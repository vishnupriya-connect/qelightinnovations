"""Checks normal, boundary, grouped, missing-result and independent cases."""

from row_filter import COURSES, ids, long_by_instructor, long_or_exception, make_connection


def main():
    with make_connection() as db:
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id;"
        ).fetchall() == COURSES
        q = "SELECT course_id FROM course_catalogue WHERE "
        tail = " ORDER BY course_id;"
        comparisons = {
            "duration_minutes = 80": [103],
            "duration_minutes <> 80": [101, 102, 104],
            "duration_minutes > 80": [101],
            "duration_minutes < 80": [102, 104],
            "duration_minutes >= 80": [101, 103],
            "duration_minutes <= 80": [102, 103, 104],
        }
        for condition, expected in comparisons.items():
            assert ids(db, q + condition + tail) == expected, condition
        print("Six comparison boundaries: correct")

        assert long_by_instructor(db, 80, 7) == [101, 103]
        assert long_by_instructor(db, 81, 7) == [101]
        assert ids(db, q + "instructor_id = 8 OR duration_minutes > 90" + tail) == [
            101, 102, 104
        ]
        assert ids(db, q + "NOT (instructor_id = 8)" + tail) == [101, 103]
        print("AND, OR, NOT and changed threshold: correct")

        ungrouped = ids(
            db, q + "title = 'Git Basics' OR instructor_id = 7 "
            "AND duration_minutes >= 90" + tail
        )
        grouped = ids(
            db, q + "(title = 'Git Basics' OR instructor_id = 7) "
            "AND duration_minutes >= 90" + tail
        )
        assert ungrouped == [101, 102]
        assert grouped == [101]
        print("Ungrouped versus grouped: [101, 102] versus [101]")

        assert long_or_exception(db) == [101, 102, 103]
        assert ids(db, q + "duration_minutes > 200" + tail) == []
        print("Mini-project and empty result: correct")

        # A possible independent variant after the learner's own attempt.
        variant = ids(
            db, q + "(instructor_id = 8 AND duration_minutes < 80) "
            "OR course_id = 103" + tail
        )
        assert variant == [102, 103, 104]
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id;"
        ).fetchall() == COURSES
        print("Independent variant: [102, 103, 104]")
        print("Stored rows unchanged: True")


if __name__ == "__main__":
    main()
