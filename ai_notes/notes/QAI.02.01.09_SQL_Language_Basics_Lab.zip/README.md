# SQL language basics lab

Run with Python 3 from this folder:

```sh
python sql_language_basics.py
python check_sql_language_basics.py
```

If `python` is not your Python 3 command, use `python3`. The database exists only in memory and is rebuilt on each run. No installation or account is needed.

First predict the output. Run the demo, change its first query's second output column to `instructor_id`, and explain the new result. Then attempt the catalogue preview and computed `display_id` variation in the notes before reading the reference functions and checks. Preserve your query, prediction, actual output, corrected error, and a short explanation.
