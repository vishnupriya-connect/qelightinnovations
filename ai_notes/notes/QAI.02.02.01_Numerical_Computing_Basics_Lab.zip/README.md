# Numerical-computing basics lab

Requires Python 3 and NumPy. In an environment where NumPy is not yet installed, run:

```sh
python -m pip install -r requirements.txt
```

Then, from this folder:

```sh
python numerical_basics.py
python check_numerical_basics.py
```

Use `python3` in place of `python` if needed. Installation should be done in your project environment. The lab needs no external dataset or database. Predict the total and mean before running. In a copy, change one value and explain the new summaries. The checker demonstrates why `import numpy` alone does not make the name `np` available in a fresh namespace.
