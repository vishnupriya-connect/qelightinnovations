"""Check boundaries, counts, spacing, errors, and altered inputs."""

import numpy as np

from number_sequences import example_sequences, six_checkpoints, wrong_direction


def run_checks():
    a = example_sequences()
    assert a["step"].tolist() == [2, 4, 6, 8, 10]
    assert a["step"].dtype == np.dtype("int32")
    assert a["descending"].tolist() == [10, 7, 4]
    assert np.allclose(a["inclusive"], [0, .25, .5, .75, 1])
    assert np.allclose(a["exclusive"], [0, .25, .5, .75])
    assert np.allclose(a["powers_of_ten"], [1, 10, 100, 1000])
    assert np.allclose(a["powers_of_two"], [1, 2, 4, 8])
    assert np.allclose(a["excluded_power"], [1, 10, 100])
    assert a["powers_of_ten"].size == 4
    assert np.allclose(six_checkpoints(), [0, 2, 4, 6, 8, 10])
    assert np.allclose(six_checkpoints(endpoint=False), [0, 10/6, 20/6, 5, 40/6, 50/6])
    assert six_checkpoints(endpoint=False).size == 6
    assert wrong_direction().size == 0
    try:
        np.arange(0, 5, 0)
    except ZeroDivisionError:
        pass
    else:
        raise AssertionError("Expected a zero-step failure")
    assert np.arange(2, 11, 2).tolist() == [2, 4, 6, 8, 10]
    print("All number-sequence checks passed.")


if __name__ == "__main__":
    run_checks()
