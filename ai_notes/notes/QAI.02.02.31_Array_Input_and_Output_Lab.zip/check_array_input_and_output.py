"""Check binary, archive, and text round trips."""

from pathlib import Path
from tempfile import TemporaryDirectory

import numpy as np

from array_input_and_output import round_trip


def main() -> None:
    with TemporaryDirectory() as temporary:
        result = round_trip(Path(temporary))
        expected = np.array([[10, 20, 30], [40, 50, 60]], dtype=np.int32)
        assert result["archive_keys"] == {"scores", "task_ids"}
        for name in ("binary", "archive_scores", "text", "original_again"):
            array = result[name]
            assert array.shape == (2, 3), name
            assert array.dtype == np.dtype("int32"), name
            assert np.array_equal(array, expected), name
        assert np.array_equal(
            result["archive_task_ids"], np.array([101, 102], dtype=np.int32)
        )
        assert result["csv_text"] == "10,20,30\n40,50,60\n"
        assert result["changed"].tolist() == [[10, 20, 30], [40, 50, 99]]

        try:
            np.loadtxt(result["csv_path"], dtype=np.int32)
        except ValueError:
            pass
        else:
            raise AssertionError("A comma-separated file needs delimiter=','.")

        default_text = np.loadtxt(result["csv_path"], delimiter=",")
        assert default_text.dtype == np.dtype("float64")
        assert np.array_equal(default_text, expected)
    print("All checks passed.")


if __name__ == "__main__":
    main()
