"""A small application access layer for a temporary SQLite database."""

import sqlite3
from collections import deque
from contextlib import contextmanager
from pathlib import Path
from tempfile import TemporaryDirectory


def connect(path):
    db = sqlite3.connect(str(path), timeout=1, isolation_level=None)
    db.execute('PRAGMA foreign_keys=ON')
    return db


@contextmanager
def open_database(path):
    db = connect(path)
    try:
        yield db
    finally:
        if db.in_transaction:
            db.rollback()
        db.close()


def initialize(path):
    with open_database(path) as db:
        db.executescript("""
            CREATE TABLE courses (
                course_id INTEGER PRIMARY KEY,
                title TEXT NOT NULL,
                duration_minutes INTEGER NOT NULL CHECK(duration_minutes > 0)
            );
            INSERT INTO courses VALUES
                (101, 'AI Foundations', 95),
                (102, 'Git Basics', 50),
                (103, 'Data Basics', 80),
                (104, 'Python Basics', 65);
        """)


def course_by_id(db, course_id):
    cursor = db.cursor()
    try:
        cursor.execute('SELECT course_id, title FROM courses WHERE course_id = ?', (course_id,))
        return cursor.fetchone()
    finally:
        cursor.close()


def courses_at_least(db, minimum_minutes):
    cursor = db.cursor()
    try:
        cursor.execute('''SELECT course_id, title FROM courses
                          WHERE duration_minutes >= ? ORDER BY course_id''',
                       (minimum_minutes,))
        return cursor.fetchall()
    finally:
        cursor.close()


def add_course(db, course_id, title, duration_minutes):
    try:
        db.execute('BEGIN IMMEDIATE')
        db.execute('INSERT INTO courses VALUES (?, ?, ?)',
                   (course_id, title, duration_minutes))
        db.execute('COMMIT')
    except Exception:
        if db.in_transaction:
            db.execute('ROLLBACK')
        raise


class PoolExhausted(RuntimeError):
    pass


class DemoPool:
    """Bounded single-thread demonstration; use a vetted pool in real services."""

    def __init__(self, path, size=2):
        if size < 1:
            raise ValueError('size must be positive')
        self.connections = [connect(path) for _ in range(size)]
        self.available = deque(self.connections)
        self.closed = False

    @contextmanager
    def checkout(self):
        if self.closed:
            raise RuntimeError('pool closed')
        if not self.available:
            raise PoolExhausted('no connection available')
        db = self.available.popleft()
        try:
            yield db
        finally:
            # A failed borrower must not pass an open transaction to another.
            if db.in_transaction:
                db.rollback()
            self.available.append(db)

    def close(self):
        if len(self.available) != len(self.connections):
            raise RuntimeError('return borrowed connections before closing')
        if not self.closed:
            for db in self.connections:
                db.close()
            self.closed = True


def pool_demo(path):
    pool = DemoPool(path)
    with pool.checkout() as first:
        first_id = id(first)
        with pool.checkout() as second:
            second_id = id(second)
            exhausted = False
            try:
                with pool.checkout():
                    pass
            except PoolExhausted:
                exhausted = True
            second.execute('BEGIN')
            second.execute("INSERT INTO courses VALUES (106, 'Temporary', 20)")
            # Returning second rolls back the unfinished write.
        cleaned = course_by_id(first, 106) is None
    with pool.checkout() as reused:
        reused_connection = id(reused) in (first_id, second_id)
        rows = courses_at_least(reused, 80)
    pool.close()
    return exhausted, cleaned, reused_connection, rows, pool.closed


def main():
    with TemporaryDirectory(prefix='qai_application_db_') as folder:
        path = Path(folder) / 'courses.sqlite'
        initialize(path)
        with open_database(path) as db:
            print('One course:', course_by_id(db, 103))
            print('Unknown course:', course_by_id(db, 999))
            print('At least 70 minutes:', courses_at_least(db, 70))
            add_course(db, 105, 'SQL Basics', 70)
            print('After insert:', courses_at_least(db, 70))
        with open_database(path) as reopened:
            print('After reopen:', course_by_id(reopened, 105))
        print('Pool demo (exhausted, cleaned, reused, rows, closed):', pool_demo(path))


if __name__ == '__main__':
    main()
