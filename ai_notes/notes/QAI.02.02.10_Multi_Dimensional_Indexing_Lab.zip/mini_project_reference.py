"""Reference for the independent two-day, three-learner task."""

import numpy as np

from multi_dimensional_indexing import corrected_week, read_scalar


def main():
    records = np.array([
        [[10, 5], [20, 10], [15, 5]],
        [[12, 8], [18, 12], [10, 10]],
    ], dtype=np.int32)
    print("Shape:", records.shape)
    print("Day 1 learner 1 practice:", read_scalar(records, (1, 1, 1)))
    print("Day 1 table:", records[1].tolist(), records[1].shape)
    print("Day 0 learner 2 row:", records[0, 2].tolist(), records[0, 2].shape)
    print("Day 1 practice column:", records[1, :, 1].tolist(), records[1, :, 1].shape)
    revised = corrected_week(records, (1, 1, 1), 17)
    print("Revised practice column:", revised[1, :, 1].tolist())
    print("Original selected value:", read_scalar(records, (1, 1, 1)))
    print("Incomplete coordinate returns row:", records[1, 1].tolist())
    try:
        read_scalar(records, (1, 1))
    except ValueError as error:
        print("Single-reading guard:", error)
    try:
        read_scalar(records, (2, 0, 0))
    except IndexError as error:
        print("Out of bounds:", type(error).__name__)


if __name__ == "__main__":
    main()
