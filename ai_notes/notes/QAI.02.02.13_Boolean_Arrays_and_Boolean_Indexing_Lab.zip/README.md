# Boolean arrays and indexing lab

Run from this folder:

```sh
python -m pip install -r requirements.txt
python boolean_indexing.py
python check_boolean_indexing.py
```

Use `python3` if needed. Predict each mask, selected value, and post-assignment array before running. Complete the task-threshold mini-project independently, then compare with `python mini_project_reference.py`. Examples were checked with NumPy 2.3.5.
