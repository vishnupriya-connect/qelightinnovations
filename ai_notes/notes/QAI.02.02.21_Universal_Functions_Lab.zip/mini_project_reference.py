"""Complete reference solution for the measurement report."""

import numpy as np


def main():
    deviations = np.array([-3.2, 0.0, 2.7, -1.5])
    counts = np.array([0.0, 1.0, 4.0, 9.0])
    angles = np.array([0.0, np.pi / 2, np.pi])
    print("magnitude", np.abs(deviations).tolist())
    print("square", np.round(np.square(deviations), 2).tolist())
    print("floor", np.floor(deviations).tolist())
    print("ceil", np.ceil(deviations).tolist())
    print("round", np.round(deviations).tolist())
    print("roots", np.sqrt(counts).tolist())
    print("sine", np.round(np.sin(angles), 6).tolist())
    print("cosine", np.round(np.cos(angles), 6).tolist())


if __name__ == "__main__":
    main()
