# QAI.02.01.06 — Relationships and cardinality

Use Python and its standard-library SQLite module. The project is local, in memory, and uses fictional learners. No external account is needed.

From this project directory:

```text
python relationships.py
python check_relationships.py
python relationships.py --enrol-ravi-in-git
```

Substitute `python3` if that is your machine's Python command. The checker rejects five invalid links or repeated pairs, accepts a new course with no lessons, and prints `Checks passed: 6`. The guided change adds one enrolment without affecting course 101's learner list.

The companion `QAI.02.01.06_Relationships_and_Cardinality_Notes.md` has a readable ER diagram, an explanation of minimum/maximum participation, and a completed answer to the independent change.

**Evidence to retain:** baseline output; six check results; the guided-change output; a diagram annotated with the minimum and maximum for each direction; and a modified copy with a third course but no lesson.

**Limit:** foreign keys and non-null constraints are active, but capacity limits and a rule requiring every course to have a lesson are not enforced here. Do not treat this as a complete enrolment service.
