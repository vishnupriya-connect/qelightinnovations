"""Check sorting, ties, paging boundaries, filtered paging and unchanged data."""

from sorting_limiting import (
    COURSES,
    duration_page,
    make_connection,
    ordered_ids,
    project_page,
)


def main():
    with make_connection() as db:
        before = db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall()
        assert before == COURSES

        assert ordered_ids(db, "title ASC, course_id ASC") == [101, 103, 102, 104]
        assert ordered_ids(db, "duration_minutes ASC, course_id ASC") == [102, 104, 103, 101]
        assert ordered_ids(db, "duration_minutes DESC, course_id ASC") == [101, 103, 104, 102]
        assert ordered_ids(db, "duration_minutes, course_id") == [102, 104, 103, 101]
        print("Sort columns and ASC/DESC: correct")

        assert ordered_ids(db, "instructor_id ASC, title ASC, course_id ASC") == [
            101, 103, 102, 104
        ]
        assert ordered_ids(db, "instructor_id ASC, title DESC, course_id ASC") == [
            103, 101, 104, 102
        ]
        assert ordered_ids(db, "lesson_count DESC, duration_minutes ASC, course_id ASC") == [
            103, 101, 102, 104
        ]
        print("Primary and secondary keys across ties: correct")

        assert ordered_ids(db, "course_id ASC LIMIT 1") == [101]
        assert ordered_ids(db, "duration_minutes DESC, course_id ASC LIMIT 1") == [101]
        assert ordered_ids(db, "title ASC, course_id ASC LIMIT 1") == [101]
        assert ordered_ids(db, "duration_minutes ASC, course_id ASC LIMIT 1") == [102]
        print("First row depends on the sort rule: correct")

        assert duration_page(db, 1, 2) == [101, 103]
        assert duration_page(db, 2, 2) == [104, 102]
        assert duration_page(db, 3, 2) == []
        assert duration_page(db, 2, 1) == [103]
        assert duration_page(db, 2, 3) == [102]
        assert ordered_ids(db, "duration_minutes DESC, course_id ASC LIMIT 2 OFFSET 1") == [
            103, 104
        ]
        print("Offset, page size and empty page: correct")

        assert project_page(db) == [(104, "Python Basics")]
        assert db.execute(
            """SELECT course_id FROM course_catalogue
            WHERE title LIKE '%Basics' AND topic_note IS NULL
            ORDER BY title ASC, course_id ASC LIMIT 1 OFFSET 0"""
        ).fetchall() == [(102,)]
        assert db.execute("SELECT * FROM course_catalogue ORDER BY course_id").fetchall() == before
        print("Filtered mini-project and unchanged source: correct")


if __name__ == "__main__":
    main()
