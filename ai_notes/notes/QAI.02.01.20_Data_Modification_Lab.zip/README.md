# Data modification lab

Run from this unzipped folder with Python 3:

```sh
python data_modification.py
python check_data_modification.py
```

Use `python3` if needed. The standard-library `sqlite3` module creates only in-memory tables. The lab prints the project candidate IDs before editing. It runs unrestricted UPDATE and DELETE and the unsupported TRUNCATE syntax in separate fresh tables. Predict affected IDs and row counts; run and verify both changed and unchanged rows. Reproduce an overly broad update only on a fresh copy, then repair the WHERE condition. Attempt the independent variation before reading its reference function. The checker validates the supplied examples and cannot validate your separate edits.
