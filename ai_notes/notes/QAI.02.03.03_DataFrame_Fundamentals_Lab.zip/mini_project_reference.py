"""Reference solution: a two-session practice log."""

import pandas as pd

practice = pd.DataFrame(
    [
        {"topic": "Python", "minutes": 20},
        {"topic": "Pandas", "minutes": 30},
    ],
    index=["S1", "S2"],
)
print("shape", practice.shape)
print("rows", practice.index.tolist())
print("columns", practice.columns.tolist())
print("minutes type", "integer" if pd.api.types.is_integer_dtype(practice["minutes"].dtype) else "other")
print("S2 minutes", practice.loc["S2", "minutes"])
