# Conditional numerical operations lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python conditional_numerical_operations.py
python check_conditional_numerical_operations.py
python mini_project_reference.py
```

Trace the values -5 and 110 through `where`, `clip`, `maximum`, and `minimum` before running. Try the controlled variation in the companion notes.
