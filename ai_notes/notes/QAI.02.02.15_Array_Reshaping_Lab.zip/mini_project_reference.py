"""Reference solution for the independent six-value grid task."""

import numpy as np

from array_reshaping import resize_on_fresh_array, shape_assignment_on_fresh_array, source_values


def main():
    source = source_values()
    two_three = source.reshape(2, 3)
    three_two = source.reshape(3, 2)
    inferred = source.reshape(2, -1)
    for name, array in [
        ("Original", source), ("2 x 3", two_three),
        ("3 x 2", three_two), ("Inferred", inferred),
    ]:
        print(f"{name}: shape={array.shape}, values={array.tolist()}")
    copied = two_three.flatten()
    raveled = two_three.ravel()
    print("Flatten:", copied.tolist(), "shares memory:", bool(np.shares_memory(copied, two_three)))
    print("Ravel:", raveled.tolist(), "shares memory:", bool(np.shares_memory(raveled, two_three)))
    print("Resized fresh array:", resize_on_fresh_array().tolist())
    print("Shape-assigned fresh array:", shape_assignment_on_fresh_array().tolist())
    try:
        source.reshape(4, 2)
    except ValueError as error:
        print("Wrong eight-slot target:", type(error).__name__, "; repair: (2, 3) for six values")


if __name__ == "__main__":
    main()
