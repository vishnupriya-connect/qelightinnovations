# Sorting and searching lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python sorting_and_searching.py
python check_sorting_and_searching.py
python mini_project_reference.py
```

Predict the first `argsort` position and the insertion position of 15 before running. Try the controlled variation in the companion notes.
