"""Inspect NumPy array layout, representation, and element bytes."""

import numpy as np


def study_grid():
    return np.array([[20, 10], [30, 15], [40, 20]], dtype=np.int16)


def inspect_array(array):
    if not isinstance(array, np.ndarray):
        raise TypeError("Expected a NumPy ndarray")
    return {
        "shape": array.shape,
        "ndim": array.ndim,
        "size": array.size,
        "dtype": str(array.dtype),
        "itemsize": array.itemsize,
        "nbytes": array.nbytes,
    }


def require_layout(array, shape, dtype):
    """Check agreed axis lengths and type before interpreting values."""
    inspected = inspect_array(array)
    expected_dtype = str(np.dtype(dtype))
    if inspected["shape"] != shape:
        raise ValueError(f"Expected shape {shape}; got {inspected['shape']}")
    if inspected["dtype"] != expected_dtype:
        raise ValueError(f"Expected dtype {expected_dtype}; got {inspected['dtype']}")
    return inspected


def main():
    grid = study_grid()
    print("Display:")
    print(grid)
    print("Representation:", repr(grid))
    print("As Python lists:", grid.tolist())
    print("Inspection:", inspect_array(grid))
    print("Expected layout:", require_layout(grid, (3, 2), np.int16))

    wider = grid.astype(np.int32)
    print("Wider item type:", inspect_array(wider))
    swapped = np.array([[20, 10, 30], [15, 40, 20]], dtype=np.int16)
    print("Swapped layout:", inspect_array(swapped))
    try:
        require_layout(swapped, (3, 2), np.int16)
    except ValueError as error:
        print("Shape diagnosis:", error)
    try:
        require_layout(wider, (3, 2), np.int16)
    except ValueError as error:
        print("Type diagnosis:", error)

    scalar = np.array(7, dtype=np.int16)
    empty = np.empty((0, 2), dtype=np.int16)
    print("Scalar:", inspect_array(scalar))
    print("Zero elements:", inspect_array(empty))


if __name__ == "__main__":
    main()
