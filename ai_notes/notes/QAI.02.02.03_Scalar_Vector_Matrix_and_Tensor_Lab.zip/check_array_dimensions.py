"""Check example outputs, boundary cases, and a controlled change."""

import numpy as np

from array_dimensions import axis_lengths, examples, revise_matrix


def run_checks():
    scalar, vector, matrix, weeks, empty = examples()
    assert isinstance(scalar, np.ndarray)
    assert isinstance(scalar[()], np.int32)
    assert (scalar.ndim, scalar.shape, scalar.size) == (0, (), 1)
    assert (empty.ndim, empty.shape, empty.size) == (1, (0,), 0)
    assert axis_lengths(scalar) == ()
    assert axis_lengths(empty) == (0,)
    assert (vector.ndim, vector.shape, vector.size) == (1, (3,), 3)
    assert int(vector[1]) == 30
    assert (matrix.ndim, matrix.shape, matrix.size) == (2, (2, 3), 6)
    assert axis_lengths(matrix) == (2, 3)
    assert int(matrix[1, 1]) == 15
    assert matrix.sum(axis=0).tolist() == [22, 23, 10]
    assert matrix.sum(axis=1).tolist() == [25, 30]
    assert matrix.sum(axis=0).shape == (3,)
    assert matrix.sum(axis=1).shape == (2,)
    assert (weeks.ndim, weeks.shape, weeks.size) == (3, (2, 2, 3), 12)
    assert axis_lengths(weeks) == (2, 2, 3)
    assert int(weeks[1, 0, 1]) == 6
    assert weeks.sum(axis=0).tolist() == [[26, 14, 10], [22, 25, 13]]
    assert weeks.sum(axis=0).shape == (2, 3)
    assert weeks.sum(axis=(1, 2)).tolist() == [55, 55]

    revised = revise_matrix(matrix)
    assert revised is not matrix
    assert revised.sum(axis=1).tolist() == [25, 34]
    assert revised.sum(axis=0).tolist() == [22, 23, 14]
    assert matrix.sum(axis=1).tolist() == [25, 30]
    assert revised.shape == matrix.shape

    try:
        matrix.sum(axis=2)
    except np.exceptions.AxisError:
        pass
    else:
        raise AssertionError("Expected invalid axis 2 to fail")
    assert int(matrix.sum(axis=1)[1]) == 30
    print("All array-dimensions checks passed.")


if __name__ == "__main__":
    run_checks()
