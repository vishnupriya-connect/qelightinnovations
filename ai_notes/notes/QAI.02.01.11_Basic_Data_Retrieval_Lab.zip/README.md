# Basic data retrieval lab

From this folder, use Python 3:

```sh
python retrieval.py
python check_retrieval.py
```

Use `python3` if needed. The lab uses Python's standard `sqlite3` module and a temporary in-memory database. It needs no account, server, or extra package.

Predict the headings and rows before running. Change one selected column, reproduce and repair a wrong identifier, and attempt the compact teacher directory from the notes before inspecting the reference function in `retrieval.py` and checks in `check_retrieval.py`.
