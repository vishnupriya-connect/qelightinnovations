# Views and reusable queries lab

Requires Python 3 with the standard-library `sqlite3` module; no installation or external data is needed.

Run from this folder:

```sh
python views_queries.py
python check_views_queries.py
```

Use `python3` if `python` is unavailable. The database is in memory and is recreated on each run.

Before running, predict the initial view rows and `(count, total minutes)`. Then trace the source update, definition replacement, and explicit snapshot refresh. For an independent exercise, write `short_courses` yourself before checking the reference function. The checker prints one result for each group of verified behavior.
