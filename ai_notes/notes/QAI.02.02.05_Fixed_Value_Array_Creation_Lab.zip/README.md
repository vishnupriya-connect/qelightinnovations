# Fixed-value array creation lab

Run in this folder:

```sh
python -m pip install -r requirements.txt
python fixed_value_arrays.py
python check_fixed_value_arrays.py
```

Use `python3` if needed. Predict the shapes and fills before running. Complete the independent activity setup first, then compare with `python mini_project_reference.py`. NumPy `2.3.5` was used to check the examples. Do not inspect or use values from a numeric `np.empty` buffer before every position has been initialized.
