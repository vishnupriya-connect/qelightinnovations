"""Complete reference solution for simulated coin-toss runs."""

import numpy as np


def coin_runs(seed, runs=3, tosses_per_run=20):
    rng = np.random.default_rng(seed)
    samples = []
    for run_number in range(runs):
        tosses = rng.integers(0, 2, size=tosses_per_run)
        heads = int(np.sum(tosses == 1))
        fraction = heads / tosses_per_run
        print("run", run_number + 1, "tosses", tosses.size,
              "heads", heads, "estimate", round(fraction, 3))
        samples.append(tosses)
    return samples


def main():
    samples = coin_runs(31)
    replay = coin_runs(31)
    total_heads = sum(int(np.sum(tosses == 1)) for tosses in samples)
    total_tosses = sum(tosses.size for tosses in samples)
    combined = total_heads / total_tosses
    print("run shapes", [tosses.shape for tosses in samples])
    print("counts valid", all(0 <= int(np.sum(t == 1)) <= t.size for t in samples))
    print("total tosses", total_tosses)
    print("combined estimate valid", 0 <= combined <= 1)
    print("same-seed replay",
          all(np.array_equal(a, b) for a, b in zip(samples, replay)))


if __name__ == "__main__":
    main()
