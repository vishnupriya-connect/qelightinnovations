"""Reference solution for the independent study-record protection task."""

import numpy as np


def starting_records():
    return np.array([[12, 8, 5], [10, 15, 5], [14, 6, 10]], dtype=np.int32)


def main():
    authoritative = starting_records()
    alias = authoritative
    print("Alias before:", authoritative.tolist())
    print("Alias identity and memory:", alias is authoritative, bool(np.shares_memory(alias, authoritative)))
    alias[0, 0] = 13
    print("Alias after, source row 0:", authoritative[0].tolist())

    authoritative = starting_records()
    row_view = authoritative[1, :]
    print("View before:", authoritative[1].tolist())
    print("View identity and memory:", row_view is authoritative, bool(np.shares_memory(row_view, authoritative)))
    row_view[1] = 16
    print("View after, source row 1:", authoritative[1].tolist())

    authoritative = starting_records()
    copied_row = authoritative[1, :].copy()
    print("Copy before:", authoritative[1].tolist())
    print("Copy identity and memory:", copied_row is authoritative, bool(np.shares_memory(copied_row, authoritative)))
    copied_row[1] = 16
    print("Copy after, derived row:", copied_row.tolist())
    print("Copy after, source row 1:", authoritative[1].tolist())


if __name__ == "__main__":
    main()
