"""Check conditional values, bounds, source preservation, and errors."""

import numpy as np

from conditional_numerical_operations import bounded, make_examples


def main():
    readings, thresholds = make_examples()
    condition = readings >= 50
    assert condition.shape == readings.shape == (2, 3)
    assert condition.tolist() == [[False, False, True], [False, True, True]]
    selected = np.where(condition, readings, 0)
    assert selected.tolist() == [[0, 0, 110], [0, 75, 95]]
    clipped = bounded(readings, 0, 100)
    assert clipped.tolist() == [[0, 45, 100], [20, 75, 95]]
    assert np.array_equal(clipped, readings.clip(0, 100))
    assert np.maximum(readings, 0).tolist() == [[0, 45, 110], [20, 75, 95]]
    assert np.minimum(readings, 100).tolist() == [[-5, 45, 100], [20, 75, 95]]
    assert np.array_equal(clipped, np.minimum(np.maximum(readings, 0), 100))
    assert np.maximum(readings, thresholds).tolist() == [[0, 50, 110], [20, 80, 95]]
    assert np.max(readings) == 110 and np.min(readings) == -5
    assert np.where(condition)[0].tolist() == [0, 1, 1]
    changed = readings.copy()
    changed[0, 1] = 55
    assert bool((changed >= 50)[0, 1])
    assert np.where(changed >= 50, changed, 0)[0, 1] == 55
    assert bounded(changed, 0, 100)[0, 1] == 55
    assert readings[0, 1] == 45
    try:
        bounded(readings, 100, 0)
    except ValueError:
        pass
    else:
        raise AssertionError("Reversed bounds should be rejected")
    assert np.isnan(np.maximum(np.array([np.nan]), np.array([1.0]))[0])
    assert np.isnan(np.minimum(np.array([1.0]), np.array([np.nan]))[0])
    print("All checks passed.")


if __name__ == "__main__":
    main()
