"""Detect NaN and infinities before summarizing or replacing values."""

import numpy as np


def make_examples():
    study = np.array([[10.0, np.nan, 20.0],
                      [5.0, 15.0, np.nan]])
    special = np.array([np.nan, np.inf, -np.inf, 5.0])
    return study, special


def available_summary(values):
    """Reject infinities and all-missing rows before reporting a mean."""
    if np.any(np.isinf(values)):
        raise ValueError("Resolve infinite values before reporting")
    if np.any(np.all(np.isnan(values), axis=1)):
        raise ValueError("An all-missing row has no observed mean")
    return np.nansum(values, axis=1), np.nanmean(values, axis=1)


def main():
    study, special = make_examples()
    print("Missing mask:", np.isnan(study).tolist())
    print("NaN:", np.isnan(special).tolist())
    print("Infinity:", np.isinf(special).tolist())
    print("Finite:", np.isfinite(special).tolist())
    totals, means = available_summary(study)
    print("Available sums:", totals.tolist())
    print("Available means:", means.tolist())
    print("Display placeholders:", np.nan_to_num(study, nan=0.0).tolist())
    print("Illustrative special codes:",
          np.nan_to_num(special, nan=0.0, posinf=100.0, neginf=-100.0).tolist())
    changed = study.copy()
    changed[0, 1] = 30.0
    new_totals, new_means = available_summary(changed)
    print("Variation:", new_totals[0], new_means[0],
          "original missing:", bool(np.isnan(study[0, 1])))


if __name__ == "__main__":
    main()
