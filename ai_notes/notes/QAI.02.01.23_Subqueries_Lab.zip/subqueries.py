"""Explore scalar, set, nested, and correlated SQLite subqueries."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95),
    (102, "Git Basics", 8, 50),
    (103, "Data Basics", 7, 80),
    (104, "Python Basics", 8, 65),
    (105, "SQL Basics", 42, 70),
]
INSTRUCTORS = [(7, "Asha"), (8, "Ben"), (9, "Cora")]
TAGS = [(101, "starter"), (101, "featured"), (102, "starter"), (104, "starter")]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY, title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL, duration_minutes INTEGER NOT NULL
        )"""
    )
    db.execute(
        """CREATE TABLE instructors (
            instructor_id INTEGER PRIMARY KEY, instructor_name TEXT NOT NULL
        )"""
    )
    db.execute(
        "CREATE TABLE course_tags (course_id INTEGER NOT NULL, tag TEXT NOT NULL)"
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?)", COURSES)
    db.executemany("INSERT INTO instructors VALUES (?, ?)", INSTRUCTORS)
    db.executemany("INSERT INTO course_tags VALUES (?, ?)", TAGS)
    db.commit()
    return db


def ids(db, query, parameters=()):
    return [row[0] for row in db.execute(query, parameters)]


def above_average(db):
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE c.duration_minutes >
             (SELECT AVG(duration_minutes) FROM course_catalogue)
           ORDER BY c.course_id""",
    )


def selected_instructors(db):
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE c.instructor_id IN
             (SELECT i.instructor_id FROM instructors AS i
              WHERE i.instructor_name IN ('Asha', 'Cora'))
           ORDER BY c.course_id""",
    )


def starter_courses(db):
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE EXISTS
             (SELECT 1 FROM course_tags AS t
              WHERE t.course_id = c.course_id AND t.tag = 'starter')
           ORDER BY c.course_id""",
    )


def untagged_courses(db):
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE NOT EXISTS
             (SELECT 1 FROM course_tags AS t WHERE t.course_id = c.course_id)
           ORDER BY c.course_id""",
    )


def nested_example(db):
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE c.instructor_id IN
             (SELECT i.instructor_id FROM instructors AS i
              WHERE i.instructor_id IN
                (SELECT x.instructor_id FROM course_catalogue AS x
                 WHERE x.duration_minutes >= 80))
           ORDER BY c.course_id""",
    )


def greater_than_any_peer(db, instructor_id=8):
    """SQLite EXISTS equivalent for > ANY with non-null numeric inputs."""
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE EXISTS
             (SELECT 1 FROM course_catalogue AS peer
              WHERE peer.instructor_id = ?
                AND c.duration_minutes > peer.duration_minutes)
           ORDER BY c.course_id""",
        (instructor_id,),
    )


def greater_than_all_peers(db, instructor_id=8):
    """SQLite NOT EXISTS equivalent for > ALL with non-null numeric inputs."""
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE NOT EXISTS
             (SELECT 1 FROM course_catalogue AS peer
              WHERE peer.instructor_id = ?
                AND c.duration_minutes <= peer.duration_minutes)
           ORDER BY c.course_id""",
        (instructor_id,),
    )


def project_candidates(db):
    """Above the global average and tagged starter, each course once."""
    return db.execute(
        """SELECT c.course_id, c.title, c.duration_minutes
           FROM course_catalogue AS c
           WHERE c.duration_minutes >
             (SELECT AVG(duration_minutes) FROM course_catalogue)
             AND EXISTS
               (SELECT 1 FROM course_tags AS t
                WHERE t.course_id = c.course_id AND t.tag = 'starter')
           ORDER BY c.course_id"""
    ).fetchall()


def independent_variation(db):
    """Untagged courses longer than every non-null instructor-8 duration."""
    return ids(
        db,
        """SELECT c.course_id FROM course_catalogue AS c
           WHERE NOT EXISTS
             (SELECT 1 FROM course_tags AS t WHERE t.course_id = c.course_id)
             AND NOT EXISTS
             (SELECT 1 FROM course_catalogue AS peer
              WHERE peer.instructor_id = 8
                AND c.duration_minutes <= peer.duration_minutes)
           ORDER BY c.course_id""",
    )


def main():
    with make_connection() as db:
        before = [db.execute("SELECT * FROM " + table + " ORDER BY 1, 2").fetchall()
                  for table in ("course_catalogue", "instructors", "course_tags")]
        print("Average duration:", db.execute(
            "SELECT AVG(duration_minutes) FROM course_catalogue"
        ).fetchone()[0])
        print("Above average:", above_average(db))
        print("Instructors Asha or Cora:", selected_instructors(db))
        print("Starter tag EXISTS:", starter_courses(db))
        print("No tags NOT EXISTS:", untagged_courses(db))
        print("Nested selection:", nested_example(db))
        print("Greater than ANY instructor-8 duration:", greater_than_any_peer(db))
        print("Greater than ALL instructor-8 durations:", greater_than_all_peers(db))
        print("Project candidates:", project_candidates(db))
        print("Independent variation:", independent_variation(db))
        after = [db.execute("SELECT * FROM " + table + " ORDER BY 1, 2").fetchall()
                 for table in ("course_catalogue", "instructors", "course_tags")]
        print("Stored tables unchanged:", before == after)


if __name__ == "__main__":
    main()
