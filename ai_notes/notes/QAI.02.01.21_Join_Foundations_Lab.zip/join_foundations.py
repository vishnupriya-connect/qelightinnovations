"""Match courses to instructors using an explicit join key."""

import sqlite3


COURSES = [
    (101, "AI Foundations", 7, 95),
    (102, "Git Basics", 8, 50),
    (103, "Data Basics", 7, 80),
    (104, "Python Basics", 8, 65),
    (105, "SQL Basics", 42, 70),
]
INSTRUCTORS = [(7, "Asha"), (8, "Ben"), (9, "Cora")]


def make_connection():
    db = sqlite3.connect(":memory:")
    db.execute(
        """CREATE TABLE course_catalogue (
            course_id INTEGER PRIMARY KEY,
            title TEXT NOT NULL,
            instructor_id INTEGER NOT NULL,
            duration_minutes INTEGER NOT NULL
        )"""
    )
    db.execute(
        """CREATE TABLE instructors (
            instructor_id INTEGER PRIMARY KEY,
            instructor_name TEXT NOT NULL
        )"""
    )
    db.executemany("INSERT INTO course_catalogue VALUES (?, ?, ?, ?)", COURSES)
    db.executemany("INSERT INTO instructors VALUES (?, ?)", INSTRUCTORS)
    db.commit()
    return db


def joined_rows(db):
    return db.execute(
        """SELECT c.course_id, c.title, i.instructor_name
           FROM course_catalogue AS c
           JOIN instructors AS i ON c.instructor_id = i.instructor_id
           ORDER BY c.course_id"""
    ).fetchall()


def project_rows(db, minimum=65):
    """Reference mini-project: named instructors for longer matching courses."""
    return db.execute(
        """SELECT c.course_id, c.title, i.instructor_name, c.duration_minutes
           FROM course_catalogue AS c
           JOIN instructors AS i ON c.instructor_id = i.instructor_id
           WHERE c.duration_minutes >= ?
           ORDER BY c.course_id""",
        (minimum,),
    ).fetchall()


def independent_variation(db, instructor=8):
    """Reference transfer: Basics titles taught by a named matching instructor."""
    return db.execute(
        """SELECT c.course_id, c.title, i.instructor_name
           FROM course_catalogue AS c
           JOIN instructors AS i ON c.instructor_id = i.instructor_id
           WHERE i.instructor_id = ? AND c.title LIKE '%Basics'
           ORDER BY c.course_id""",
        (instructor,),
    ).fetchall()


def main():
    with make_connection() as db:
        before_courses = db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall()
        before_instructors = db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall()
        print("Matched courses:", joined_rows(db))
        print("Project, at least 65:", project_rows(db))
        print("Independent variation:", independent_variation(db))
        print("Course 105's key:", db.execute(
            "SELECT course_id, instructor_id FROM course_catalogue WHERE course_id = 105"
        ).fetchone())
        print("Instructor 9:", db.execute(
            "SELECT instructor_id, instructor_name FROM instructors WHERE instructor_id = 9"
        ).fetchone())
        print("Both tables unchanged:", before_courses == db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() and before_instructors == db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall())


if __name__ == "__main__":
    main()
