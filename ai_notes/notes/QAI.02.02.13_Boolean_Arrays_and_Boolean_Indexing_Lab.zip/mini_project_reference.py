"""Reference for the independent task-threshold report."""

import numpy as np

from boolean_indexing import task_grid


def main():
    work = task_grid()
    mask = work >= 10
    selected = work[mask]
    print("Element mask:", mask.tolist(), mask.shape)
    print("Selected values:", selected.tolist(), selected.shape)
    updated = work.copy()
    updated[mask] = updated[mask] + 2
    print("Updated copy:", updated.tolist())
    print("Unchanged source:", work.tolist())
    row_mask = np.array([False, True])
    print("Selected learner row:", work[row_mask].tolist(), work[row_mask].shape)
    try:
        _ = work[np.array([False, True, False])]
    except IndexError as error:
        print("Wrong row-mask length:", type(error).__name__, "; expected two entries")


if __name__ == "__main__":
    main()
