# Linear-algebra array operations lab

Use Python 3:

```bash
python -m pip install -r requirements.txt
python linear_algebra_array_operations.py
python check_linear_algebra_array_operations.py
python mini_project_reference.py
```

Predict the top-left matrix-product cell and contrast it with element-wise multiplication. Verify each solution and eigenpair by substitution, then try the controlled variation in the notes.
