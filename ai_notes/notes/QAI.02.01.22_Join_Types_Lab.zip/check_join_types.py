"""Check preservation rules, missing values, pairs, and repeated joined rows."""

import sqlite3

from join_types import (
    COURSES, INSTRUCTORS, TAGS, cross_count, join_rows, make_connection,
    same_instructor_pairs, tag_rows, unmatched_audit,
)


def main():
    if sqlite3.sqlite_version_info < (3, 39, 0):
        raise RuntimeError("RIGHT and FULL OUTER JOIN require SQLite 3.39.0 or later")
    with make_connection() as db:
        expected_matched = [
            (101, "AI Foundations", 7, "Asha"),
            (102, "Git Basics", 8, "Ben"),
            (103, "Data Basics", 7, "Asha"),
            (104, "Python Basics", 8, "Ben"),
        ]
        left_only = (105, "SQL Basics", None, None)
        right_only = (None, None, 9, "Cora")
        assert join_rows(db, "inner") == expected_matched
        assert join_rows(db, "left") == expected_matched + [left_only]
        assert join_rows(db, "right") == expected_matched + [right_only]
        assert join_rows(db, "full") == expected_matched + [left_only, right_only]
        print("INNER, LEFT, RIGHT, FULL and missing joined values: correct")

        assert cross_count(db) == 15
        assert db.execute(
            "SELECT c.course_id, i.instructor_id FROM course_catalogue AS c "
            "CROSS JOIN instructors AS i WHERE c.course_id = 101 "
            "ORDER BY i.instructor_id"
        ).fetchall() == [(101, 7), (101, 8), (101, 9)]
        assert same_instructor_pairs(db) == [(101, 103, 7), (102, 104, 8)]
        print("CROSS product and self-join pairs: correct")

        assert tag_rows(db) == [
            (101, "AI Foundations", "featured"),
            (101, "AI Foundations", "starter"),
            (102, "Git Basics", "starter"),
            (104, "Python Basics", "starter"),
        ]
        assert db.execute(
            "SELECT c.course_id, c.title FROM course_catalogue AS c "
            "JOIN course_tags AS t ON c.course_id = t.course_id "
            "ORDER BY c.course_id, t.tag"
        ).fetchall() == [
            (101, "AI Foundations"), (101, "AI Foundations"),
            (102, "Git Basics"), (104, "Python Basics"),
        ]
        print("One-to-many join multiplicity and duplicate selected rows: correct")

        assert unmatched_audit(db) == [
            (105, "SQL Basics", 42, None, None),
            (None, None, None, 9, "Cora"),
        ]
        assert db.execute(
            "SELECT c.course_id FROM course_catalogue AS c "
            "LEFT JOIN instructors AS i ON c.instructor_id = i.instructor_id "
            "WHERE i.instructor_id IS NULL"
        ).fetchall() == [(105,)]
        in_on = db.execute(
            "SELECT c.course_id, i.instructor_name FROM course_catalogue AS c "
            "LEFT JOIN instructors AS i ON c.instructor_id = i.instructor_id "
            "AND i.instructor_name = 'Asha' ORDER BY c.course_id"
        ).fetchall()
        in_where = db.execute(
            "SELECT c.course_id, i.instructor_name FROM course_catalogue AS c "
            "LEFT JOIN instructors AS i ON c.instructor_id = i.instructor_id "
            "WHERE i.instructor_name = 'Asha' ORDER BY c.course_id"
        ).fetchall()
        assert in_on == [
            (101, "Asha"), (102, None), (103, "Asha"),
            (104, None), (105, None),
        ]
        assert in_where == [(101, "Asha"), (103, "Asha")]
        assert db.execute(
            "SELECT * FROM course_catalogue ORDER BY course_id"
        ).fetchall() == COURSES
        assert db.execute(
            "SELECT * FROM instructors ORDER BY instructor_id"
        ).fetchall() == INSTRUCTORS
        assert db.execute("SELECT * FROM course_tags ORDER BY course_id, tag").fetchall() == sorted(TAGS)
        print("Unmatched audit, ON versus WHERE, and unchanged tables: correct")


if __name__ == "__main__":
    main()
